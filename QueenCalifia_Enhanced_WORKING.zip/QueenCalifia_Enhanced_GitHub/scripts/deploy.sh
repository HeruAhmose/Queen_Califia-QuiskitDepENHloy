#!/bin/bash

# QueenCalifia One-Click Deployment Script
# This script sets up and deploys the complete QueenCalifia system

set -e  # Exit on any error

echo "🚀 QueenCalifia One-Click Deployment Starting..."
echo "=================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check Python
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        print_success "Python $PYTHON_VERSION found"
    else
        print_error "Python 3 is required but not installed"
        exit 1
    fi
    
    # Check Node.js
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node --version)
        print_success "Node.js $NODE_VERSION found"
    else
        print_warning "Node.js not found, installing..."
        # Install Node.js using NodeSource repository
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        sudo apt-get install -y nodejs
    fi
    
    # Check npm
    if command -v npm &> /dev/null; then
        NPM_VERSION=$(npm --version)
        print_success "npm $NPM_VERSION found"
    else
        print_error "npm is required but not installed"
        exit 1
    fi
    
    # Check pip
    if command -v pip3 &> /dev/null; then
        print_success "pip3 found"
    else
        print_warning "pip3 not found, installing..."
        sudo apt-get update
        sudo apt-get install -y python3-pip
    fi
}

# Setup backend
setup_backend() {
    print_status "Setting up backend..."
    
    cd backend
    
    # Create virtual environment
    if [ ! -d "venv" ]; then
        print_status "Creating Python virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip
    
    # Install requirements
    print_status "Installing Python dependencies..."
    pip install -r requirements.txt
    
    # Create environment file
    if [ ! -f ".env" ]; then
        print_status "Creating environment configuration..."
        cat > .env << EOF
FLASK_APP=app.py
FLASK_ENV=development
SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(16))')
QISKIT_BACKEND=aer_simulator
DATABASE_URL=sqlite:///queencalifia.db
REDIS_URL=redis://localhost:6379
EOF
    fi
    
    # Initialize database
    print_status "Initializing database..."
    python -c "
from app import create_app, db
app = create_app()
with app.app_context():
    db.create_all()
    print('Database initialized successfully')
"
    
    cd ..
    print_success "Backend setup completed"
}

# Setup frontend
setup_frontend() {
    print_status "Setting up frontend..."
    
    cd frontend
    
    # Install npm dependencies
    print_status "Installing Node.js dependencies..."
    npm install
    
    # Create environment file
    if [ ! -f ".env" ]; then
        print_status "Creating frontend environment configuration..."
        cat > .env << EOF
REACT_APP_API_URL=http://localhost:5000
REACT_APP_WEBSOCKET_URL=ws://localhost:5000
REACT_APP_VERSION=1.0.0
GENERATE_SOURCEMAP=false
EOF
    fi
    
    cd ..
    print_success "Frontend setup completed"
}

# Setup configuration
setup_config() {
    print_status "Setting up configuration files..."
    
    # Create nginx configuration
    mkdir -p config
    cat > config/nginx.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    upstream backend {
        server backend:5000;
    }
    
    server {
        listen 80;
        server_name localhost;
        
        # Frontend
        location / {
            root /usr/share/nginx/html;
            index index.html index.htm;
            try_files $uri $uri/ /index.html;
        }
        
        # API
        location /api/ {
            proxy_pass http://backend/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
        
        # WebSocket
        location /socket.io/ {
            proxy_pass http://backend;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
}
EOF
    
    print_success "Configuration setup completed"
}

# Start services
start_services() {
    print_status "Starting QueenCalifia services..."
    
    # Start backend
    print_status "Starting backend server..."
    cd backend
    source venv/bin/activate
    nohup python app.py > ../logs/backend.log 2>&1 &
    BACKEND_PID=$!
    echo $BACKEND_PID > ../logs/backend.pid
    cd ..
    
    # Wait for backend to start
    sleep 5
    
    # Start frontend
    print_status "Starting frontend server..."
    cd frontend
    nohup npm start > ../logs/frontend.log 2>&1 &
    FRONTEND_PID=$!
    echo $FRONTEND_PID > ../logs/frontend.pid
    cd ..
    
    # Wait for frontend to start
    sleep 10
    
    print_success "Services started successfully"
}

# Create log directory
mkdir -p logs

# Run deployment steps
check_requirements
setup_backend
setup_frontend
setup_config
start_services

# Final status check
print_status "Performing final system check..."

# Check if backend is running
if curl -s http://localhost:5000/health > /dev/null; then
    print_success "Backend is running at http://localhost:5000"
else
    print_error "Backend failed to start"
    exit 1
fi

# Check if frontend is running
if curl -s http://localhost:3000 > /dev/null; then
    print_success "Frontend is running at http://localhost:3000"
else
    print_warning "Frontend may still be starting up..."
fi

echo ""
echo "🎉 QueenCalifia Deployment Completed Successfully!"
echo "=================================================="
echo ""
echo "🌐 Access Points:"
echo "   • Web Interface: http://localhost:3000"
echo "   • API Endpoint:  http://localhost:5000"
echo "   • Health Check:  http://localhost:5000/health"
echo ""
echo "📊 System Status:"
echo "   • Backend PID: $(cat logs/backend.pid 2>/dev/null || echo 'Not found')"
echo "   • Frontend PID: $(cat logs/frontend.pid 2>/dev/null || echo 'Not found')"
echo ""
echo "📝 Logs:"
echo "   • Backend:  tail -f logs/backend.log"
echo "   • Frontend: tail -f logs/frontend.log"
echo ""
echo "🛑 To stop services:"
echo "   • ./scripts/stop.sh"
echo ""
echo "QueenCalifia is now ready for quantum-enhanced intelligence!"

