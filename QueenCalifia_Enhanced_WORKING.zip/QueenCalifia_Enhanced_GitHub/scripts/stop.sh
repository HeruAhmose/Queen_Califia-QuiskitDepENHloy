#!/bin/bash

# QueenCalifia Stop Services Script

set -e

echo "🛑 Stopping QueenCalifia services..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Stop backend
if [ -f "logs/backend.pid" ]; then
    BACKEND_PID=$(cat logs/backend.pid)
    if kill -0 $BACKEND_PID 2>/dev/null; then
        print_status "Stopping backend (PID: $BACKEND_PID)..."
        kill $BACKEND_PID
        rm logs/backend.pid
        print_success "Backend stopped"
    else
        print_status "Backend process not running"
        rm -f logs/backend.pid
    fi
else
    print_status "Backend PID file not found"
fi

# Stop frontend
if [ -f "logs/frontend.pid" ]; then
    FRONTEND_PID=$(cat logs/frontend.pid)
    if kill -0 $FRONTEND_PID 2>/dev/null; then
        print_status "Stopping frontend (PID: $FRONTEND_PID)..."
        kill $FRONTEND_PID
        rm logs/frontend.pid
        print_success "Frontend stopped"
    else
        print_status "Frontend process not running"
        rm -f logs/frontend.pid
    fi
else
    print_status "Frontend PID file not found"
fi

# Kill any remaining processes
print_status "Cleaning up any remaining processes..."
pkill -f "python.*app.py" 2>/dev/null || true
pkill -f "npm.*start" 2>/dev/null || true
pkill -f "react-scripts" 2>/dev/null || true

print_success "All QueenCalifia services stopped"

