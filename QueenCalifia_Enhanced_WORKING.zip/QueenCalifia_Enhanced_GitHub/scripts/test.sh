#!/bin/bash

# QueenCalifia Comprehensive Test Script

set -e

echo "🧪 QueenCalifia Test Suite"
echo "========================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[TEST]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

print_error() {
    echo -e "${RED}[FAIL]${NC} $1"
}

# Test counters
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

run_test() {
    local test_name="$1"
    local test_command="$2"
    
    print_status "Running: $test_name"
    TESTS_RUN=$((TESTS_RUN + 1))
    
    if eval "$test_command" > /dev/null 2>&1; then
        print_success "$test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        print_error "$test_name"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# Backend tests
print_status "Testing Backend..."
cd backend

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# Test Python imports
run_test "Python imports" "python -c 'import flask, qiskit, tensorflow, numpy'"

# Test quantum circuits
run_test "Quantum circuit creation" "python -c '
from qiskit import QuantumCircuit
qc = QuantumCircuit(2)
qc.h(0)
qc.cx(0, 1)
print(\"Quantum circuit created successfully\")
'"

# Test biomimetic networks
run_test "Biomimetic network imports" "python -c '
import tensorflow as tf
import numpy as np
print(\"Biomimetic dependencies available\")
'"

# Run backend unit tests if they exist
if [ -d "tests" ]; then
    run_test "Backend unit tests" "python -m pytest tests/ -v"
fi

cd ..

# Frontend tests
print_status "Testing Frontend..."
cd frontend

# Test Node.js dependencies
run_test "Node.js dependencies" "npm list --depth=0"

# Test TypeScript compilation
run_test "TypeScript compilation" "npm run type-check"

# Test React build
run_test "React build process" "npm run build"

# Run frontend unit tests
run_test "Frontend unit tests" "npm test -- --coverage --watchAll=false"

cd ..

# Integration tests
print_status "Testing Integration..."

# Test API endpoints (if backend is running)
if curl -s http://localhost:5000/health > /dev/null; then
    run_test "Backend health check" "curl -s http://localhost:5000/health"
    run_test "API quantum endpoint" "curl -s http://localhost:5000/api/quantum/status"
    run_test "API biomimetic endpoint" "curl -s http://localhost:5000/api/biomimetic/status"
    run_test "API smartcity endpoint" "curl -s http://localhost:5000/api/smartcity/status"
else
    print_status "Backend not running, skipping API tests"
fi

# Test frontend (if running)
if curl -s http://localhost:3000 > /dev/null; then
    run_test "Frontend accessibility" "curl -s http://localhost:3000"
else
    print_status "Frontend not running, skipping frontend tests"
fi

# Performance tests
print_status "Testing Performance..."

# Test quantum computation speed
run_test "Quantum computation performance" "python -c '
import time
from qiskit import QuantumCircuit, transpile
from qiskit_aer import Aer

start = time.time()
qc = QuantumCircuit(4)
for i in range(4):
    qc.h(i)
qc.measure_all()

backend = Aer.get_backend(\"aer_simulator\")
job = backend.run(transpile(qc, backend), shots=1000)
result = job.result()
end = time.time()

if end - start < 5.0:
    print(f\"Performance test passed: {end - start:.2f}s\")
else:
    raise Exception(f\"Performance test failed: {end - start:.2f}s\")
'"

# Security tests
print_status "Testing Security..."

# Test environment variables
run_test "Environment security" "python -c '
import os
required_vars = [\"SECRET_KEY\", \"FLASK_APP\"]
missing = [var for var in required_vars if not os.getenv(var)]
if missing:
    raise Exception(f\"Missing environment variables: {missing}\")
print(\"Environment variables configured\")
'"

# Test results summary
echo ""
echo "📊 Test Results Summary"
echo "======================"
echo "Tests Run:    $TESTS_RUN"
echo "Tests Passed: $TESTS_PASSED"
echo "Tests Failed: $TESTS_FAILED"

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}🎉 All tests passed!${NC}"
    exit 0
else
    echo -e "${RED}❌ Some tests failed!${NC}"
    exit 1
fi

