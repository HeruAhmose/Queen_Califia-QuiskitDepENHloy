import React, { useState, useEffect } from 'react';

const BiomimeticNetworks = () => {
  const [networkType, setNetworkType] = useState('spider');
  const [isTraining, setIsTraining] = useState(false);
  const [results, setResults] = useState([]);

  const trainSpiderNetwork = async () => {
    setIsTraining(true);
    try {
      const response = await fetch('/api/biomimetic/spider-web', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          input_data: [[0.1, 0.2, 0.3], [0.4, 0.5, 0.6], [0.7, 0.8, 0.9]],
          target_data: [[1, 0], [0, 1], [1, 1]],
          epochs: 10
        })
      });
      const data = await response.json();
      setResults(prev => [{ ...data, type: 'spider', timestamp: new Date() }, ...prev.slice(0, 4)]);
    } catch (error) {
      console.error('Spider network training failed:', error);
    } finally {
      setIsTraining(false);
    }
  };

  const trainMyceliumNetwork = async () => {
    setIsTraining(true);
    try {
      const response = await fetch('/api/biomimetic/mycelium', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          input_data: [[0.2, 0.4, 0.6], [0.1, 0.3, 0.5], [0.8, 0.7, 0.9]],
          target_data: [[0, 1], [1, 0], [1, 1]],
          epochs: 10
        })
      });
      const data = await response.json();
      setResults(prev => [{ ...data, type: 'mycelium', timestamp: new Date() }, ...prev.slice(0, 4)]);
    } catch (error) {
      console.error('Mycelium network training failed:', error);
    } finally {
      setIsTraining(false);
    }
  };

  return (
    <div>
      <div className="card quantum-glow">
        <h2>🕸️ Biomimetic Neural Networks</h2>
        <p>Nature-inspired neural architectures with quantum enhancement</p>
        
        <div className="network-selector">
          <button 
            className={`network-btn ${networkType === 'spider' ? 'active' : ''}`}
            onClick={() => setNetworkType('spider')}
          >
            🕷️ Spider Web Network
          </button>
          <button 
            className={`network-btn ${networkType === 'mycelium' ? 'active' : ''}`}
            onClick={() => setNetworkType('mycelium')}
          >
            🍄 Mycelium Network
          </button>
        </div>

        <div className="network-controls">
          <button 
            className="train-btn spider"
            onClick={trainSpiderNetwork}
            disabled={isTraining}
          >
            {isTraining ? '🔄 Training...' : '🕷️ Train Spider Network'}
          </button>
          
          <button 
            className="train-btn mycelium"
            onClick={trainMyceliumNetwork}
            disabled={isTraining}
          >
            {isTraining ? '🔄 Training...' : '🍄 Train Mycelium Network'}
          </button>
        </div>
      </div>

      <div className="card">
        <h3>🧠 Network Architecture Visualization</h3>
        {networkType === 'spider' ? (
          <div className="spider-web-viz">
            <div className="web-center">🕷️</div>
            <div className="web-ring ring-1">
              <div className="node">N₁</div>
              <div className="node">N₂</div>
              <div className="node">N₃</div>
              <div className="node">N₄</div>
            </div>
            <div className="web-ring ring-2">
              <div className="node">N₅</div>
              <div className="node">N₆</div>
              <div className="node">N₇</div>
              <div className="node">N₈</div>
            </div>
            <div className="web-ring ring-3">
              <div className="node">N₉</div>
              <div className="node">N₁₀</div>
              <div className="node">N₁₁</div>
              <div className="node">N₁₂</div>
            </div>
          </div>
        ) : (
          <div className="mycelium-viz">
            <div className="mycelium-network">
              <div className="mycelium-node main">🍄</div>
              <div className="mycelium-branch">
                <div className="mycelium-node">M₁</div>
                <div className="mycelium-node">M₂</div>
                <div className="mycelium-node">M₃</div>
              </div>
              <div className="mycelium-branch">
                <div className="mycelium-node">M₄</div>
                <div className="mycelium-node">M₅</div>
                <div className="mycelium-node">M₆</div>
              </div>
              <div className="mycelium-branch">
                <div className="mycelium-node">M₇</div>
                <div className="mycelium-node">M₈</div>
                <div className="mycelium-node">M₉</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {results.length > 0 && (
        <div className="card">
          <h3>📊 Training Results</h3>
          <div className="results-container">
            {results.map((result, index) => (
              <div key={index} className="result-item">
                <div className="result-header">
                  <span className="result-type">
                    {result.type === 'spider' ? '🕷️ Spider Web Network' : '🍄 Mycelium Network'}
                  </span>
                  <span className="result-time">
                    {result.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                
                <div className="result-content">
                  <p><strong>Final Accuracy:</strong> {(result.accuracy * 100)?.toFixed(2) || 'N/A'}%</p>
                  <p><strong>Training Loss:</strong> {result.loss?.toFixed(4) || 'N/A'}</p>
                  <p><strong>Epochs Completed:</strong> {result.epochs || 'N/A'}</p>
                  <p><strong>Training Time:</strong> {result.training_time?.toFixed(3) || 'N/A'}s</p>
                  {result.quantum_enhancement && (
                    <p><strong>Quantum Enhancement:</strong> +{(result.quantum_enhancement * 100).toFixed(1)}% accuracy</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="card">
        <h3>🔬 Network Characteristics</h3>
        <div className="characteristics-grid">
          <div className="char-item">
            <h4>🕷️ Spider Web Network</h4>
            <ul>
              <li>Radial topology with concentric layers</li>
              <li>Adaptive connection strength</li>
              <li>Vibration-based signal propagation</li>
              <li>Self-healing capabilities</li>
              <li>Quantum-enhanced pattern recognition</li>
            </ul>
          </div>
          <div className="char-item">
            <h4>🍄 Mycelium Network</h4>
            <ul>
              <li>Distributed branching architecture</li>
              <li>Resource sharing mechanisms</li>
              <li>Emergent collective intelligence</li>
              <li>Fault-tolerant communication</li>
              <li>Quantum correlation enhancement</li>
            </ul>
          </div>
        </div>
      </div>

      <style jsx>{`
        .network-selector {
          display: flex;
          gap: 15px;
          justify-content: center;
          margin: 20px 0;
        }
        
        .network-btn {
          padding: 12px 24px;
          border: 2px solid #667eea;
          border-radius: 8px;
          background: transparent;
          color: #667eea;
          font-weight: bold;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        
        .network-btn.active {
          background: #667eea;
          color: white;
        }
        
        .network-controls {
          display: flex;
          gap: 20px;
          justify-content: center;
          margin: 30px 0;
          flex-wrap: wrap;
        }
        
        .train-btn {
          padding: 15px 30px;
          border: none;
          border-radius: 10px;
          font-size: 1.1rem;
          font-weight: bold;
          cursor: pointer;
          transition: all 0.3s ease;
          color: white;
          min-width: 200px;
        }
        
        .train-btn.spider {
          background: linear-gradient(45deg, #f093fb, #f5576c);
        }
        
        .train-btn.mycelium {
          background: linear-gradient(45deg, #4facfe, #00f2fe);
        }
        
        .train-btn:hover:not(:disabled) {
          transform: translateY(-3px);
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }
        
        .train-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        
        .spider-web-viz {
          position: relative;
          width: 300px;
          height: 300px;
          margin: 20px auto;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(102, 126, 234, 0.1) 0%, transparent 70%);
        }
        
        .web-center {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          font-size: 2rem;
          z-index: 10;
        }
        
        .web-ring {
          position: absolute;
          border: 2px solid rgba(102, 126, 234, 0.3);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: space-around;
        }
        
        .ring-1 {
          width: 120px;
          height: 120px;
          top: 90px;
          left: 90px;
        }
        
        .ring-2 {
          width: 200px;
          height: 200px;
          top: 50px;
          left: 50px;
        }
        
        .ring-3 {
          width: 280px;
          height: 280px;
          top: 10px;
          left: 10px;
        }
        
        .node {
          background: #667eea;
          color: white;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 0.8rem;
          font-weight: bold;
        }
        
        .mycelium-viz {
          display: flex;
          justify-content: center;
          margin: 20px 0;
        }
        
        .mycelium-network {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 20px;
        }
        
        .mycelium-node {
          background: #4facfe;
          color: white;
          width: 40px;
          height: 40px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          margin: 5px;
        }
        
        .mycelium-node.main {
          font-size: 1.5rem;
          width: 50px;
          height: 50px;
        }
        
        .mycelium-branch {
          display: flex;
          gap: 10px;
        }
        
        .characteristics-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 30px;
          margin-top: 20px;
        }
        
        .char-item {
          background: rgba(0, 0, 0, 0.05);
          border-radius: 10px;
          padding: 20px;
        }
        
        .char-item h4 {
          margin: 0 0 15px 0;
          color: #667eea;
        }
        
        .char-item ul {
          margin: 0;
          padding-left: 20px;
        }
        
        .char-item li {
          margin: 8px 0;
        }
        
        .results-container {
          max-height: 400px;
          overflow-y: auto;
          margin-top: 20px;
        }
        
        .result-item {
          background: rgba(0, 0, 0, 0.05);
          border-radius: 8px;
          padding: 15px;
          margin-bottom: 15px;
          border-left: 4px solid #f093fb;
        }
        
        .result-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
        }
        
        .result-type {
          font-weight: bold;
          font-size: 1.1rem;
        }
        
        .result-time {
          font-size: 0.9rem;
          color: #666;
        }
        
        .result-content p {
          margin: 5px 0;
        }
      `}</style>
    </div>
  );
};

export default BiomimeticNetworks;

