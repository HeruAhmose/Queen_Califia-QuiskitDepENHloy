"""
QueenCalifia Flask Application Module
Main application entry point and API server
"""

from .main import app, queen_califia

__version__ = "1.0.0"
__author__ = "QueenCalifia Development Team"

# Export main application
__all__ = ['app', 'queen_califia']

