"""
QueenCalifia Smart City Infrastructure Module
Advanced resource optimization and environmental monitoring
"""

from .smart_city_infrastructure import (
    SmartCityComponent,
    EnergyManagementSystem,
    TrafficManagementSystem,
    EnvironmentalMonitoringSystem,
    SmartCityOrchestrator,
    ResourceData,
    EnvironmentalData,
    TrafficData,
    OptimizationResult,
    create_smart_city_component
)

__version__ = "1.0.0"
__author__ = "QueenCalifia Development Team"

# Quick access functions
def create_city_orchestrator():
    """Create a smart city orchestrator with all systems"""
    return SmartCityOrchestrator()

def create_energy_system():
    """Create an energy management system"""
    return EnergyManagementSystem()

def create_traffic_system():
    """Create a traffic management system"""
    return TrafficManagementSystem()

def create_environmental_system():
    """Create an environmental monitoring system"""
    return EnvironmentalMonitoringSystem()

__all__ = [
    'SmartCityComponent',
    'EnergyManagementSystem',
    'TrafficManagementSystem', 
    'EnvironmentalMonitoringSystem',
    'SmartCityOrchestrator',
    'ResourceData',
    'EnvironmentalData',
    'TrafficData',
    'OptimizationResult',
    'create_smart_city_component',
    'create_city_orchestrator',
    'create_energy_system',
    'create_traffic_system',
    'create_environmental_system'
]

