"""
QueenCalifia Quantum Computing Module
Advanced quantum neural networks and optimization algorithms
Optimized for IBM Qiskit environment
"""

from .quantum_core import (
    QuantumNeuralNetwork,
    QuantumErrorCorrection,
    QuantumOptimizer,
    QuantumStateManager,
    QuantumCore,
    QuantumResult,
    create_quantum_component
)

from .quantum_utils import (
    QuantumMetrics,
    QuantumVisualization,
    QuantumDataEncoder,
    QuantumCircuitBuilder,
    QuantumNoiseModel,
    QuantumBenchmark,
    optimize_circuit_depth,
    validate_quantum_state,
    quantum_state_tomography_data
)

__version__ = "1.0.0"
__author__ = "QueenCalifia Development Team"

# Module-level configuration
DEFAULT_BACKEND = 'aer_simulator'
DEFAULT_SHOTS = 1024
DEFAULT_OPTIMIZATION_LEVEL = 3

# Quick access functions
def get_quantum_core(backend_name: str = DEFAULT_BACKEND) -> QuantumCore:
    """Get a configured QuantumCore instance"""
    return QuantumCore(backend_name=backend_name)

def create_quantum_neural_network(num_qubits: int = 4, num_layers: int = 2, backend_name: str = DEFAULT_BACKEND) -> QuantumNeuralNetwork:
    """Create a quantum neural network with default parameters"""
    return QuantumNeuralNetwork(num_qubits=num_qubits, num_layers=num_layers, backend_name=backend_name)

def create_quantum_optimizer(backend_name: str = DEFAULT_BACKEND) -> QuantumOptimizer:
    """Create a quantum optimizer with default parameters"""
    return QuantumOptimizer(backend_name=backend_name)

# Module information
def get_module_info():
    """Get information about the quantum module"""
    return {
        'name': 'QueenCalifia Quantum Module',
        'version': __version__,
        'author': __author__,
        'components': [
            'QuantumNeuralNetwork',
            'QuantumErrorCorrection', 
            'QuantumOptimizer',
            'QuantumStateManager',
            'QuantumCore'
        ],
        'utilities': [
            'QuantumMetrics',
            'QuantumVisualization',
            'QuantumDataEncoder',
            'QuantumCircuitBuilder',
            'QuantumNoiseModel',
            'QuantumBenchmark'
        ],
        'default_backend': DEFAULT_BACKEND,
        'default_shots': DEFAULT_SHOTS
    }

__all__ = [
    # Core classes
    'QuantumNeuralNetwork',
    'QuantumErrorCorrection',
    'QuantumOptimizer', 
    'QuantumStateManager',
    'QuantumCore',
    'QuantumResult',
    
    # Utility classes
    'QuantumMetrics',
    'QuantumVisualization',
    'QuantumDataEncoder',
    'QuantumCircuitBuilder',
    'QuantumNoiseModel',
    'QuantumBenchmark',
    
    # Functions
    'create_quantum_component',
    'optimize_circuit_depth',
    'validate_quantum_state',
    'quantum_state_tomography_data',
    'get_quantum_core',
    'create_quantum_neural_network',
    'create_quantum_optimizer',
    'get_module_info'
]

