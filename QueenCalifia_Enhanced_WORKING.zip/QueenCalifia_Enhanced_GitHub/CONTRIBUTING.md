# Contributing to QueenCalifia

Thank you for your interest in contributing to QueenCalifia! This document provides guidelines and information for contributors.

## 🤝 How to Contribute

### Reporting Issues
- Use the [issue tracker](https://github.com/your-username/QueenCalifia_FullStack/issues)
- Search existing issues before creating new ones
- Provide detailed information including:
  - Steps to reproduce
  - Expected vs actual behavior
  - Environment details
  - Error messages and logs

### Suggesting Features
- Open a [feature request](https://github.com/your-username/QueenCalifia_FullStack/issues/new?template=feature_request.md)
- Describe the problem you're trying to solve
- Explain your proposed solution
- Consider implementation complexity

### Code Contributions

#### Getting Started
1. Fork the repository
2. Clone your fork: `git clone https://github.com/your-username/QueenCalifia_FullStack.git`
3. Create a feature branch: `git checkout -b feature/your-feature-name`
4. Set up development environment (see below)

#### Development Environment Setup

**Backend Setup:**
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
pip install -r requirements-dev.txt  # Development dependencies
```

**Frontend Setup:**
```bash
cd frontend
npm install
```

**Full Stack Setup:**
```bash
# Using Docker (recommended)
docker-compose -f docker-compose.dev.yml up --build
```

#### Making Changes

1. **Code Style**
   - Python: Follow PEP 8, use type hints
   - JavaScript: Use ESLint and Prettier
   - Run linters before committing

2. **Testing**
   - Write tests for new features
   - Maintain >90% test coverage
   - Run all tests before submitting

3. **Documentation**
   - Update relevant documentation
   - Add docstrings to new functions
   - Update API documentation if needed

#### Testing Your Changes

**Backend Tests:**
```bash
cd backend
python -m pytest tests/ -v --cov=app
```

**Frontend Tests:**
```bash
cd frontend
npm test
npm run test:coverage
```

**Integration Tests:**
```bash
./scripts/test.sh
```

**Manual Testing:**
```bash
# Start development environment
docker-compose -f docker-compose.dev.yml up

# Test API endpoints
curl http://localhost:5000/api/health
```

#### Submitting Changes

1. **Commit Guidelines**
   - Use clear, descriptive commit messages
   - Follow conventional commits format:
     ```
     type(scope): description
     
     feat(quantum): add new quantum circuit optimization
     fix(api): resolve authentication issue
     docs(readme): update installation instructions
     ```

2. **Pull Request Process**
   - Push to your feature branch
   - Create pull request against `main` branch
   - Fill out the PR template completely
   - Link related issues
   - Request review from maintainers

3. **PR Requirements**
   - [ ] All tests pass
   - [ ] Code coverage maintained
   - [ ] Documentation updated
   - [ ] No merge conflicts
   - [ ] Follows code style guidelines

## 📋 Development Guidelines

### Code Organization

```
QueenCalifia_FullStack/
├── backend/
│   ├── app/           # Flask application
│   ├── quantum/       # Quantum computing modules
│   ├── biomimetic/    # Neural network modules
│   ├── smartcity/     # Smart city modules
│   └── tests/         # Test suites
├── frontend/
│   ├── src/
│   │   ├── components/  # React components
│   │   ├── pages/       # Page components
│   │   ├── services/    # API services
│   │   └── utils/       # Utility functions
│   └── public/          # Static assets
├── docs/              # Documentation
└── scripts/           # Deployment scripts
```

### Coding Standards

#### Python
- Use type hints for all functions
- Follow PEP 8 style guide
- Use docstrings for all public functions
- Maximum line length: 88 characters
- Use Black for code formatting

```python
def quantum_execute(circuit: QuantumCircuit, shots: int = 1024) -> Dict[str, Any]:
    """Execute a quantum circuit and return results.
    
    Args:
        circuit: The quantum circuit to execute
        shots: Number of measurement shots
        
    Returns:
        Dictionary containing execution results
    """
    # Implementation here
    pass
```

#### JavaScript/React
- Use functional components with hooks
- Follow ESLint configuration
- Use TypeScript for type safety
- Use meaningful component names

```javascript
const QuantumDashboard: React.FC<QuantumDashboardProps> = ({ 
    circuits, 
    onExecute 
}) => {
    // Component implementation
};
```

### Testing Standards

#### Backend Testing
- Use pytest for testing
- Write unit tests for all functions
- Use fixtures for test data
- Mock external dependencies

```python
def test_quantum_circuit_execution():
    """Test quantum circuit execution."""
    circuit = create_test_circuit()
    result = quantum_execute(circuit, shots=100)
    
    assert result['success'] is True
    assert 'counts' in result
    assert len(result['counts']) > 0
```

#### Frontend Testing
- Use Jest and React Testing Library
- Test component behavior, not implementation
- Mock API calls

```javascript
test('renders quantum dashboard', () => {
    render(<QuantumDashboard circuits={mockCircuits} />);
    expect(screen.getByText('Quantum Circuits')).toBeInTheDocument();
});
```

### Documentation Standards

- Use Markdown for documentation
- Include code examples
- Keep documentation up to date
- Use clear, concise language

## 🔄 Development Workflow

### Branch Strategy
- `main`: Production-ready code
- `develop`: Integration branch for features
- `feature/*`: Individual feature branches
- `hotfix/*`: Critical bug fixes

### Release Process
1. Feature development in feature branches
2. Merge to develop for integration testing
3. Create release branch from develop
4. Final testing and bug fixes
5. Merge to main and tag release
6. Deploy to production

## 🐛 Debugging

### Common Issues

**Backend Issues:**
```bash
# Check logs
docker-compose logs backend

# Debug mode
export FLASK_DEBUG=1
flask run

# Database issues
rm data/queencalifia.db  # Reset database
```

**Frontend Issues:**
```bash
# Clear cache
npm start -- --reset-cache

# Check console errors
# Open browser dev tools
```

**Quantum Issues:**
```bash
# Check Qiskit installation
python -c "import qiskit; print(qiskit.__version__)"

# Test quantum backend
python -c "from qiskit import Aer; print(Aer.backends())"
```

### Performance Profiling

**Backend Profiling:**
```python
# Add to code for profiling
import cProfile
cProfile.run('your_function()')
```

**Frontend Profiling:**
```javascript
// Use React DevTools Profiler
// Enable in development mode
```

## 📚 Resources

### Learning Resources
- [Qiskit Textbook](https://qiskit.org/textbook/)
- [React Documentation](https://reactjs.org/docs/)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [TensorFlow Tutorials](https://www.tensorflow.org/tutorials)

### Development Tools
- **IDE:** VS Code with Python and React extensions
- **Debugging:** Python debugger, React DevTools
- **Testing:** pytest, Jest, React Testing Library
- **Linting:** pylint, ESLint, Prettier

### Community
- [GitHub Discussions](https://github.com/your-username/QueenCalifia_FullStack/discussions)
- [Discord Server](https://discord.gg/queencalifia)
- [Stack Overflow](https://stackoverflow.com/questions/tagged/queencalifia)

## 🏆 Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Annual contributor awards
- Conference presentations

## 📞 Getting Help

If you need help:
1. Check existing documentation
2. Search closed issues
3. Ask in GitHub Discussions
4. Contact maintainers directly

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to QueenCalifia! Together, we're building the future of quantum-enhanced intelligent systems. 🚀

