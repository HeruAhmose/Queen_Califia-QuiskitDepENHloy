# QueenCalifia API Documentation

## 🌟 Overview

The QueenCalifia API provides access to quantum computing, biomimetic neural networks, and smart city infrastructure through a comprehensive REST interface.

**Base URL:** `http://localhost:5000/api`

## 🔐 Authentication

Currently, the API is open for development. In production, implement:
- API key authentication
- JWT tokens
- Rate limiting per user

## 📋 Endpoints

### System Health

#### GET /health
Check system health status.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-06-09T17:23:16Z",
  "version": "1.0.0",
  "components": {
    "quantum": "operational",
    "biomimetic": "operational",
    "smartcity": "operational"
  }
}
```

#### GET /status
Get detailed system status and metrics.

**Response:**
```json
{
  "system_status": "operational",
  "last_update": "2025-06-09T17:23:16Z",
  "performance_metrics": {
    "cpu_usage": 45.2,
    "memory_usage": 67.8,
    "active_sessions": 3
  },
  "components": {
    "quantum_core": true,
    "biomimetic_networks": true,
    "smart_city_orchestrator": true
  }
}
```

### Quantum Computing

#### POST /quantum/execute
Execute a quantum circuit.

**Request Body:**
```json
{
  "circuit_type": "neural_network",
  "parameters": {
    "num_qubits": 4,
    "layers": 2,
    "shots": 1024
  },
  "input_data": [0.5, 0.3, 0.8, 0.1]
}
```

**Response:**
```json
{
  "success": true,
  "execution_id": "qc_exec_123456",
  "results": {
    "counts": {"0000": 256, "0001": 128, "1111": 640},
    "probabilities": [0.25, 0.125, 0.625],
    "execution_time": 0.045
  },
  "circuit_info": {
    "depth": 8,
    "gates": 16,
    "backend": "aer_simulator"
  }
}
```

### Biomimetic Neural Networks

#### POST /biomimetic/predict
Make predictions using biomimetic networks.

**Request Body:**
```json
{
  "network_type": "spider_web",
  "input_data": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0],
  "options": {
    "use_quantum": true,
    "ensemble": false
  }
}
```

**Response:**
```json
{
  "success": true,
  "prediction_id": "bio_pred_789012",
  "predictions": [0.85],
  "confidence": 0.92,
  "network_info": {
    "type": "spider_web",
    "layers": 3,
    "nodes": 8,
    "quantum_enhanced": true
  },
  "execution_time": 0.023
}
```

#### POST /biomimetic/train
Train a biomimetic network.

**Request Body:**
```json
{
  "network_type": "mycelium",
  "training_data": {
    "inputs": [[0.1, 0.2], [0.3, 0.4]],
    "targets": [[0.5], [0.6]]
  },
  "training_config": {
    "epochs": 100,
    "learning_rate": 0.001,
    "batch_size": 32
  }
}
```

**Response:**
```json
{
  "success": true,
  "training_id": "bio_train_345678",
  "status": "completed",
  "metrics": {
    "final_loss": 0.023,
    "accuracy": 0.95,
    "training_time": 45.2
  },
  "model_info": {
    "parameters": 1024,
    "convergence": true
  }
}
```

### Smart City Infrastructure

#### GET /smartcity/status
Get smart city system status.

**Response:**
```json
{
  "success": true,
  "city_status": "operational",
  "systems": {
    "energy_management": {
      "status": "active",
      "efficiency": 0.87,
      "total_consumption": 1250.5,
      "renewable_percentage": 0.65
    },
    "traffic_management": {
      "status": "active",
      "average_speed": 45.2,
      "congestion_level": 0.23,
      "incidents": 2
    },
    "environmental_monitoring": {
      "status": "active",
      "air_quality_index": 85,
      "temperature": 22.5,
      "humidity": 0.58
    }
  }
}
```

#### POST /smartcity/optimize
Optimize city resources using quantum algorithms.

**Request Body:**
```json
{
  "optimization_type": "energy_distribution",
  "parameters": {
    "demand_nodes": [100, 150, 200, 120],
    "supply_nodes": [180, 220, 160],
    "constraints": {
      "max_transmission": 500,
      "efficiency_target": 0.9
    }
  }
}
```

**Response:**
```json
{
  "success": true,
  "optimization_id": "city_opt_901234",
  "results": {
    "optimal_distribution": [120, 180, 140, 110],
    "efficiency_improvement": 0.15,
    "cost_reduction": 0.12,
    "execution_time": 2.34
  },
  "algorithm_info": {
    "type": "quantum_annealing",
    "iterations": 1000,
    "convergence": true
  }
}
```

#### POST /smartcity/simulate
Run smart city simulations.

**Request Body:**
```json
{
  "simulation_type": "traffic_flow",
  "scenario": {
    "duration": 3600,
    "events": [
      {"type": "accident", "time": 1800, "location": "intersection_5"},
      {"type": "construction", "time": 0, "duration": 3600, "location": "road_12"}
    ]
  },
  "parameters": {
    "vehicle_count": 1000,
    "weather": "clear",
    "time_of_day": "rush_hour"
  }
}
```

**Response:**
```json
{
  "success": true,
  "simulation_id": "city_sim_567890",
  "results": {
    "average_travel_time": 25.4,
    "congestion_hotspots": ["intersection_3", "road_7"],
    "efficiency_metrics": {
      "throughput": 0.78,
      "delay_factor": 1.23
    }
  },
  "recommendations": [
    "Increase signal timing at intersection_3",
    "Consider alternate route suggestions"
  ]
}
```

### Hybrid Analysis

#### POST /hybrid/analyze
Perform hybrid quantum-classical analysis.

**Request Body:**
```json
{
  "analysis_type": "pattern_recognition",
  "data": {
    "classical_features": [0.1, 0.2, 0.3],
    "quantum_features": [0.4, 0.5, 0.6]
  },
  "config": {
    "quantum_layers": 2,
    "classical_layers": 3,
    "hybrid_connections": true
  }
}
```

**Response:**
```json
{
  "success": true,
  "analysis_id": "hybrid_123456",
  "results": {
    "pattern_detected": true,
    "confidence": 0.89,
    "quantum_advantage": 0.15,
    "classical_baseline": 0.74
  },
  "performance": {
    "quantum_time": 0.045,
    "classical_time": 0.023,
    "total_time": 0.068
  }
}
```

## 📊 Response Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 400 | Bad Request - Invalid parameters |
| 401 | Unauthorized - Authentication required |
| 403 | Forbidden - Insufficient permissions |
| 404 | Not Found - Endpoint doesn't exist |
| 429 | Too Many Requests - Rate limit exceeded |
| 500 | Internal Server Error |
| 503 | Service Unavailable - System maintenance |

## 🔄 Async Operations

Some operations (training, optimization) are asynchronous:

1. **Submit Request** - Returns operation ID
2. **Check Status** - Use operation ID to check progress
3. **Get Results** - Retrieve results when complete

### Check Operation Status
```bash
GET /api/operations/{operation_id}/status
```

### Get Operation Results
```bash
GET /api/operations/{operation_id}/results
```

## 📈 Rate Limiting

- **Default:** 100 requests per minute per IP
- **Burst:** Up to 10 requests per second
- **Headers:** `X-RateLimit-Remaining`, `X-RateLimit-Reset`

## 🔧 Error Handling

All errors return consistent format:

```json
{
  "success": false,
  "error": {
    "code": "INVALID_PARAMETERS",
    "message": "Input data must be a list of numbers",
    "details": {
      "field": "input_data",
      "expected": "array",
      "received": "string"
    }
  },
  "request_id": "req_123456789"
}
```

## 📝 Examples

### Python Client Example
```python
import requests

# Execute quantum circuit
response = requests.post('http://localhost:5000/api/quantum/execute', json={
    'circuit_type': 'neural_network',
    'parameters': {'num_qubits': 4, 'layers': 2},
    'input_data': [0.5, 0.3, 0.8, 0.1]
})

result = response.json()
print(f"Quantum execution result: {result['results']}")
```

### JavaScript Client Example
```javascript
// Make biomimetic prediction
const response = await fetch('http://localhost:5000/api/biomimetic/predict', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
        network_type: 'spider_web',
        input_data: [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    })
});

const result = await response.json();
console.log('Prediction:', result.predictions);
```

### cURL Examples
```bash
# Health check
curl http://localhost:5000/api/health

# Smart city status
curl http://localhost:5000/api/smartcity/status

# Quantum execution
curl -X POST http://localhost:5000/api/quantum/execute \
  -H "Content-Type: application/json" \
  -d '{"circuit_type": "neural_network", "parameters": {"num_qubits": 4}}'
```

## 🔗 WebSocket Support

Real-time updates available via WebSocket:

```javascript
const socket = io('http://localhost:5000');

// Subscribe to system status updates
socket.on('system_status', (data) => {
    console.log('System status:', data);
});

// Subscribe to operation progress
socket.on('operation_progress', (data) => {
    console.log('Progress:', data.progress);
});
```

## 📚 SDK and Libraries

Official SDKs available for:
- Python: `pip install queencalifia-sdk`
- JavaScript/Node.js: `npm install queencalifia-sdk`
- Java: Maven/Gradle packages
- Go: Go modules

## 🧪 Testing

Use the built-in test endpoints:

```bash
# Test all systems
curl http://localhost:5000/api/test/all

# Test specific component
curl http://localhost:5000/api/test/quantum
curl http://localhost:5000/api/test/biomimetic
curl http://localhost:5000/api/test/smartcity
```

