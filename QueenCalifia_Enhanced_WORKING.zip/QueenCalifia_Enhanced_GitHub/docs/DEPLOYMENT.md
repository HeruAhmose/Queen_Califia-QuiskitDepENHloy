# QueenCalifia Deployment Guide

## 🚀 One-Click Deployment

### Prerequisites
- Docker and Docker Compose installed
- Git installed
- 8GB+ RAM recommended
- 10GB+ free disk space

### Quick Start

1. **Clone and Deploy**
   ```bash
   git clone <repository-url>
   cd QueenCalifia_FullStack
   chmod +x scripts/deploy.sh
   ./scripts/deploy.sh
   ```

2. **Access the Application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000
   - API Documentation: http://localhost:5000/api/docs

### Manual Deployment

#### Using Docker Compose (Recommended)

1. **Environment Setup**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

2. **Build and Start Services**
   ```bash
   docker-compose up --build -d
   ```

3. **Check Status**
   ```bash
   docker-compose ps
   docker-compose logs -f
   ```

#### Local Development Setup

1. **Backend Setup**
   ```bash
   cd backend
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   export FLASK_APP=app/main.py
   flask run --host=0.0.0.0 --port=5000
   ```

2. **Frontend Setup**
   ```bash
   cd frontend
   npm install
   npm start
   ```

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `FLASK_ENV` | Flask environment | `production` |
| `SECRET_KEY` | Flask secret key | Required |
| `DATABASE_URL` | Database connection | `sqlite:///data/queencalifia.db` |
| `REDIS_URL` | Redis connection | `redis://redis:6379/0` |
| `IBM_QUANTUM_TOKEN` | IBM Quantum token | Optional |
| `LOG_LEVEL` | Logging level | `INFO` |

### Quantum Computing Setup

1. **IBM Quantum Account**
   - Sign up at https://quantum-computing.ibm.com/
   - Get your API token
   - Set `IBM_QUANTUM_TOKEN` in environment

2. **Local Simulation**
   - Uses Qiskit Aer simulator by default
   - No additional setup required

## 📊 Monitoring and Maintenance

### Health Checks
- Backend: `curl http://localhost:5000/api/health`
- Frontend: `curl http://localhost:3000/health`

### Logs
```bash
# View all logs
docker-compose logs -f

# View specific service logs
docker-compose logs -f backend
docker-compose logs -f frontend
```

### Backup
```bash
# Backup database
docker-compose exec backend python -c "
import sqlite3
import shutil
shutil.copy('/app/data/queencalifia.db', '/app/data/backup.db')
"
```

### Updates
```bash
# Pull latest changes
git pull origin main

# Rebuild and restart
docker-compose down
docker-compose up --build -d
```

## 🔒 Security

### Production Checklist
- [ ] Change default SECRET_KEY
- [ ] Set up HTTPS/TLS
- [ ] Configure firewall rules
- [ ] Set up monitoring and alerting
- [ ] Regular security updates
- [ ] Backup strategy

### API Security
- Rate limiting enabled
- CORS configured
- Input validation
- Error handling

## 🐛 Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   # Check what's using the port
   lsof -i :5000
   # Kill the process or change port in docker-compose.yml
   ```

2. **Memory Issues**
   ```bash
   # Increase Docker memory limit
   # Check system resources
   docker stats
   ```

3. **Database Connection Issues**
   ```bash
   # Reset database
   docker-compose down -v
   docker-compose up --build -d
   ```

4. **Quantum Module Issues**
   ```bash
   # Check Qiskit installation
   docker-compose exec backend python -c "import qiskit; print(qiskit.__version__)"
   ```

### Performance Optimization

1. **Scaling**
   ```yaml
   # In docker-compose.yml
   backend:
     deploy:
       replicas: 3
   ```

2. **Caching**
   - Redis caching enabled
   - Static file caching
   - API response caching

3. **Database Optimization**
   - Use PostgreSQL for production
   - Enable connection pooling
   - Regular maintenance

## 📈 Monitoring

### Metrics Available
- System health status
- API response times
- Quantum circuit execution times
- Neural network performance
- Smart city simulation metrics

### Integration Options
- Prometheus metrics endpoint
- Grafana dashboards
- Custom monitoring hooks

## 🔄 CI/CD Integration

### GitHub Actions Example
```yaml
name: Deploy QueenCalifia
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy
        run: ./scripts/deploy.sh
```

### Testing
```bash
# Run all tests
./scripts/test.sh

# Run specific test suites
docker-compose exec backend python -m pytest tests/
```

## 📞 Support

For issues and questions:
- Check the troubleshooting section
- Review logs for error messages
- Create an issue in the repository
- Contact the development team

## 🔄 Updates and Maintenance

### Regular Maintenance
- Weekly: Check logs and performance
- Monthly: Update dependencies
- Quarterly: Security audit
- Annually: Architecture review

### Version Updates
1. Check release notes
2. Test in staging environment
3. Backup production data
4. Deploy with rollback plan
5. Monitor post-deployment

