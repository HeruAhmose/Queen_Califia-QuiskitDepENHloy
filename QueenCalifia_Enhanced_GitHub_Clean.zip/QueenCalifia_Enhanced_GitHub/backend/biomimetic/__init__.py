"""
QueenCalifia Biomimetic Neural Networks Module
Spider web and mycelium-inspired adaptive neural architectures
"""

from .biomimetic_networks import (
    BiomimeticNetwork,
    SpiderWebNetwork,
    MyceliumNetwork,
    EnsembleBiomimeticNetwork,
    NetworkMetrics,
    create_biomimetic_network
)

__version__ = "1.0.0"
__author__ = "QueenCalifia Development Team"

# Quick access functions
def create_spider_web_network(input_shape, output_shape, **kwargs):
    """Create a spider web network with default parameters"""
    return SpiderWebNetwork(input_shape, output_shape, **kwargs)

def create_mycelium_network(input_shape, output_shape, **kwargs):
    """Create a mycelium network with default parameters"""
    return MyceliumNetwork(input_shape, output_shape, **kwargs)

def create_ensemble_network(input_shape, output_shape, **kwargs):
    """Create an ensemble biomimetic network"""
    return EnsembleBiomimeticNetwork(input_shape, output_shape, **kwargs)

__all__ = [
    'BiomimeticNetwork',
    'SpiderWebNetwork', 
    'MyceliumNetwork',
    'EnsembleBiomimeticNetwork',
    'NetworkMetrics',
    'create_biomimetic_network',
    'create_spider_web_network',
    'create_mycelium_network',
    'create_ensemble_network'
]

