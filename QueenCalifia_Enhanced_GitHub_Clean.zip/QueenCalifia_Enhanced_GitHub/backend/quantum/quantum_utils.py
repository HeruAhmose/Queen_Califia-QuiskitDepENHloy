"""
QueenCalifia Quantum Utilities
Helper functions and utilities for quantum computing operations
"""

import numpy as np
from typing import List, Dict, Any, Optional, Tuple, Union
import logging
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector, DensityMatrix, partial_trace
from qiskit.visualization import plot_histogram
import matplotlib.pyplot as plt
from io import BytesIO
import base64

logger = logging.getLogger(__name__)

class QuantumMetrics:
    """Quantum computation metrics and analysis"""
    
    @staticmethod
    def calculate_fidelity(state1: Statevector, state2: Statevector) -> float:
        """Calculate fidelity between two quantum states"""
        try:
            fidelity = abs(state1.inner(state2))**2
            return float(fidelity)
        except Exception as e:
            logger.error(f"Error calculating fidelity: {e}")
            return 0.0
    
    @staticmethod
    def calculate_entanglement_entropy(state: Statevector, subsystem_qubits: List[int]) -> float:
        """Calculate entanglement entropy of a subsystem"""
        try:
            # Convert to density matrix
            rho = DensityMatrix(state)
            
            # Partial trace over subsystem
            rho_sub = partial_trace(rho, subsystem_qubits)
            
            # Calculate von Neumann entropy
            eigenvals = np.linalg.eigvals(rho_sub.data)
            eigenvals = eigenvals[eigenvals > 1e-12]  # Remove numerical zeros
            entropy = -np.sum(eigenvals * np.log2(eigenvals))
            
            return float(entropy)
        except Exception as e:
            logger.error(f"Error calculating entanglement entropy: {e}")
            return 0.0
    
    @staticmethod
    def calculate_circuit_metrics(circuit: QuantumCircuit) -> Dict[str, Any]:
        """Calculate various metrics for a quantum circuit"""
        try:
            metrics = {
                'depth': circuit.depth(),
                'width': circuit.width(),
                'size': circuit.size(),
                'num_qubits': circuit.num_qubits,
                'num_clbits': circuit.num_clbits,
                'gate_counts': dict(circuit.count_ops()),
                'num_parameters': circuit.num_parameters
            }
            
            # Calculate gate density
            if circuit.depth() > 0:
                metrics['gate_density'] = circuit.size() / circuit.depth()
            else:
                metrics['gate_density'] = 0
            
            return metrics
        except Exception as e:
            logger.error(f"Error calculating circuit metrics: {e}")
            return {}

class QuantumVisualization:
    """Quantum state and circuit visualization utilities"""
    
    @staticmethod
    def create_histogram_plot(counts: Dict[str, int], title: str = "Quantum Measurement Results") -> str:
        """Create histogram plot and return as base64 encoded string"""
        try:
            plt.figure(figsize=(10, 6))
            
            # Sort by state value for consistent ordering
            sorted_items = sorted(counts.items(), key=lambda x: x[0] if isinstance(x[0], str) else str(x[0]))
            states, values = zip(*sorted_items) if sorted_items else ([], [])
            
            plt.bar(range(len(states)), values)
            plt.xlabel('Quantum States')
            plt.ylabel('Counts')
            plt.title(title)
            plt.xticks(range(len(states)), states, rotation=45)
            plt.tight_layout()
            
            # Convert to base64
            buffer = BytesIO()
            plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
            buffer.seek(0)
            plot_data = base64.b64encode(buffer.getvalue()).decode()
            plt.close()
            
            return plot_data
        except Exception as e:
            logger.error(f"Error creating histogram plot: {e}")
            return ""
    
    @staticmethod
    def create_bloch_sphere_data(state: Statevector) -> Dict[str, Any]:
        """Create Bloch sphere representation data for single qubit states"""
        try:
            if state.num_qubits != 1:
                raise ValueError("Bloch sphere visualization only supports single qubit states")
            
            # Get state vector components
            alpha, beta = state.data
            
            # Calculate Bloch sphere coordinates
            x = 2 * np.real(alpha * np.conj(beta))
            y = 2 * np.imag(alpha * np.conj(beta))
            z = np.abs(alpha)**2 - np.abs(beta)**2
            
            return {
                'x': float(x),
                'y': float(y),
                'z': float(z),
                'alpha': complex(alpha),
                'beta': complex(beta)
            }
        except Exception as e:
            logger.error(f"Error creating Bloch sphere data: {e}")
            return {'x': 0, 'y': 0, 'z': 1, 'alpha': 1, 'beta': 0}

class QuantumDataEncoder:
    """Utilities for encoding classical data into quantum states"""
    
    @staticmethod
    def amplitude_encoding(data: np.ndarray, num_qubits: int) -> np.ndarray:
        """Encode classical data as quantum state amplitudes"""
        try:
            # Normalize data
            data = np.array(data, dtype=complex)
            norm = np.linalg.norm(data)
            if norm > 0:
                data = data / norm
            
            # Pad or truncate to fit 2^num_qubits amplitudes
            target_size = 2**num_qubits
            if len(data) > target_size:
                data = data[:target_size]
            elif len(data) < target_size:
                data = np.pad(data, (0, target_size - len(data)), 'constant')
            
            return data
        except Exception as e:
            logger.error(f"Error in amplitude encoding: {e}")
            return np.array([1] + [0] * (2**num_qubits - 1), dtype=complex)
    
    @staticmethod
    def angle_encoding(data: np.ndarray, scaling_factor: float = np.pi) -> np.ndarray:
        """Encode classical data as rotation angles"""
        try:
            # Normalize to [0, 1] range
            data = np.array(data)
            data_min, data_max = np.min(data), np.max(data)
            if data_max > data_min:
                data = (data - data_min) / (data_max - data_min)
            
            # Scale to desired range
            angles = data * scaling_factor
            
            return angles
        except Exception as e:
            logger.error(f"Error in angle encoding: {e}")
            return np.zeros_like(data)
    
    @staticmethod
    def basis_encoding(data: List[int], num_qubits: int) -> str:
        """Encode classical binary data as computational basis state"""
        try:
            # Convert to binary string
            binary_data = [str(int(x)) for x in data]
            
            # Pad or truncate to num_qubits
            if len(binary_data) > num_qubits:
                binary_data = binary_data[:num_qubits]
            elif len(binary_data) < num_qubits:
                binary_data = ['0'] * (num_qubits - len(binary_data)) + binary_data
            
            return ''.join(binary_data)
        except Exception as e:
            logger.error(f"Error in basis encoding: {e}")
            return '0' * num_qubits

class QuantumCircuitBuilder:
    """Advanced quantum circuit construction utilities"""
    
    @staticmethod
    def create_qft_circuit(num_qubits: int) -> QuantumCircuit:
        """Create Quantum Fourier Transform circuit"""
        qc = QuantumCircuit(num_qubits)
        
        for i in range(num_qubits):
            qc.h(i)
            for j in range(i + 1, num_qubits):
                qc.cp(np.pi / (2**(j - i)), j, i)
        
        # Reverse qubit order
        for i in range(num_qubits // 2):
            qc.swap(i, num_qubits - 1 - i)
        
        return qc
    
    @staticmethod
    def create_grover_circuit(num_qubits: int, marked_states: List[str]) -> QuantumCircuit:
        """Create Grover's search algorithm circuit"""
        qc = QuantumCircuit(num_qubits)
        
        # Initialize superposition
        for i in range(num_qubits):
            qc.h(i)
        
        # Number of iterations
        num_iterations = int(np.pi / 4 * np.sqrt(2**num_qubits))
        
        for _ in range(num_iterations):
            # Oracle for marked states
            for state in marked_states:
                # Apply oracle (simplified implementation)
                qc.z(0)  # Placeholder for oracle
            
            # Diffusion operator
            for i in range(num_qubits):
                qc.h(i)
                qc.x(i)
            
            qc.h(num_qubits - 1)
            qc.mcx(list(range(num_qubits - 1)), num_qubits - 1)
            qc.h(num_qubits - 1)
            
            for i in range(num_qubits):
                qc.x(i)
                qc.h(i)
        
        qc.measure_all()
        return qc
    
    @staticmethod
    def create_variational_ansatz(num_qubits: int, num_layers: int, entanglement: str = 'linear') -> QuantumCircuit:
        """Create variational ansatz circuit"""
        from qiskit.circuit import ParameterVector
        
        # Parameters for rotation gates
        theta = ParameterVector('theta', num_layers * num_qubits * 3)
        
        qc = QuantumCircuit(num_qubits)
        param_idx = 0
        
        for layer in range(num_layers):
            # Rotation layer
            for qubit in range(num_qubits):
                qc.ry(theta[param_idx], qubit)
                param_idx += 1
                qc.rz(theta[param_idx], qubit)
                param_idx += 1
                qc.ry(theta[param_idx], qubit)
                param_idx += 1
            
            # Entanglement layer
            if entanglement == 'linear':
                for i in range(num_qubits - 1):
                    qc.cx(i, i + 1)
            elif entanglement == 'circular':
                for i in range(num_qubits - 1):
                    qc.cx(i, i + 1)
                if num_qubits > 2:
                    qc.cx(num_qubits - 1, 0)
            elif entanglement == 'full':
                for i in range(num_qubits):
                    for j in range(i + 1, num_qubits):
                        qc.cx(i, j)
        
        return qc

class QuantumNoiseModel:
    """Quantum noise modeling and simulation utilities"""
    
    @staticmethod
    def add_depolarizing_noise(circuit: QuantumCircuit, error_rate: float = 0.01) -> QuantumCircuit:
        """Add depolarizing noise to quantum circuit"""
        # This is a simplified implementation
        # In practice, you would use Qiskit Aer noise models
        noisy_circuit = circuit.copy()
        
        # Add random Pauli errors (simplified)
        for i in range(circuit.num_qubits):
            if np.random.random() < error_rate:
                noise_type = np.random.choice(['x', 'y', 'z'])
                if noise_type == 'x':
                    noisy_circuit.x(i)
                elif noise_type == 'y':
                    noisy_circuit.y(i)
                elif noise_type == 'z':
                    noisy_circuit.z(i)
        
        return noisy_circuit
    
    @staticmethod
    def estimate_error_rate(ideal_counts: Dict[str, int], noisy_counts: Dict[str, int]) -> float:
        """Estimate error rate by comparing ideal and noisy results"""
        try:
            total_shots = sum(ideal_counts.values())
            error_count = 0
            
            for state in ideal_counts:
                ideal_prob = ideal_counts[state] / total_shots
                noisy_prob = noisy_counts.get(state, 0) / total_shots
                error_count += abs(ideal_prob - noisy_prob) * total_shots
            
            return error_count / (2 * total_shots)  # Normalized error rate
        except Exception as e:
            logger.error(f"Error estimating error rate: {e}")
            return 0.0

class QuantumBenchmark:
    """Quantum computing benchmarking utilities"""
    
    @staticmethod
    def quantum_volume_circuit(num_qubits: int, depth: int) -> QuantumCircuit:
        """Create quantum volume benchmark circuit"""
        qc = QuantumCircuit(num_qubits)
        
        for layer in range(depth):
            # Random SU(4) gates on random qubit pairs
            available_qubits = list(range(num_qubits))
            np.random.shuffle(available_qubits)
            
            for i in range(0, len(available_qubits) - 1, 2):
                q1, q2 = available_qubits[i], available_qubits[i + 1]
                
                # Random unitary (simplified with random rotations)
                angles = np.random.random(6) * 2 * np.pi
                qc.ry(angles[0], q1)
                qc.rz(angles[1], q1)
                qc.ry(angles[2], q2)
                qc.rz(angles[3], q2)
                qc.cx(q1, q2)
                qc.ry(angles[4], q1)
                qc.ry(angles[5], q2)
        
        qc.measure_all()
        return qc
    
    @staticmethod
    def randomized_benchmarking_circuit(num_qubits: int, sequence_length: int) -> QuantumCircuit:
        """Create randomized benchmarking circuit"""
        qc = QuantumCircuit(num_qubits)
        
        # Random Clifford gates (simplified implementation)
        clifford_gates = ['h', 's', 'x', 'y', 'z']
        
        for _ in range(sequence_length):
            for qubit in range(num_qubits):
                gate = np.random.choice(clifford_gates)
                if gate == 'h':
                    qc.h(qubit)
                elif gate == 's':
                    qc.s(qubit)
                elif gate == 'x':
                    qc.x(qubit)
                elif gate == 'y':
                    qc.y(qubit)
                elif gate == 'z':
                    qc.z(qubit)
        
        qc.measure_all()
        return qc

# Utility functions
def optimize_circuit_depth(circuit: QuantumCircuit) -> QuantumCircuit:
    """Optimize quantum circuit to reduce depth"""
    from qiskit import transpile
    from qiskit_aer import Aer
    
    try:
        backend = Aer.get_backend('aer_simulator')
        optimized_circuit = transpile(circuit, backend, optimization_level=3)
        return optimized_circuit
    except Exception as e:
        logger.error(f"Error optimizing circuit: {e}")
        return circuit

def validate_quantum_state(state_vector: np.ndarray) -> bool:
    """Validate if a state vector represents a valid quantum state"""
    try:
        # Check normalization
        norm = np.linalg.norm(state_vector)
        if not np.isclose(norm, 1.0, atol=1e-10):
            return False
        
        # Check if all amplitudes are finite
        if not np.all(np.isfinite(state_vector)):
            return False
        
        return True
    except Exception:
        return False

def quantum_state_tomography_data(circuit: QuantumCircuit, num_shots: int = 1024) -> Dict[str, Any]:
    """Generate data for quantum state tomography"""
    try:
        from qiskit_aer import Aer
        from qiskit.primitives import BackendSamplerV2
        
        backend = Aer.get_backend('aer_simulator')
        sampler = BackendSamplerV2(backend=backend)
        
        # Measurement bases for tomography
        bases = ['Z', 'X', 'Y']
        tomography_data = {}
        
        for basis in bases:
            # Create measurement circuit
            meas_circuit = circuit.copy()
            
            for qubit in range(circuit.num_qubits):
                if basis == 'X':
                    meas_circuit.ry(-np.pi/2, qubit)
                elif basis == 'Y':
                    meas_circuit.rx(np.pi/2, qubit)
                # Z basis requires no additional gates
            
            if not meas_circuit.cregs:
                meas_circuit.measure_all()
            
            # Execute measurement
            job = sampler.run([meas_circuit], shots=num_shots)
            result = job.result()
            counts = result[0].data.meas.get_counts()
            
            tomography_data[basis] = counts
        
        return {
            'success': True,
            'tomography_data': tomography_data,
            'num_shots': num_shots
        }
    except Exception as e:
        logger.error(f"Error in quantum state tomography: {e}")
        return {
            'success': False,
            'error': str(e)
        }

# Export all utility classes and functions
__all__ = [
    'QuantumMetrics',
    'QuantumVisualization', 
    'QuantumDataEncoder',
    'QuantumCircuitBuilder',
    'QuantumNoiseModel',
    'QuantumBenchmark',
    'optimize_circuit_depth',
    'validate_quantum_state',
    'quantum_state_tomography_data'
]

