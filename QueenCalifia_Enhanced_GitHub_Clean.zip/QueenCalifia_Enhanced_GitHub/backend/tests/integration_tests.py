"""
QueenCalifia Integration Test Suite
Comprehensive testing for all system components
"""

import sys
import os
import unittest
import requests
import time
import json
import subprocess
import threading
from datetime import datetime

# Add backend modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

class QueenCalifiaIntegrationTests(unittest.TestCase):
    """Integration tests for the complete QueenCalifia system"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment"""
        cls.base_url = "http://localhost:5000"
        cls.api_url = f"{cls.base_url}/api"
        cls.server_process = None
        cls.server_started = False
        
        print("Starting QueenCalifia server for testing...")
        cls._start_server()
        
        # Wait for server to start
        max_retries = 30
        for i in range(max_retries):
            try:
                response = requests.get(f"{cls.api_url}/health", timeout=5)
                if response.status_code == 200:
                    cls.server_started = True
                    print("Server started successfully!")
                    break
            except requests.exceptions.RequestException:
                pass
            
            time.sleep(2)
            print(f"Waiting for server... ({i+1}/{max_retries})")
        
        if not cls.server_started:
            raise Exception("Failed to start server for testing")
    
    @classmethod
    def _start_server(cls):
        """Start the Flask server in a separate process"""
        try:
            # Change to backend directory
            backend_dir = os.path.join(os.path.dirname(__file__), '..', 'app')
            
            # Start server
            cls.server_process = subprocess.Popen(
                [sys.executable, 'main.py'],
                cwd=backend_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env={**os.environ, 'FLASK_ENV': 'testing'}
            )
            
            # Give server time to start
            time.sleep(5)
            
        except Exception as e:
            print(f"Error starting server: {e}")
            raise
    
    @classmethod
    def tearDownClass(cls):
        """Clean up test environment"""
        if cls.server_process:
            cls.server_process.terminate()
            cls.server_process.wait()
            print("Server stopped.")
    
    def test_01_health_check(self):
        """Test basic health check endpoint"""
        response = requests.get(f"{self.api_url}/health")
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertEqual(data['status'], 'healthy')
        self.assertIn('timestamp', data)
        self.assertIn('system_status', data)
        
        print("✅ Health check passed")
    
    def test_02_system_status(self):
        """Test system status endpoint"""
        response = requests.get(f"{self.api_url}/status")
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertIn('system_status', data)
        self.assertIn('components', data)
        self.assertIn('last_update', data)
        
        # Check that components are present
        components = data['components']
        expected_components = ['quantum', 'biomimetic', 'smart_city']
        
        for component in expected_components:
            self.assertIn(component, components)
        
        print("✅ System status check passed")
    
    def test_03_quantum_execution(self):
        """Test quantum circuit execution"""
        test_data = {
            'circuit_type': 'basic',
            'parameters': {
                'num_qubits': 3,
                'shots': 1024
            }
        }
        
        response = requests.post(
            f"{self.api_url}/quantum/execute",
            json=test_data,
            headers={'Content-Type': 'application/json'}
        )
        
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertTrue(data.get('success', False))
        self.assertEqual(data['circuit_type'], 'basic')
        self.assertIn('result', data)
        self.assertIn('timestamp', data)
        
        print("✅ Quantum execution test passed")
    
    def test_04_quantum_neural_network(self):
        """Test quantum neural network execution"""
        test_data = {
            'circuit_type': 'neural_network',
            'parameters': {
                'input_data': [0.5, 0.3, 0.8, 0.2],
                'num_qubits': 4,
                'num_layers': 2
            }
        }
        
        response = requests.post(
            f"{self.api_url}/quantum/execute",
            json=test_data,
            headers={'Content-Type': 'application/json'}
        )
        
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertTrue(data.get('success', False))
        self.assertEqual(data['circuit_type'], 'neural_network')
        
        print("✅ Quantum neural network test passed")
    
    def test_05_biomimetic_prediction(self):
        """Test biomimetic network prediction"""
        test_data = {
            'network_type': 'ensemble',
            'input_data': [0.5, 0.3, 0.8, 0.2, 0.6, 0.9, 0.1, 0.7, 0.4, 0.5]
        }
        
        response = requests.post(
            f"{self.api_url}/biomimetic/predict",
            json=test_data,
            headers={'Content-Type': 'application/json'}
        )
        
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertTrue(data.get('success', False))
        self.assertEqual(data['network_type'], 'ensemble')
        self.assertIn('prediction', data)
        self.assertIn('metrics', data)
        
        print("✅ Biomimetic prediction test passed")
    
    def test_06_biomimetic_training(self):
        """Test biomimetic network training"""
        test_data = {
            'network_type': 'spider_web',
            'training_data': [[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]] * 10,
            'training_labels': [0.5] * 10,
            'epochs': 5
        }
        
        response = requests.post(
            f"{self.api_url}/biomimetic/train",
            json=test_data,
            headers={'Content-Type': 'application/json'}
        )
        
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertTrue(data.get('success', False))
        self.assertEqual(data['network_type'], 'spider_web')
        self.assertIn('training_metrics', data)
        
        print("✅ Biomimetic training test passed")
    
    def test_07_smart_city_status(self):
        """Test smart city status endpoint"""
        response = requests.get(f"{self.api_url}/smartcity/status")
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertIn('orchestrator_status', data)
        self.assertIn('systems', data)
        
        print("✅ Smart city status test passed")
    
    def test_08_smart_city_simulation(self):
        """Test smart city data simulation"""
        response = requests.post(
            f"{self.api_url}/smartcity/simulate",
            json={},
            headers={'Content-Type': 'application/json'}
        )
        
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertTrue(data.get('success', False))
        self.assertIn('simulated_data', data)
        
        print("✅ Smart city simulation test passed")
    
    def test_09_smart_city_optimization(self):
        """Test smart city optimization"""
        response = requests.post(
            f"{self.api_url}/smartcity/optimize",
            json={'systems': ['energy', 'traffic']},
            headers={'Content-Type': 'application/json'}
        )
        
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertTrue(data.get('success', False))
        self.assertIn('optimization_results', data)
        
        print("✅ Smart city optimization test passed")
    
    def test_10_hybrid_analysis(self):
        """Test hybrid quantum-classical analysis"""
        test_data = {
            'analysis_type': 'comprehensive',
            'input_data': [0.5, 0.3, 0.8, 0.2, 0.6, 0.9, 0.1, 0.7, 0.4, 0.5]
        }
        
        response = requests.post(
            f"{self.api_url}/hybrid/analyze",
            json=test_data,
            headers={'Content-Type': 'application/json'}
        )
        
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertTrue(data.get('success', False))
        self.assertEqual(data['analysis_type'], 'comprehensive')
        self.assertIn('results', data)
        
        print("✅ Hybrid analysis test passed")
    
    def test_11_api_documentation(self):
        """Test API documentation endpoint"""
        response = requests.get(f"{self.api_url}/docs")
        self.assertEqual(response.status_code, 200)
        
        data = response.json()
        self.assertIn('title', data)
        self.assertIn('endpoints', data)
        self.assertIn('version', data)
        
        print("✅ API documentation test passed")
    
    def test_12_frontend_accessibility(self):
        """Test that frontend is accessible"""
        response = requests.get(self.base_url)
        self.assertEqual(response.status_code, 200)
        
        # Check that it's HTML content
        self.assertIn('text/html', response.headers.get('content-type', ''))
        
        # Check for QueenCalifia in content
        content = response.text
        self.assertIn('QueenCalifia', content)
        
        print("✅ Frontend accessibility test passed")
    
    def test_13_error_handling(self):
        """Test error handling for invalid requests"""
        # Test invalid endpoint
        response = requests.get(f"{self.api_url}/invalid-endpoint")
        self.assertEqual(response.status_code, 404)
        
        # Test invalid JSON
        response = requests.post(
            f"{self.api_url}/quantum/execute",
            data="invalid json",
            headers={'Content-Type': 'application/json'}
        )
        self.assertEqual(response.status_code, 400)
        
        print("✅ Error handling test passed")
    
    def test_14_performance_benchmark(self):
        """Basic performance benchmark"""
        start_time = time.time()
        
        # Run multiple requests
        for i in range(5):
            response = requests.get(f"{self.api_url}/health")
            self.assertEqual(response.status_code, 200)
        
        end_time = time.time()
        avg_response_time = (end_time - start_time) / 5
        
        # Should respond within reasonable time
        self.assertLess(avg_response_time, 1.0)  # Less than 1 second average
        
        print(f"✅ Performance benchmark passed (avg: {avg_response_time:.3f}s)")
    
    def test_15_concurrent_requests(self):
        """Test handling of concurrent requests"""
        import threading
        import queue
        
        results = queue.Queue()
        
        def make_request():
            try:
                response = requests.get(f"{self.api_url}/health", timeout=10)
                results.put(response.status_code)
            except Exception as e:
                results.put(str(e))
        
        # Start multiple threads
        threads = []
        for i in range(10):
            thread = threading.Thread(target=make_request)
            threads.append(thread)
            thread.start()
        
        # Wait for all threads
        for thread in threads:
            thread.join()
        
        # Check results
        success_count = 0
        while not results.empty():
            result = results.get()
            if result == 200:
                success_count += 1
        
        # At least 80% should succeed
        self.assertGreaterEqual(success_count, 8)
        
        print(f"✅ Concurrent requests test passed ({success_count}/10 successful)")

class ComponentUnitTests(unittest.TestCase):
    """Unit tests for individual components"""
    
    def test_quantum_core_import(self):
        """Test quantum core module import"""
        try:
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'quantum'))
            from quantum_core import QuantumCore
            
            # Try to create instance
            qc = QuantumCore()
            self.assertIsNotNone(qc)
            
            print("✅ Quantum core import test passed")
        except ImportError as e:
            self.skipTest(f"Quantum core not available: {e}")
    
    def test_biomimetic_import(self):
        """Test biomimetic module import"""
        try:
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'biomimetic'))
            from biomimetic_networks import create_biomimetic_network
            
            # Try to create network
            network = create_biomimetic_network('spider_web', (10,), 1)
            self.assertIsNotNone(network)
            
            print("✅ Biomimetic import test passed")
        except ImportError as e:
            self.skipTest(f"Biomimetic module not available: {e}")
    
    def test_smart_city_import(self):
        """Test smart city module import"""
        try:
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'smartcity'))
            from smart_city_infrastructure import SmartCityOrchestrator
            
            # Try to create orchestrator
            orchestrator = SmartCityOrchestrator()
            self.assertIsNotNone(orchestrator)
            
            print("✅ Smart city import test passed")
        except ImportError as e:
            self.skipTest(f"Smart city module not available: {e}")

def run_tests():
    """Run all tests and generate report"""
    print("=" * 60)
    print("QueenCalifia Integration Test Suite")
    print("=" * 60)
    print(f"Test started at: {datetime.now()}")
    print()
    
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test classes
    suite.addTests(loader.loadTestsFromTestCase(ComponentUnitTests))
    suite.addTests(loader.loadTestsFromTestCase(QueenCalifiaIntegrationTests))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
    result = runner.run(suite)
    
    # Generate summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Skipped: {len(result.skipped) if hasattr(result, 'skipped') else 0}")
    
    if result.failures:
        print("\nFAILURES:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback}")
    
    if result.errors:
        print("\nERRORS:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback}")
    
    success_rate = ((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100) if result.testsRun > 0 else 0
    print(f"\nSuccess Rate: {success_rate:.1f}%")
    
    if success_rate >= 90:
        print("🎉 EXCELLENT! System is ready for deployment!")
    elif success_rate >= 75:
        print("✅ GOOD! Minor issues may need attention.")
    else:
        print("⚠️  WARNING! Significant issues detected.")
    
    print(f"\nTest completed at: {datetime.now()}")
    
    return result.wasSuccessful()

if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1)

