#!/bin/bash
# QueenCalifia Enhanced One-Click Deployment Script
# Revolutionary quantum intelligence portal with full personality and emotions

set -e  # Exit on any error

echo "🚀 QueenCalifia Enhanced Deployment Starting..."
echo "=================================================="
echo "🌟 Deploying Revolutionary Quantum Intelligence Portal"
echo "💫 With Full Personality, Emotions & Comprehensive Knowledge"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_quantum() {
    echo -e "${PURPLE}[QUANTUM]${NC} $1"
}

# Check system requirements
print_status "Checking system requirements..."

# Check Python
if ! command -v python3 &> /dev/null; then
    print_error "Python 3 is required but not installed"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
if [[ $(echo "$PYTHON_VERSION < 3.8" | bc -l) -eq 1 ]]; then
    print_error "Python 3.8+ is required, found $PYTHON_VERSION"
    exit 1
fi

print_success "Python $PYTHON_VERSION found"

# Check Node.js
if ! command -v node &> /dev/null; then
    print_warning "Node.js not found, frontend features will be limited"
    NODE_AVAILABLE=false
else
    NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [[ $NODE_VERSION -lt 16 ]]; then
        print_warning "Node.js 16+ recommended, found v$NODE_VERSION"
    else
        print_success "Node.js v$NODE_VERSION found"
    fi
    NODE_AVAILABLE=true
fi

# Create virtual environment
print_status "Setting up Python virtual environment..."
cd backend

if [ ! -d "venv" ]; then
    python3 -m venv venv
    print_success "Virtual environment created"
else
    print_status "Virtual environment already exists"
fi

# Activate virtual environment
source venv/bin/activate
print_success "Virtual environment activated"

# Install Python dependencies
print_status "Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

print_success "Python dependencies installed"

# Install quantum computing dependencies
print_quantum "Installing quantum computing framework..."
pip install qiskit qiskit-aer qiskit-ibm-runtime
print_success "Qiskit quantum framework installed"

# Install additional AI/ML dependencies
print_status "Installing AI/ML dependencies..."
pip install numpy scipy matplotlib pandas scikit-learn
print_success "AI/ML dependencies installed"

# Setup environment variables
print_status "Setting up environment configuration..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    print_success "Environment file created from template"
    print_warning "Please edit .env file with your API keys and configuration"
else
    print_status "Environment file already exists"
fi

# Test backend startup
print_status "Testing backend startup..."
timeout 10s python app/main.py &
BACKEND_PID=$!
sleep 5

if kill -0 $BACKEND_PID 2>/dev/null; then
    print_success "Backend started successfully"
    kill $BACKEND_PID
else
    print_warning "Backend startup test completed (may need configuration)"
fi

# Setup frontend if Node.js is available
if [ "$NODE_AVAILABLE" = true ]; then
    print_status "Setting up frontend..."
    cd ../frontend
    
    if [ ! -d "node_modules" ]; then
        npm install
        print_success "Frontend dependencies installed"
    else
        print_status "Frontend dependencies already installed"
    fi
    
    # Build frontend
    print_status "Building frontend..."
    npm run build
    print_success "Frontend built successfully"
    
    cd ../backend
fi

# Create startup scripts
print_status "Creating startup scripts..."

# Backend startup script
cat > start_backend.sh << 'EOF'
#!/bin/bash
cd backend
source venv/bin/activate
echo "🚀 Starting QueenCalifia Enhanced Backend..."
echo "⚛️ Quantum Intelligence Portal with Full Personality"
echo "🌐 Access at: http://localhost:5000"
echo ""
python app/main.py
EOF

chmod +x start_backend.sh

# Frontend startup script (if Node.js available)
if [ "$NODE_AVAILABLE" = true ]; then
    cat > start_frontend.sh << 'EOF'
#!/bin/bash
cd frontend
echo "🎨 Starting QueenCalifia Enhanced Frontend..."
echo "✨ Revolutionary Quantum Interface"
echo "🌐 Access at: http://localhost:3000"
echo ""
npm start
EOF
    chmod +x start_frontend.sh
fi

# Full system startup script
cat > start_queencalifia.sh << 'EOF'
#!/bin/bash
echo "🌟 QueenCalifia Enhanced - Starting Full System"
echo "=============================================="
echo "🧠 AI Personality: Activating..."
echo "📚 Knowledge Engine: Loading..."
echo "⚛️ Quantum Core: Initializing..."
echo "🕷️ Neural Networks: Connecting..."
echo "🏙️ Smart City: Optimizing..."
echo ""

# Start backend
echo "🚀 Starting backend..."
cd backend
source venv/bin/activate
python app/main.py &
BACKEND_PID=$!

# Wait for backend to start
sleep 5

# Check if backend is running
if kill -0 $BACKEND_PID 2>/dev/null; then
    echo "✅ Backend running on http://localhost:5000"
    
    # Start frontend if available
    if [ -f "start_frontend.sh" ]; then
        echo "🎨 Starting frontend..."
        ./start_frontend.sh &
        FRONTEND_PID=$!
        echo "✅ Frontend running on http://localhost:3000"
    fi
    
    echo ""
    echo "🎉 QueenCalifia Enhanced is now running!"
    echo "💬 Chat with QueenCalifia at: http://localhost:5000"
    echo "🎛️ Full portal interface at: http://localhost:3000"
    echo ""
    echo "Press Ctrl+C to stop all services"
    
    # Wait for user interrupt
    trap 'echo ""; echo "🛑 Stopping QueenCalifia Enhanced..."; kill $BACKEND_PID 2>/dev/null; kill $FRONTEND_PID 2>/dev/null; exit 0' INT
    wait
else
    echo "❌ Failed to start backend"
    exit 1
fi
EOF

chmod +x start_queencalifia.sh

# Create test script
cat > test_system.sh << 'EOF'
#!/bin/bash
echo "🧪 Testing QueenCalifia Enhanced System"
echo "======================================"

cd backend
source venv/bin/activate

echo "🔍 Testing Python imports..."
python -c "
try:
    from app.queencalifia_personality import QueenCalifiaPersonality
    from app.queencalifia_knowledge import QueenCalifiaKnowledge
    print('✅ Personality and Knowledge systems imported successfully')
except ImportError as e:
    print(f'❌ Import error: {e}')

try:
    import qiskit
    print('✅ Qiskit quantum framework imported successfully')
except ImportError:
    print('⚠️ Qiskit not available (quantum features will be simulated)')

try:
    import flask
    print('✅ Flask web framework imported successfully')
except ImportError as e:
    print(f'❌ Flask import error: {e}')
"

echo ""
echo "🚀 Starting quick system test..."
timeout 15s python app/main.py &
TEST_PID=$!
sleep 5

if kill -0 $TEST_PID 2>/dev/null; then
    echo "✅ Backend startup test passed"
    
    # Test API endpoint
    if command -v curl &> /dev/null; then
        echo "🌐 Testing API endpoints..."
        HEALTH_RESPONSE=$(curl -s http://localhost:5000/api/health || echo "failed")
        if [[ $HEALTH_RESPONSE == *"healthy"* ]]; then
            echo "✅ Health endpoint responding"
        else
            echo "⚠️ Health endpoint test failed"
        fi
    fi
    
    kill $TEST_PID
    echo "✅ System test completed successfully"
else
    echo "❌ Backend startup test failed"
    exit 1
fi

echo ""
echo "🎉 QueenCalifia Enhanced is ready to deploy!"
echo "🚀 Run './start_queencalifia.sh' to start the full system"
EOF

chmod +x test_system.sh

# Run system test
print_status "Running system tests..."
./test_system.sh

echo ""
echo "🎉 QueenCalifia Enhanced Deployment Complete!"
echo "============================================="
echo ""
echo -e "${GREEN}✅ Backend:${NC} Quantum intelligence with full personality"
echo -e "${GREEN}✅ Frontend:${NC} Revolutionary interactive portal"
echo -e "${GREEN}✅ Quantum:${NC} IBM Qiskit integration ready"
echo -e "${GREEN}✅ AI:${NC} Comprehensive knowledge across all domains"
echo ""
echo -e "${CYAN}🚀 Quick Start:${NC}"
echo "   ./start_queencalifia.sh    # Start full system"
echo "   ./start_backend.sh         # Backend only"
echo "   ./test_system.sh           # Run tests"
echo ""
echo -e "${PURPLE}🌐 Access Points:${NC}"
echo "   Backend API: http://localhost:5000"
echo "   Chat Interface: http://localhost:5000"
if [ "$NODE_AVAILABLE" = true ]; then
    echo "   Full Portal: http://localhost:3000"
fi
echo ""
echo -e "${YELLOW}💡 Try asking QueenCalifia:${NC}"
echo '   "How are you feeling today?"'
echo '   "Explain quantum entanglement"'
echo '   "Help me with personal finance"'
echo '   "What are your thoughts on AI ethics?"'
echo ""
echo -e "${GREEN}🌟 Welcome to the future of AI interaction!${NC}"

