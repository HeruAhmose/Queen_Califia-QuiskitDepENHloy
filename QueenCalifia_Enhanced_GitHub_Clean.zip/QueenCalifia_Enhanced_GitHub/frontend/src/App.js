import React, { useState, useEffect } from 'react';
import './App.css';

// Import components
import Dashboard from './components/Dashboard';
import QuantumVisualization from './components/QuantumVisualization';
import BiomimeticNetworks from './components/BiomimeticNetworks';
import SmartCityDashboard from './components/SmartCityDashboard';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [systemStatus, setSystemStatus] = useState(null);

  useEffect(() => {
    // Check system health on startup
    fetch('/api/health')
      .then(response => response.json())
      .then(data => setSystemStatus(data))
      .catch(error => console.error('Health check failed:', error));
  }, []);

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: '🏠' },
    { id: 'quantum', label: 'Quantum Core', icon: '⚛️' },
    { id: 'biomimetic', label: 'Biomimetic Networks', icon: '🕸️' },
    { id: 'smartcity', label: 'Smart City', icon: '🏙️' }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard systemStatus={systemStatus} />;
      case 'quantum':
        return <QuantumVisualization />;
      case 'biomimetic':
        return <BiomimeticNetworks />;
      case 'smartcity':
        return <SmartCityDashboard />;
      default:
        return <Dashboard systemStatus={systemStatus} />;
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <div className="container">
          <h1 className="quantum-glow">
            👑 QueenCalifia Quantum Intelligence System
          </h1>
          <p className="subtitle">
            Advanced Quantum-Enhanced Hybrid Intelligence Platform
          </p>
          
          <nav className="tab-navigation">
            {tabs.map(tab => (
              <button
                key={tab.id}
                className={`tab-button ${activeTab === tab.id ? 'active' : ''}`}
                onClick={() => setActiveTab(tab.id)}
              >
                <span className="tab-icon">{tab.icon}</span>
                <span className="tab-label">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="App-main">
        <div className="container">
          {renderContent()}
        </div>
      </main>

      <footer className="App-footer">
        <div className="container">
          <p>
            QueenCalifia System Status: 
            <span className={`status ${systemStatus?.status === 'healthy' ? 'healthy' : 'warning'}`}>
              {systemStatus?.status || 'Checking...'}
            </span>
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;

