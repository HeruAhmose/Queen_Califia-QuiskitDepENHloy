import React, { useState, useEffect } from 'react';

const Dashboard = ({ systemStatus }) => {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await fetch('/api/metrics');
        const data = await response.json();
        setMetrics(data);
      } catch (error) {
        console.error('Failed to fetch metrics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchMetrics();
    const interval = setInterval(fetchMetrics, 5000); // Update every 5 seconds
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="card">
        <h2>🔄 Loading System Dashboard...</h2>
        <div className="loading-spinner">
          <div className="spinner"></div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="card quantum-glow">
        <h2>🎯 System Overview</h2>
        <div className="metrics-grid">
          <div className="metric-card">
            <h3>⚛️ Quantum Core</h3>
            <div className="metric-value">
              {systemStatus?.components?.quantum_core ? '✅ Active' : '⚠️ Initializing'}
            </div>
            <p>Quantum neural networks and optimization algorithms</p>
          </div>
          
          <div className="metric-card">
            <h3>🕸️ Biomimetic Networks</h3>
            <div className="metric-value">
              {systemStatus?.components?.biomimetic_networks ? '✅ Active' : '⚠️ Initializing'}
            </div>
            <p>Spider web and mycelium-inspired neural architectures</p>
          </div>
          
          <div className="metric-card">
            <h3>🏙️ Smart City</h3>
            <div className="metric-value">
              {systemStatus?.components?.smart_city_orchestrator ? '✅ Active' : '⚠️ Initializing'}
            </div>
            <p>Urban infrastructure optimization and management</p>
          </div>
        </div>
      </div>

      {metrics && (
        <div className="card">
          <h2>📊 Performance Metrics</h2>
          <div className="performance-grid">
            <div className="performance-item">
              <span className="label">Quantum Circuits Executed:</span>
              <span className="value">{metrics.quantum_executions || 0}</span>
            </div>
            <div className="performance-item">
              <span className="label">Neural Network Predictions:</span>
              <span className="value">{metrics.neural_predictions || 0}</span>
            </div>
            <div className="performance-item">
              <span className="label">Smart City Optimizations:</span>
              <span className="value">{metrics.city_optimizations || 0}</span>
            </div>
            <div className="performance-item">
              <span className="label">System Uptime:</span>
              <span className="value">{metrics.uptime || 'N/A'}</span>
            </div>
          </div>
        </div>
      )}

      <div className="card">
        <h2>🚀 Quick Actions</h2>
        <div className="action-buttons">
          <button className="action-btn quantum" onClick={() => window.location.hash = '#quantum'}>
            ⚛️ Run Quantum Test
          </button>
          <button className="action-btn biomimetic" onClick={() => window.location.hash = '#biomimetic'}>
            🕸️ Test Neural Networks
          </button>
          <button className="action-btn smartcity" onClick={() => window.location.hash = '#smartcity'}>
            🏙️ Optimize City Resources
          </button>
        </div>
      </div>

      <style jsx>{`
        .metrics-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 20px;
          margin-top: 20px;
        }
        
        .metric-card {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
          padding: 20px;
          text-align: center;
          border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .metric-card h3 {
          margin: 0 0 10px 0;
          font-size: 1.2rem;
        }
        
        .metric-value {
          font-size: 1.1rem;
          font-weight: bold;
          margin: 10px 0;
        }
        
        .performance-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 15px;
          margin-top: 20px;
        }
        
        .performance-item {
          display: flex;
          justify-content: space-between;
          padding: 10px;
          background: rgba(0, 0, 0, 0.05);
          border-radius: 5px;
        }
        
        .label {
          font-weight: 500;
        }
        
        .value {
          font-weight: bold;
          color: #667eea;
        }
        
        .action-buttons {
          display: flex;
          gap: 15px;
          justify-content: center;
          flex-wrap: wrap;
          margin-top: 20px;
        }
        
        .action-btn {
          padding: 12px 24px;
          border: none;
          border-radius: 8px;
          font-size: 1rem;
          font-weight: bold;
          cursor: pointer;
          transition: all 0.3s ease;
          color: white;
        }
        
        .action-btn.quantum {
          background: linear-gradient(45deg, #667eea, #764ba2);
        }
        
        .action-btn.biomimetic {
          background: linear-gradient(45deg, #f093fb, #f5576c);
        }
        
        .action-btn.smartcity {
          background: linear-gradient(45deg, #4facfe, #00f2fe);
        }
        
        .action-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .loading-spinner {
          display: flex;
          justify-content: center;
          margin: 20px 0;
        }
        
        .spinner {
          width: 40px;
          height: 40px;
          border: 4px solid rgba(102, 126, 234, 0.3);
          border-top: 4px solid #667eea;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default Dashboard;

