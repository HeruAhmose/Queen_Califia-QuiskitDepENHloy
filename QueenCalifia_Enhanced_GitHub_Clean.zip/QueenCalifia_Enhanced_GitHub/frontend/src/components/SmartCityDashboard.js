import React, { useState, useEffect } from 'react';

const SmartCityDashboard = () => {
  const [cityData, setCityData] = useState(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationResults, setOptimizationResults] = useState([]);

  useEffect(() => {
    fetchCityData();
    const interval = setInterval(fetchCityData, 10000); // Update every 10 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchCityData = async () => {
    try {
      const response = await fetch('/api/smart-city/status');
      const data = await response.json();
      setCityData(data);
    } catch (error) {
      console.error('Failed to fetch city data:', error);
    }
  };

  const optimizeEnergyGrid = async () => {
    setIsOptimizing(true);
    try {
      const response = await fetch('/api/smart-city/optimize-energy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          current_load: [85, 92, 78, 88, 95],
          renewable_sources: [45, 38, 52, 41, 49]
        })
      });
      const data = await response.json();
      setOptimizationResults(prev => [{ ...data, type: 'energy', timestamp: new Date() }, ...prev.slice(0, 4)]);
    } catch (error) {
      console.error('Energy optimization failed:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const optimizeTraffic = async () => {
    setIsOptimizing(true);
    try {
      const response = await fetch('/api/smart-city/optimize-traffic', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          traffic_density: [0.7, 0.8, 0.6, 0.9, 0.5],
          signal_timing: [30, 45, 35, 40, 25]
        })
      });
      const data = await response.json();
      setOptimizationResults(prev => [{ ...data, type: 'traffic', timestamp: new Date() }, ...prev.slice(0, 4)]);
    } catch (error) {
      console.error('Traffic optimization failed:', error);
    } finally {
      setIsOptimizing(false);
    }
  };

  return (
    <div>
      <div className="card quantum-glow">
        <h2>🏙️ Smart City Infrastructure</h2>
        <p>Quantum-optimized urban management and resource allocation</p>
        
        <div className="city-controls">
          <button 
            className="city-btn energy"
            onClick={optimizeEnergyGrid}
            disabled={isOptimizing}
          >
            {isOptimizing ? '🔄 Optimizing...' : '⚡ Optimize Energy Grid'}
          </button>
          
          <button 
            className="city-btn traffic"
            onClick={optimizeTraffic}
            disabled={isOptimizing}
          >
            {isOptimizing ? '🔄 Optimizing...' : '🚦 Optimize Traffic Flow'}
          </button>
        </div>
      </div>

      {cityData && (
        <div className="card">
          <h3>📊 Real-Time City Metrics</h3>
          <div className="metrics-dashboard">
            <div className="metric-section">
              <h4>⚡ Energy Management</h4>
              <div className="metric-grid">
                <div className="metric-item">
                  <span className="metric-label">Grid Load:</span>
                  <span className="metric-value">{cityData.energy?.grid_load || 'N/A'}%</span>
                </div>
                <div className="metric-item">
                  <span className="metric-label">Renewable:</span>
                  <span className="metric-value">{cityData.energy?.renewable_percentage || 'N/A'}%</span>
                </div>
                <div className="metric-item">
                  <span className="metric-label">Efficiency:</span>
                  <span className="metric-value">{cityData.energy?.efficiency || 'N/A'}%</span>
                </div>
              </div>
            </div>

            <div className="metric-section">
              <h4>🚦 Traffic Management</h4>
              <div className="metric-grid">
                <div className="metric-item">
                  <span className="metric-label">Avg Speed:</span>
                  <span className="metric-value">{cityData.traffic?.average_speed || 'N/A'} km/h</span>
                </div>
                <div className="metric-item">
                  <span className="metric-label">Congestion:</span>
                  <span className="metric-value">{cityData.traffic?.congestion_level || 'N/A'}%</span>
                </div>
                <div className="metric-item">
                  <span className="metric-label">Incidents:</span>
                  <span className="metric-value">{cityData.traffic?.incidents || 'N/A'}</span>
                </div>
              </div>
            </div>

            <div className="metric-section">
              <h4>🌱 Environmental</h4>
              <div className="metric-grid">
                <div className="metric-item">
                  <span className="metric-label">Air Quality:</span>
                  <span className="metric-value">{cityData.environment?.air_quality || 'N/A'}</span>
                </div>
                <div className="metric-item">
                  <span className="metric-label">Temperature:</span>
                  <span className="metric-value">{cityData.environment?.temperature || 'N/A'}°C</span>
                </div>
                <div className="metric-item">
                  <span className="metric-label">Humidity:</span>
                  <span className="metric-value">{cityData.environment?.humidity || 'N/A'}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {optimizationResults.length > 0 && (
        <div className="card">
          <h3>🎯 Optimization Results</h3>
          <div className="results-container">
            {optimizationResults.map((result, index) => (
              <div key={index} className="result-item">
                <div className="result-header">
                  <span className="result-type">
                    {result.type === 'energy' ? '⚡ Energy Grid Optimization' : '🚦 Traffic Flow Optimization'}
                  </span>
                  <span className="result-time">
                    {result.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                
                <div className="result-content">
                  {result.type === 'energy' ? (
                    <div>
                      <p><strong>Energy Savings:</strong> {result.energy_savings?.toFixed(2) || 'N/A'}%</p>
                      <p><strong>Load Balancing:</strong> {result.load_balance_improvement?.toFixed(2) || 'N/A'}%</p>
                      <p><strong>Renewable Integration:</strong> {result.renewable_integration?.toFixed(2) || 'N/A'}%</p>
                      <p><strong>Cost Reduction:</strong> ${result.cost_savings?.toFixed(2) || 'N/A'}/hour</p>
                    </div>
                  ) : (
                    <div>
                      <p><strong>Travel Time Reduction:</strong> {result.travel_time_reduction?.toFixed(2) || 'N/A'}%</p>
                      <p><strong>Congestion Relief:</strong> {result.congestion_improvement?.toFixed(2) || 'N/A'}%</p>
                      <p><strong>Fuel Savings:</strong> {result.fuel_savings?.toFixed(2) || 'N/A'}%</p>
                      <p><strong>Emission Reduction:</strong> {result.emission_reduction?.toFixed(2) || 'N/A'}%</p>
                    </div>
                  )}
                  <p><strong>Optimization Time:</strong> {result.execution_time?.toFixed(3) || 'N/A'}s</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="card">
        <h3>🏗️ Smart City Architecture</h3>
        <div className="city-visualization">
          <div className="city-grid">
            <div className="city-zone residential">
              <div className="zone-label">🏠 Residential</div>
              <div className="zone-metrics">
                <div className="zone-metric">Energy: 85%</div>
                <div className="zone-metric">Traffic: Low</div>
              </div>
            </div>
            
            <div className="city-zone commercial">
              <div className="zone-label">🏢 Commercial</div>
              <div className="zone-metrics">
                <div className="zone-metric">Energy: 92%</div>
                <div className="zone-metric">Traffic: High</div>
              </div>
            </div>
            
            <div className="city-zone industrial">
              <div className="zone-label">🏭 Industrial</div>
              <div className="zone-metrics">
                <div className="zone-metric">Energy: 78%</div>
                <div className="zone-metric">Traffic: Medium</div>
              </div>
            </div>
            
            <div className="city-zone green">
              <div className="zone-label">🌳 Green Space</div>
              <div className="zone-metrics">
                <div className="zone-metric">Air Quality: Good</div>
                <div className="zone-metric">CO₂: -15%</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .city-controls {
          display: flex;
          gap: 20px;
          justify-content: center;
          margin: 30px 0;
          flex-wrap: wrap;
        }
        
        .city-btn {
          padding: 15px 30px;
          border: none;
          border-radius: 10px;
          font-size: 1.1rem;
          font-weight: bold;
          cursor: pointer;
          transition: all 0.3s ease;
          color: white;
          min-width: 200px;
        }
        
        .city-btn.energy {
          background: linear-gradient(45deg, #4facfe, #00f2fe);
        }
        
        .city-btn.traffic {
          background: linear-gradient(45deg, #43e97b, #38f9d7);
        }
        
        .city-btn:hover:not(:disabled) {
          transform: translateY(-3px);
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }
        
        .city-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        
        .metrics-dashboard {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 30px;
          margin-top: 20px;
        }
        
        .metric-section {
          background: rgba(0, 0, 0, 0.05);
          border-radius: 10px;
          padding: 20px;
        }
        
        .metric-section h4 {
          margin: 0 0 15px 0;
          color: #667eea;
          font-size: 1.2rem;
        }
        
        .metric-grid {
          display: grid;
          gap: 10px;
        }
        
        .metric-item {
          display: flex;
          justify-content: space-between;
          padding: 8px 0;
          border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .metric-label {
          font-weight: 500;
        }
        
        .metric-value {
          font-weight: bold;
          color: #4facfe;
        }
        
        .city-visualization {
          margin: 20px 0;
        }
        
        .city-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 20px;
          margin-top: 20px;
        }
        
        .city-zone {
          border-radius: 10px;
          padding: 20px;
          text-align: center;
          color: white;
          min-height: 120px;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }
        
        .city-zone.residential {
          background: linear-gradient(135deg, #667eea, #764ba2);
        }
        
        .city-zone.commercial {
          background: linear-gradient(135deg, #f093fb, #f5576c);
        }
        
        .city-zone.industrial {
          background: linear-gradient(135deg, #4facfe, #00f2fe);
        }
        
        .city-zone.green {
          background: linear-gradient(135deg, #43e97b, #38f9d7);
        }
        
        .zone-label {
          font-size: 1.1rem;
          font-weight: bold;
          margin-bottom: 10px;
        }
        
        .zone-metrics {
          font-size: 0.9rem;
        }
        
        .zone-metric {
          margin: 5px 0;
          opacity: 0.9;
        }
        
        .results-container {
          max-height: 400px;
          overflow-y: auto;
          margin-top: 20px;
        }
        
        .result-item {
          background: rgba(0, 0, 0, 0.05);
          border-radius: 8px;
          padding: 15px;
          margin-bottom: 15px;
          border-left: 4px solid #4facfe;
        }
        
        .result-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
        }
        
        .result-type {
          font-weight: bold;
          font-size: 1.1rem;
        }
        
        .result-time {
          font-size: 0.9rem;
          color: #666;
        }
        
        .result-content p {
          margin: 5px 0;
        }
      `}</style>
    </div>
  );
};

export default SmartCityDashboard;

