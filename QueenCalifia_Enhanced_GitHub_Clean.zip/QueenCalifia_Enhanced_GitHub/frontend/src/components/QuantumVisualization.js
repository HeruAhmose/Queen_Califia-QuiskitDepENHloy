import React, { useState, useEffect } from 'react';

const QuantumVisualization = () => {
  const [quantumState, setQuantumState] = useState(null);
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState([]);

  const runQuantumCircuit = async () => {
    setIsRunning(true);
    try {
      const response = await fetch('/api/quantum/neural-network', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          input_data: [0.5, 0.3, 0.8, 0.2],
          num_qubits: 4,
          num_layers: 2
        })
      });
      const data = await response.json();
      setResults(prev => [data, ...prev.slice(0, 4)]); // Keep last 5 results
    } catch (error) {
      console.error('Quantum circuit execution failed:', error);
    } finally {
      setIsRunning(false);
    }
  };

  const runQuantumOptimization = async () => {
    setIsRunning(true);
    try {
      const response = await fetch('/api/quantum/optimization', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          resources: [100, 150, 200, 120],
          constraints: [80, 90, 180, 100]
        })
      });
      const data = await response.json();
      setResults(prev => [data, ...prev.slice(0, 4)]);
    } catch (error) {
      console.error('Quantum optimization failed:', error);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div>
      <div className="card quantum-glow">
        <h2>⚛️ Quantum Computing Core</h2>
        <p>Advanced quantum neural networks and optimization algorithms powered by IBM Qiskit</p>
        
        <div className="quantum-controls">
          <button 
            className="quantum-btn neural"
            onClick={runQuantumCircuit}
            disabled={isRunning}
          >
            {isRunning ? '🔄 Running...' : '🧠 Run Quantum Neural Network'}
          </button>
          
          <button 
            className="quantum-btn optimization"
            onClick={runQuantumOptimization}
            disabled={isRunning}
          >
            {isRunning ? '🔄 Running...' : '⚡ Run Quantum Optimization'}
          </button>
        </div>
      </div>

      {results.length > 0 && (
        <div className="card">
          <h3>📊 Quantum Execution Results</h3>
          <div className="results-container">
            {results.map((result, index) => (
              <div key={index} className="result-item">
                <div className="result-header">
                  <span className="result-type">
                    {result.type === 'neural_network' ? '🧠 Neural Network' : '⚡ Optimization'}
                  </span>
                  <span className="result-time">
                    {new Date(result.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                
                <div className="result-content">
                  {result.type === 'neural_network' ? (
                    <div>
                      <p><strong>Prediction:</strong> {result.prediction?.toFixed(4) || 'N/A'}</p>
                      <p><strong>Confidence:</strong> {(result.confidence * 100)?.toFixed(1) || 'N/A'}%</p>
                      <p><strong>Execution Time:</strong> {result.execution_time?.toFixed(3) || 'N/A'}s</p>
                    </div>
                  ) : (
                    <div>
                      <p><strong>Optimal Solution:</strong> {result.optimal_solution?.join(', ') || 'N/A'}</p>
                      <p><strong>Cost Reduction:</strong> {result.cost_reduction?.toFixed(2) || 'N/A'}%</p>
                      <p><strong>Execution Time:</strong> {result.execution_time?.toFixed(3) || 'N/A'}s</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="card">
        <h3>🔬 Quantum Circuit Visualization</h3>
        <div className="circuit-visualization">
          <div className="qubit-line">
            <span className="qubit-label">|q₀⟩</span>
            <div className="gate">H</div>
            <div className="gate">RY(θ₁)</div>
            <div className="gate">RZ(θ₂)</div>
            <div className="cnot-control">●</div>
            <div className="wire"></div>
          </div>
          <div className="qubit-line">
            <span className="qubit-label">|q₁⟩</span>
            <div className="gate">H</div>
            <div className="gate">RY(θ₃)</div>
            <div className="gate">RZ(θ₄)</div>
            <div className="cnot-target">⊕</div>
            <div className="wire"></div>
          </div>
          <div className="qubit-line">
            <span className="qubit-label">|q₂⟩</span>
            <div className="gate">H</div>
            <div className="gate">RY(θ₅)</div>
            <div className="gate">RZ(θ₆)</div>
            <div className="cnot-control">●</div>
            <div className="wire"></div>
          </div>
          <div className="qubit-line">
            <span className="qubit-label">|q₃⟩</span>
            <div className="gate">H</div>
            <div className="gate">RY(θ₇)</div>
            <div className="gate">RZ(θ₈)</div>
            <div className="cnot-target">⊕</div>
            <div className="wire"></div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .quantum-controls {
          display: flex;
          gap: 20px;
          justify-content: center;
          margin: 30px 0;
          flex-wrap: wrap;
        }
        
        .quantum-btn {
          padding: 15px 30px;
          border: none;
          border-radius: 10px;
          font-size: 1.1rem;
          font-weight: bold;
          cursor: pointer;
          transition: all 0.3s ease;
          color: white;
          min-width: 200px;
        }
        
        .quantum-btn.neural {
          background: linear-gradient(45deg, #667eea, #764ba2);
        }
        
        .quantum-btn.optimization {
          background: linear-gradient(45deg, #f093fb, #f5576c);
        }
        
        .quantum-btn:hover:not(:disabled) {
          transform: translateY(-3px);
          box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }
        
        .quantum-btn:disabled {
          opacity: 0.7;
          cursor: not-allowed;
        }
        
        .results-container {
          max-height: 400px;
          overflow-y: auto;
          margin-top: 20px;
        }
        
        .result-item {
          background: rgba(0, 0, 0, 0.05);
          border-radius: 8px;
          padding: 15px;
          margin-bottom: 15px;
          border-left: 4px solid #667eea;
        }
        
        .result-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
        }
        
        .result-type {
          font-weight: bold;
          font-size: 1.1rem;
        }
        
        .result-time {
          font-size: 0.9rem;
          color: #666;
        }
        
        .result-content p {
          margin: 5px 0;
        }
        
        .circuit-visualization {
          background: #f8f9fa;
          border-radius: 10px;
          padding: 30px;
          margin: 20px 0;
          overflow-x: auto;
        }
        
        .qubit-line {
          display: flex;
          align-items: center;
          margin: 15px 0;
          min-width: 600px;
        }
        
        .qubit-label {
          width: 50px;
          font-weight: bold;
          font-family: 'Courier New', monospace;
        }
        
        .gate {
          background: #667eea;
          color: white;
          padding: 8px 12px;
          margin: 0 10px;
          border-radius: 5px;
          font-weight: bold;
          min-width: 60px;
          text-align: center;
        }
        
        .cnot-control, .cnot-target {
          background: #764ba2;
          color: white;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 10px;
          font-weight: bold;
        }
        
        .wire {
          flex: 1;
          height: 2px;
          background: #333;
          margin-left: 10px;
        }
      `}</style>
    </div>
  );
};

export default QuantumVisualization;

