"""
QueenCalifia-Ω Test Suite
Comprehensive testing for all framework components
"""

import unittest
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from memory_manager import MemoryEngine
from emotion_engine import EmotionEngine
from voice_interface import VoiceInterface
from califia_agent import QueenCalifiaAgent

class TestMemoryEngine(unittest.TestCase):
    def setUp(self):
        self.memory = MemoryEngine(memory_file="test_memory.json", db_file="test_memory.db")
    
    def test_logging(self):
        self.memory.log("Test input", "Test response", "happy", "casual")
        context = self.memory.get_context(last_n=1)
        self.assertIn("Test input", context)
        self.assertIn("Test response", context)
    
    def test_memory_search(self):
        self.memory.log("I love programming", "That's wonderful!", "happy", "enthusiastic")
        results = self.memory.search_memory("programming")
        self.assertTrue(len(results) > 0)
        self.assertIn("programming", results[0]['user_input'])
    
    def tearDown(self):
        # Clean up test files
        for file in ["test_memory.json", "test_memory.db"]:
            if os.path.exists(file):
                os.remove(file)

class TestEmotionEngine(unittest.TestCase):
    def setUp(self):
        self.emotion_engine = EmotionEngine()
    
    def test_emotion_detection(self):
        result = self.emotion_engine.analyze_emotion("I'm so excited about this!")
        self.assertEqual(result['primary_emotion'], 'excited')
        self.assertGreater(result['intensity'], 0.3)
    
    def test_sad_emotion(self):
        result = self.emotion_engine.analyze_emotion("I'm feeling really sad and depressed")
        self.assertEqual(result['primary_emotion'], 'sad')
        self.assertGreater(result['emotion_scores']['sad'], 0.5)
    
    def test_tone_detection(self):
        result = self.emotion_engine.analyze_emotion("Could you please help me with this?")
        self.assertEqual(result['tone'], 'formal')

class TestVoiceInterface(unittest.TestCase):
    def setUp(self):
        self.voice = VoiceInterface(tts_engine="system", stt_engine="system")
    
    def test_voice_toggle(self):
        initial_state = self.voice.is_enabled
        self.voice.toggle_voice()
        self.assertNotEqual(initial_state, self.voice.is_enabled)
    
    def test_voice_settings(self):
        self.voice.set_voice_settings(rate=120, volume=0.9)
        self.assertEqual(self.voice.voice_settings['rate'], 120)
        self.assertEqual(self.voice.voice_settings['volume'], 0.9)
    
    def test_emotion_adjustment(self):
        settings = self.voice._adjust_voice_for_emotion('happy', 'enthusiastic')
        self.assertGreater(settings['rate'], 150)  # Happy should be faster

class TestQueenCalifiaAgent(unittest.TestCase):
    def setUp(self):
        self.agent = QueenCalifiaAgent(use_voice=False)
    
    def test_response_generation(self):
        response_package = self.agent.respond("Hello, how are you?", "test_user")
        self.assertIn('response', response_package)
        self.assertIn('emotion_analysis', response_package)
        self.assertIsInstance(response_package['response'], str)
        self.assertGreater(len(response_package['response']), 10)
    
    def test_emotional_support_response(self):
        response_package = self.agent.respond("I'm feeling really sad and overwhelmed", "test_user")
        response = response_package['response'].lower()
        # Should contain supportive language
        supportive_words = ['understand', 'feel', 'support', 'here', 'valid', 'sense']
        self.assertTrue(any(word in response for word in supportive_words))
    
    def test_conversation_count(self):
        initial_count = self.agent.conversation_count
        self.agent.respond("Test message", "test_user")
        self.assertEqual(self.agent.conversation_count, initial_count + 1)
    
    def test_personality_traits(self):
        self.assertIn('curiosity_level', self.agent.personality_traits)
        self.assertIn('empathy_level', self.agent.personality_traits)
        self.assertBetween(self.agent.personality_traits['empathy_level'], 0.0, 1.0)
    
    def assertBetween(self, value, min_val, max_val):
        self.assertGreaterEqual(value, min_val)
        self.assertLessEqual(value, max_val)

class TestIntegration(unittest.TestCase):
    def setUp(self):
        self.agent = QueenCalifiaAgent(use_voice=False)
    
    def test_full_conversation_flow(self):
        # Test a complete conversation flow
        conversations = [
            "Hello, I'm new here",
            "I'm feeling stressed about work",
            "Can you help me with my finances?",
            "Thank you for your help"
        ]
        
        for i, message in enumerate(conversations):
            response_package = self.agent.respond(message, "integration_test_user")
            
            # Each response should be meaningful
            self.assertGreater(len(response_package['response']), 20)
            
            # Conversation count should increment
            self.assertEqual(response_package['conversation_count'], i + 1)
            
            # Should have emotion analysis
            self.assertIn('primary_emotion', response_package['emotion_analysis'])
    
    def test_memory_persistence(self):
        # Test that memory persists across interactions
        self.agent.respond("My name is Alice and I love cats", "memory_test_user")
        
        # Later conversation should potentially reference this
        response_package = self.agent.respond("Do you remember what I told you?", "memory_test_user")
        
        # Should have conversation history
        self.assertGreater(self.agent.conversation_count, 1)
    
    def test_emotion_response_adaptation(self):
        # Test that responses adapt to different emotions
        sad_response = self.agent.respond("I'm feeling really depressed", "emotion_test_user")
        happy_response = self.agent.respond("I'm so excited and happy!", "emotion_test_user")
        
        # Responses should be different
        self.assertNotEqual(sad_response['response'], happy_response['response'])
        
        # Emotions should be detected correctly
        self.assertIn(sad_response['emotion_analysis']['primary_emotion'], ['sad', 'anxious', 'negative'])
        self.assertIn(happy_response['emotion_analysis']['primary_emotion'], ['happy', 'excited', 'positive'])

def run_all_tests():
    """Run all tests and display results"""
    print("🧪 Running QueenCalifia-Ω Test Suite...")
    print("=" * 60)
    
    # Create test suite
    test_suite = unittest.TestSuite()
    
    # Add test classes
    test_classes = [
        TestMemoryEngine,
        TestEmotionEngine,
        TestVoiceInterface,
        TestQueenCalifiaAgent,
        TestIntegration
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Display summary
    print("\n" + "=" * 60)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    
    if result.failures:
        print("\nFailures:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback}")
    
    if result.errors:
        print("\nErrors:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback}")
    
    if result.wasSuccessful():
        print("\n✅ All tests passed! QueenCalifia-Ω is working correctly.")
    else:
        print("\n❌ Some tests failed. Please check the output above.")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    run_all_tests()

