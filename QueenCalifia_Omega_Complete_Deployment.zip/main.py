"""
QueenCalifia-Ω Main Application
Firebase + BigQuery Integration with Voice-Ready Hooks
"""

import os
import json
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from datetime import datetime
import threading
import time

# Import our components
from califia_agent import QueenCalifiaAgent
from memory_manager import MemoryEngine
from emotion_engine import EmotionEngine

# Firebase imports (with fallback)
try:
    import firebase_admin
    from firebase_admin import credentials, firestore
    FIREBASE_AVAILABLE = True
except ImportError:
    FIREBASE_AVAILABLE = False
    print("⚠️ Firebase not available - using local storage")

# BigQuery imports (with fallback)
try:
    from google.cloud import bigquery
    BIGQUERY_AVAILABLE = True
except ImportError:
    BIGQUERY_AVAILABLE = False
    print("⚠️ BigQuery not available - using local knowledge base")

app = Flask(__name__)
CORS(app)

class QueenCalifiaOmegaApp:
    def __init__(self):
        self.agent = None
        self.firebase_db = None
        self.bigquery_client = None
        self.initialize_services()
        self.initialize_agent()
    
    def initialize_services(self):
        """Initialize Firebase and BigQuery services"""
        
        # Initialize Firebase
        if FIREBASE_AVAILABLE and os.path.exists('secrets/serviceAccountKey.json'):
            try:
                cred = credentials.Certificate('secrets/serviceAccountKey.json')
                firebase_admin.initialize_app(cred)
                self.firebase_db = firestore.client()
                print("✅ Firebase Firestore connected")
            except Exception as e:
                print(f"⚠️ Firebase initialization failed: {e}")
        
        # Initialize BigQuery
        if BIGQUERY_AVAILABLE and os.path.exists('secrets/serviceAccountKey.json'):
            try:
                self.bigquery_client = bigquery.Client.from_service_account_json('secrets/serviceAccountKey.json')
                print("✅ BigQuery connected")
            except Exception as e:
                print(f"⚠️ BigQuery initialization failed: {e}")
    
    def initialize_agent(self):
        """Initialize QueenCalifia agent with enhanced capabilities"""
        memory_engine = MemoryEngine(
            firebase_db=self.firebase_db,
            bigquery_client=self.bigquery_client
        )
        
        self.agent = QueenCalifiaAgent(
            memory=memory_engine,
            use_voice=True
        )
        print("👑 QueenCalifia-Ω initialized with Firebase + BigQuery integration")
    
    def generate_reply(self, user_input, user_id="default"):
        """Enhanced reply generation with memory and knowledge integration"""
        
        # Recall context from Firebase/BigQuery
        memory_context = self.recall_context(user_input, user_id)
        
        # Analyze tone and emotion
        emotion_analysis = self.agent.emotion_engine.analyze_emotion(user_input)
        
        # Generate response using agent
        response_data = self.agent.respond(user_input, user_id)
        
        # Log to Firebase if available
        self.log_conversation(user_input, response_data['response'], user_id, emotion_analysis)
        
        return response_data
    
    def recall_context(self, user_input, user_id):
        """Recall relevant context from memory systems"""
        context = ""
        
        # Get from Firebase if available
        if self.firebase_db:
            try:
                docs = self.firebase_db.collection('conversations').where('user_id', '==', user_id).limit(5).stream()
                conversations = [doc.to_dict() for doc in docs]
                context += f"Recent conversations: {conversations}\n"
            except Exception as e:
                print(f"Firebase recall error: {e}")
        
        # Get from BigQuery knowledge base if available
        if self.bigquery_client:
            try:
                # Query relevant knowledge based on user input keywords
                query = f"""
                SELECT content, relevance_score 
                FROM `queen_califia_knowledge.knowledge_base` 
                WHERE LOWER(content) CONTAINS '{user_input.lower()[:50]}'
                ORDER BY relevance_score DESC 
                LIMIT 3
                """
                results = self.bigquery_client.query(query)
                knowledge = [row.content for row in results]
                context += f"Relevant knowledge: {knowledge}\n"
            except Exception as e:
                print(f"BigQuery recall error: {e}")
        
        return context
    
    def log_conversation(self, user_input, response, user_id, emotion_analysis):
        """Log conversation to Firebase"""
        if self.firebase_db:
            try:
                doc_data = {
                    'user_id': user_id,
                    'user_input': user_input,
                    'response': response,
                    'emotion_analysis': emotion_analysis,
                    'timestamp': datetime.utcnow(),
                    'session_id': f"{user_id}_{datetime.now().strftime('%Y%m%d')}"
                }
                self.firebase_db.collection('conversations').add(doc_data)
            except Exception as e:
                print(f"Firebase logging error: {e}")

# Initialize the app
califia_app = QueenCalifiaOmegaApp()

@app.route('/')
def dashboard():
    """Main dashboard"""
    return render_template('dashboard.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    """Main chat endpoint"""
    try:
        data = request.get_json()
        user_input = data.get('message', '')
        user_id = data.get('user_id', 'default')
        
        if not user_input:
            return jsonify({'error': 'No message provided'}), 400
        
        # Generate reply using enhanced system
        response_data = califia_app.generate_reply(user_input, user_id)
        
        return jsonify({
            'success': True,
            'response': response_data['response'],
            'metadata': response_data.get('metadata', {}),
            'firebase_connected': califia_app.firebase_db is not None,
            'bigquery_connected': califia_app.bigquery_client is not None
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/voice/toggle', methods=['POST'])
def toggle_voice():
    """Toggle voice interface"""
    try:
        enabled = califia_app.agent.toggle_voice()
        return jsonify({
            'success': True,
            'voice_enabled': enabled
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/status', methods=['GET'])
def get_status():
    """Get system status"""
    return jsonify({
        'status': 'online',
        'firebase_connected': califia_app.firebase_db is not None,
        'bigquery_connected': califia_app.bigquery_client is not None,
        'voice_available': califia_app.agent.voice_interface is not None,
        'agent_stats': califia_app.agent.get_agent_status()
    })

@app.route('/api/memory/sync', methods=['POST'])
def sync_memory():
    """Sync memory to cloud services"""
    try:
        # Sync local memory to Firebase
        if califia_app.firebase_db:
            # Implementation for memory sync
            return jsonify({'success': True, 'message': 'Memory synced to Firebase'})
        else:
            return jsonify({'success': False, 'message': 'Firebase not available'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("🚀 Starting QueenCalifia-Ω with Firebase + BigQuery Integration...")
    print("🌐 Dashboard will be available at: http://localhost:5000")
    print("☁️ Firebase status:", "Connected" if califia_app.firebase_db else "Not connected")
    print("📊 BigQuery status:", "Connected" if califia_app.bigquery_client else "Not connected")
    
    app.run(host='0.0.0.0', port=5000, debug=False)

