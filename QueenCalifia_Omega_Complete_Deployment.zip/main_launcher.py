"""
QueenCalifia-Ω Main Launcher
CLI + PowerShell entry with one-click simulation
"""

import sys
import os
import time
from califia_agent import QueenCalifiaAgent
from memory_manager import MemoryEngine
from voice_interface import VoiceInterface

def print_banner():
    """Display QueenCalifia-Ω banner"""
    banner = """
    ╔══════════════════════════════════════════════════════════════╗
    ║                    👑 QueenCalifia-Ω                         ║
    ║              Advanced Conversational AI Framework            ║
    ║                                                              ║
    ║  🧠 Natural Language Model    🏷️ Memory Tags                ║
    ║  🎙️ Voice Interface          😊 Emotion Analysis           ║
    ║  💬 Dynamic Dialogue Engine   📡 External API Brain         ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def print_help():
    """Display help information"""
    help_text = """
    QueenCalifia-Ω Commands:
    
    🗣️  Chat Commands:
    - Just type naturally to chat with QueenCalifia-Ω
    - She adapts to your emotion and tone automatically
    
    🎛️  Control Commands:
    - /voice          - Toggle voice interface on/off
    - /status         - Show system status and statistics
    - /memory         - Display memory and conversation history
    - /personality    - Show current personality traits
    - /help           - Show this help message
    - /clear          - Clear conversation history
    - /exit or /quit  - Exit the program
    
    💡 Tips:
    - QueenCalifia-Ω remembers your conversations
    - She detects emotions and adapts her responses
    - Try asking about finances, health, relationships, or anything!
    - Voice interface works on supported systems
    """
    print(help_text)

def display_status(agent):
    """Display agent status"""
    status = agent.get_agent_status()
    
    print("\n📊 QueenCalifia-Ω Status:")
    print(f"   Conversations: {status['conversation_count']}")
    print(f"   Voice Enabled: {status['voice_enabled']}")
    
    print("\n🧠 Memory Statistics:")
    memory_stats = status['memory_stats']
    print(f"   Total Interactions: {memory_stats.get('total_interactions', 0)}")
    print(f"   Short-term Memory: {memory_stats.get('short_term_memory_size', 0)} items")
    print(f"   Recent Activity (24h): {memory_stats.get('recent_activity_24h', 0)}")
    
    if memory_stats.get('emotion_distribution'):
        print("\n😊 Emotion Distribution:")
        for emotion, count in list(memory_stats['emotion_distribution'].items())[:5]:
            print(f"   {emotion}: {count}")
    
    print("\n🎭 Personality Traits:")
    for trait, value in status['personality_traits'].items():
        bar = "█" * int(value * 10) + "░" * (10 - int(value * 10))
        print(f"   {trait.replace('_', ' ').title()}: {bar} {value:.1f}")

def display_memory(agent):
    """Display memory information"""
    print("\n🧠 Memory System:")
    
    # Get recent context
    context = agent.memory.get_context(last_n=3, include_emotions=True)
    if context and context != "No prior context.":
        print("\n📝 Recent Conversations:")
        print(context)
    else:
        print("   No conversation history yet.")
    
    # Get emotional patterns
    emotional_patterns = agent.memory.get_emotional_pattern(days=7)
    if emotional_patterns:
        print("\n😊 Emotional Patterns (Last 7 days):")
        for emotion, count in emotional_patterns.items():
            print(f"   {emotion}: {count} times")

def main():
    """Main application entry point"""
    print_banner()
    
    # Initialize QueenCalifia-Ω
    print("🚀 Initializing QueenCalifia-Ω...")
    try:
        agent = QueenCalifiaAgent(use_voice=True)
        print("✅ QueenCalifia-Ω is online and ready!")
    except Exception as e:
        print(f"❌ Error initializing QueenCalifia-Ω: {e}")
        return
    
    print("\n💡 Type '/help' for commands or just start chatting!")
    print("👑 QueenCalifia-Ω: Hello! I'm QueenCalifia-Ω, and I'm delighted to meet you. How are you feeling today?")
    
    # Main conversation loop
    while True:
        try:
            # Get user input
            user_input = input("\n🎙️ You: ").strip()
            
            if not user_input:
                continue
            
            # Handle commands
            if user_input.startswith('/'):
                command = user_input.lower()
                
                if command in ['/exit', '/quit']:
                    print("\n👑 QueenCalifia-Ω: Thank you for our wonderful conversation. Take care! 💫")
                    break
                    
                elif command == '/help':
                    print_help()
                    continue
                    
                elif command == '/status':
                    display_status(agent)
                    continue
                    
                elif command == '/memory':
                    display_memory(agent)
                    continue
                    
                elif command == '/personality':
                    print("\n🎭 Current Personality Traits:")
                    for trait, value in agent.personality_traits.items():
                        print(f"   {trait.replace('_', ' ').title()}: {value:.2f}")
                    continue
                    
                elif command == '/voice':
                    voice_status = agent.toggle_voice()
                    status_text = "enabled" if voice_status else "disabled"
                    print(f"\n🎤 Voice interface {status_text}")
                    continue
                    
                elif command == '/clear':
                    # Clear conversation history
                    agent.memory.short_term_memory = []
                    print("\n🧹 Conversation history cleared")
                    continue
                    
                else:
                    print(f"\n❓ Unknown command: {user_input}")
                    print("   Type '/help' to see available commands")
                    continue
            
            # Process conversation
            print("\n🤔 QueenCalifia-Ω is thinking...")
            
            start_time = time.time()
            response_package = agent.respond(user_input)
            processing_time = time.time() - start_time
            
            # Display response
            print(f"\n👑 QueenCalifia-Ω: {response_package['response']}")
            
            # Show emotion analysis (optional debug info)
            emotion_info = response_package['emotion_analysis']
            print(f"\n💭 [Detected: {emotion_info['primary_emotion']} emotion, {emotion_info['tone']} tone, {processing_time:.2f}s]")
            
        except KeyboardInterrupt:
            print("\n\n👑 QueenCalifia-Ω: I understand you need to go. Until we meet again! ✨")
            break
            
        except Exception as e:
            print(f"\n❌ Error: {e}")
            print("👑 QueenCalifia-Ω: I apologize, but I encountered a technical difficulty. Please try again.")

def quick_test():
    """Quick test function for development"""
    print("🧪 Running Quick Test...")
    
    agent = QueenCalifiaAgent(use_voice=False)
    
    test_inputs = [
        "I'm feeling really stressed about work",
        "Can you help me with my finances?",
        "I'm so excited about my vacation!",
        "What's the meaning of life?"
    ]
    
    for i, test_input in enumerate(test_inputs, 1):
        print(f"\nTest {i}: {test_input}")
        response = agent.respond(test_input)
        print(f"Response: {response['response'][:100]}...")
        print(f"Emotion: {response['emotion_analysis']['primary_emotion']}")
    
    print("\n✅ Quick test complete!")

if __name__ == "__main__":
    # Check for command line arguments
    if len(sys.argv) > 1:
        if sys.argv[1] == "test":
            quick_test()
        elif sys.argv[1] == "help":
            print_help()
        else:
            print(f"Unknown argument: {sys.argv[1]}")
            print("Usage: python main_launcher.py [test|help]")
    else:
        main()

