# QueenCalifia-Ω PowerShell Setup Script
# Automated installation and configuration for Windows systems

param(
    [switch]$SkipPython,
    [switch]$SkipDependencies,
    [switch]$QuickStart,
    [string]$InstallPath = "$env:USERPROFILE\QueenCalifia-Omega"
)

# Colors for output
$ErrorColor = "Red"
$SuccessColor = "Green"
$InfoColor = "Cyan"
$WarningColor = "Yellow"

function Write-ColorOutput {
    param([string]$Message, [string]$Color = "White")
    Write-Host $Message -ForegroundColor $Color
}

function Test-Administrator {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Install-Python {
    Write-ColorOutput "🐍 Checking Python installation..." $InfoColor
    
    try {
        $pythonVersion = python --version 2>&1
        if ($pythonVersion -match "Python 3\.[8-9]|Python 3\.1[0-9]") {
            Write-ColorOutput "✅ Python is already installed: $pythonVersion" $SuccessColor
            return $true
        }
    }
    catch {
        Write-ColorOutput "❌ Python not found or incompatible version" $WarningColor
    }
    
    Write-ColorOutput "📥 Downloading Python 3.11..." $InfoColor
    $pythonUrl = "https://www.python.org/ftp/python/3.11.7/python-3.11.7-amd64.exe"
    $pythonInstaller = "$env:TEMP\python-installer.exe"
    
    try {
        Invoke-WebRequest -Uri $pythonUrl -OutFile $pythonInstaller
        Write-ColorOutput "🚀 Installing Python 3.11..." $InfoColor
        Start-Process -FilePath $pythonInstaller -ArgumentList "/quiet", "InstallAllUsers=1", "PrependPath=1", "Include_test=0" -Wait
        
        # Refresh environment variables
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
        
        Write-ColorOutput "✅ Python installation completed" $SuccessColor
        return $true
    }
    catch {
        Write-ColorOutput "❌ Failed to install Python: $_" $ErrorColor
        return $false
    }
}

function Install-Git {
    Write-ColorOutput "📦 Checking Git installation..." $InfoColor
    
    try {
        $gitVersion = git --version 2>&1
        if ($gitVersion -match "git version") {
            Write-ColorOutput "✅ Git is already installed: $gitVersion" $SuccessColor
            return $true
        }
    }
    catch {
        Write-ColorOutput "❌ Git not found" $WarningColor
    }
    
    Write-ColorOutput "📥 Downloading Git..." $InfoColor
    $gitUrl = "https://github.com/git-for-windows/git/releases/download/v2.42.0.windows.2/Git-2.42.0.2-64-bit.exe"
    $gitInstaller = "$env:TEMP\git-installer.exe"
    
    try {
        Invoke-WebRequest -Uri $gitUrl -OutFile $gitInstaller
        Write-ColorOutput "🚀 Installing Git..." $InfoColor
        Start-Process -FilePath $gitInstaller -ArgumentList "/VERYSILENT", "/NORESTART" -Wait
        
        Write-ColorOutput "✅ Git installation completed" $SuccessColor
        return $true
    }
    catch {
        Write-ColorOutput "❌ Failed to install Git: $_" $ErrorColor
        return $false
    }
}

function Setup-QueenCalifia {
    Write-ColorOutput "👑 Setting up QueenCalifia-Ω..." $InfoColor
    
    # Create installation directory
    if (!(Test-Path $InstallPath)) {
        New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
        Write-ColorOutput "📁 Created installation directory: $InstallPath" $SuccessColor
    }
    
    Set-Location $InstallPath
    
    # Copy files if running from source
    $sourceFiles = @(
        "quantum_consciousness_engine.py",
        "enhanced_memory_engine.py", 
        "advanced_conversational_agent.py",
        "emotion_engine.py",
        "requirements.txt",
        ".env.example"
    )
    
    foreach ($file in $sourceFiles) {
        if (Test-Path "..\$file") {
            Copy-Item "..\$file" . -Force
            Write-ColorOutput "📄 Copied $file" $SuccessColor
        }
    }
    
    # Create virtual environment
    Write-ColorOutput "🔧 Creating Python virtual environment..." $InfoColor
    python -m venv venv
    
    # Activate virtual environment
    Write-ColorOutput "⚡ Activating virtual environment..." $InfoColor
    & ".\venv\Scripts\Activate.ps1"
    
    # Upgrade pip
    Write-ColorOutput "📦 Upgrading pip..." $InfoColor
    python -m pip install --upgrade pip
    
    # Install requirements
    Write-ColorOutput "📦 Installing Python packages..." $InfoColor
    if (Test-Path "requirements.txt") {
        pip install -r requirements.txt
        Write-ColorOutput "✅ Python packages installed successfully" $SuccessColor
    } else {
        Write-ColorOutput "❌ requirements.txt not found" $ErrorColor
        return $false
    }
    
    # Create environment file
    if (!(Test-Path ".env")) {
        Copy-Item ".env.example" ".env"
        Write-ColorOutput "📝 Created .env file from template" $SuccessColor
        Write-ColorOutput "⚠️  Please edit .env file with your API keys" $WarningColor
    }
    
    # Create logs directory
    if (!(Test-Path "logs")) {
        New-Item -ItemType Directory -Path "logs" -Force | Out-Null
        Write-ColorOutput "📁 Created logs directory" $SuccessColor
    }
    
    # Create memory directory
    if (!(Test-Path "memory")) {
        New-Item -ItemType Directory -Path "memory" -Force | Out-Null
        Write-ColorOutput "📁 Created memory directory" $SuccessColor
    }
    
    return $true
}

function Create-LaunchScript {
    Write-ColorOutput "🚀 Creating launch script..." $InfoColor
    
    $launchScript = @"
@echo off
title QueenCalifia-Omega Quantum Intelligence
echo.
echo ========================================
echo   QueenCalifia-Omega Quantum Intelligence
echo ========================================
echo.

cd /d "%~dp0"

if not exist "venv\Scripts\activate.bat" (
    echo Error: Virtual environment not found!
    echo Please run setup.ps1 first.
    pause
    exit /b 1
)

echo Activating virtual environment...
call venv\Scripts\activate.bat

echo Starting QueenCalifia-Omega...
python advanced_conversational_agent.py

if errorlevel 1 (
    echo.
    echo Error: Failed to start QueenCalifia-Omega
    echo Check the error messages above.
    pause
)
"@
    
    $launchScript | Out-File -FilePath "launch_califia.bat" -Encoding ASCII
    Write-ColorOutput "✅ Created launch_califia.bat" $SuccessColor
    
    # Create PowerShell launch script
    $psLaunchScript = @"
# QueenCalifia-Omega PowerShell Launcher
Set-Location `$PSScriptRoot

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  QueenCalifia-Omega Quantum Intelligence" -ForegroundColor Cyan  
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if (!(Test-Path "venv\Scripts\Activate.ps1")) {
    Write-Host "Error: Virtual environment not found!" -ForegroundColor Red
    Write-Host "Please run setup.ps1 first." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "Activating virtual environment..." -ForegroundColor Green
& ".\venv\Scripts\Activate.ps1"

Write-Host "Starting QueenCalifia-Omega..." -ForegroundColor Green
python advanced_conversational_agent.py

if (`$LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "Error: Failed to start QueenCalifia-Omega" -ForegroundColor Red
    Write-Host "Check the error messages above." -ForegroundColor Red
    Read-Host "Press Enter to exit"
}
"@
    
    $psLaunchScript | Out-File -FilePath "launch_califia.ps1" -Encoding UTF8
    Write-ColorOutput "✅ Created launch_califia.ps1" $SuccessColor
}

function Test-Installation {
    Write-ColorOutput "🧪 Testing installation..." $InfoColor
    
    # Activate virtual environment
    & ".\venv\Scripts\Activate.ps1"
    
    # Test Python imports
    $testScript = @"
try:
    import sys
    print(f"Python version: {sys.version}")
    
    # Test core imports
    import qiskit
    print("✅ Qiskit imported successfully")
    
    import vaderSentiment
    print("✅ VADER sentiment imported successfully")
    
    import flask
    print("✅ Flask imported successfully")
    
    # Test QueenCalifia modules
    from quantum_consciousness_engine import QuantumConsciousnessEngine
    print("✅ Quantum consciousness engine imported successfully")
    
    from enhanced_memory_engine import EnhancedMemoryEngine
    print("✅ Enhanced memory engine imported successfully")
    
    from emotion_engine import EmotionEngine
    print("✅ Emotion engine imported successfully")
    
    print("🎉 All tests passed! QueenCalifia-Ω is ready to run.")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)
except Exception as e:
    print(f"❌ Unexpected error: {e}")
    sys.exit(1)
"@
    
    $testScript | Out-File -FilePath "test_installation.py" -Encoding UTF8
    
    try {
        $result = python test_installation.py 2>&1
        Write-ColorOutput $result $SuccessColor
        Remove-Item "test_installation.py" -Force
        return $true
    }
    catch {
        Write-ColorOutput "❌ Installation test failed: $_" $ErrorColor
        return $false
    }
}

# Main execution
Write-ColorOutput "========================================" $InfoColor
Write-ColorOutput "  QueenCalifia-Ω Setup Script" $InfoColor
Write-ColorOutput "========================================" $InfoColor
Write-ColorOutput ""

# Check if running as administrator
if (!(Test-Administrator)) {
    Write-ColorOutput "⚠️  Running without administrator privileges" $WarningColor
    Write-ColorOutput "Some features may require administrator access" $WarningColor
    Write-ColorOutput ""
}

# Install Python if needed
if (!$SkipPython) {
    if (!(Install-Python)) {
        Write-ColorOutput "❌ Python installation failed. Exiting." $ErrorColor
        exit 1
    }
}

# Install Git if needed
if (!$SkipDependencies) {
    Install-Git | Out-Null
}

# Setup QueenCalifia
if (!(Setup-QueenCalifia)) {
    Write-ColorOutput "❌ QueenCalifia setup failed. Exiting." $ErrorColor
    exit 1
}

# Create launch scripts
Create-LaunchScript

# Test installation
if (!$QuickStart) {
    if (!(Test-Installation)) {
        Write-ColorOutput "❌ Installation test failed" $ErrorColor
        Write-ColorOutput "Please check the error messages above" $WarningColor
    }
}

Write-ColorOutput ""
Write-ColorOutput "🎉 QueenCalifia-Ω setup completed successfully!" $SuccessColor
Write-ColorOutput ""
Write-ColorOutput "Next steps:" $InfoColor
Write-ColorOutput "1. Edit the .env file with your API keys" $WarningColor
Write-ColorOutput "2. Run launch_califia.bat or launch_califia.ps1 to start" $SuccessColor
Write-ColorOutput ""
Write-ColorOutput "Installation location: $InstallPath" $InfoColor

if (!$QuickStart) {
    Read-Host "Press Enter to exit"
}

