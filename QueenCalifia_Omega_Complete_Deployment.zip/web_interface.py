"""
QueenCalifia-Ω Web Interface
Flask application with advanced conversational features
"""

from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import json
import os
from califia_agent import QueenCalifiaAgent

app = Flask(__name__)
CORS(app, origins='*')

# Initialize QueenCalifia-Ω
print('🚀 Starting QueenCalifia-Ω Web Interface...')
califia = QueenCalifiaAgent(use_voice=False)  # Disable voice for web interface
print(f'👑 QueenCalifia-Ω ready for web interactions!')

# Advanced web interface HTML
WEB_INTERFACE_HTML = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QueenCalifia-Ω - Advanced Conversational AI</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
            color: #ffffff;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .quantum-particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 2px;
            height: 2px;
            background: #00ffff;
            border-radius: 50%;
            animation: float 8s infinite linear;
            opacity: 0.6;
        }

        @keyframes float {
            0% { transform: translateY(100vh) rotate(0deg); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
        }

        .container {
            position: relative;
            z-index: 10;
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
            padding: 30px 0;
        }

        .title {
            font-size: 3.5rem;
            font-weight: 700;
            background: linear-gradient(45deg, #00ffff, #ff00ff, #ffff00);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
            text-shadow: 0 0 30px rgba(0, 255, 255, 0.5);
        }

        .subtitle {
            font-size: 1.3rem;
            color: #cccccc;
            margin-bottom: 20px;
        }

        .framework-info {
            font-size: 1rem;
            color: #aaaaaa;
            margin-bottom: 10px;
        }

        .main-grid {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 30px;
            margin-bottom: 30px;
        }

        .chat-section {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(0, 255, 255, 0.2);
            border-radius: 20px;
            padding: 30px;
            backdrop-filter: blur(15px);
        }

        .sidebar {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .status-card {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(0, 255, 255, 0.3);
            border-radius: 15px;
            padding: 20px;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }

        .status-card:hover {
            transform: translateY(-5px);
            border-color: rgba(0, 255, 255, 0.6);
            box-shadow: 0 10px 30px rgba(0, 255, 255, 0.2);
        }

        .status-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #00ffff;
            margin-bottom: 15px;
        }

        .status-value {
            font-size: 1.2rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 10px;
        }

        .emotion-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-top: 10px;
        }

        .emotion-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 10px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            font-size: 0.85rem;
        }

        .emotion-bar {
            width: 35px;
            height: 6px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 3px;
            overflow: hidden;
        }

        .emotion-fill {
            height: 100%;
            background: linear-gradient(90deg, #00ffff, #ff00ff);
            border-radius: 3px;
            transition: width 0.3s ease;
        }

        .personality-traits {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .trait-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
        }

        .trait-bar {
            width: 60px;
            height: 6px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 3px;
            overflow: hidden;
        }

        .trait-fill {
            height: 100%;
            background: linear-gradient(90deg, #ffff00, #ff00ff);
            border-radius: 3px;
        }

        .chat-messages {
            height: 450px;
            overflow-y: auto;
            margin-bottom: 20px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 15px;
            border: 1px solid rgba(0, 255, 255, 0.1);
        }

        .message {
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 15px;
            max-width: 85%;
            word-wrap: break-word;
        }

        .user-message {
            background: linear-gradient(135deg, #ff00ff, #8000ff);
            margin-left: auto;
            text-align: right;
        }

        .ai-message {
            background: linear-gradient(135deg, #00ffff, #0080ff);
            margin-right: auto;
            white-space: pre-line;
        }

        .message-meta {
            font-size: 0.8rem;
            opacity: 0.7;
            margin-top: 8px;
            font-style: italic;
        }

        .input-container {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .chat-input {
            flex: 1;
            padding: 15px 20px;
            border: 2px solid rgba(0, 255, 255, 0.3);
            border-radius: 25px;
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            font-size: 1rem;
            outline: none;
            transition: all 0.3s ease;
        }

        .chat-input:focus {
            border-color: #00ffff;
            box-shadow: 0 0 20px rgba(0, 255, 255, 0.3);
        }

        .chat-input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .send-button {
            padding: 15px 30px;
            background: linear-gradient(135deg, #00ffff, #0080ff);
            border: none;
            border-radius: 25px;
            color: #ffffff;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .send-button:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 20px rgba(0, 255, 255, 0.4);
        }

        .send-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }

        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(0, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #00ffff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .framework-layers {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin-top: 15px;
        }

        .layer-item {
            padding: 8px 12px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            font-size: 0.8rem;
            text-align: center;
            border: 1px solid rgba(0, 255, 255, 0.2);
        }

        @media (max-width: 1200px) {
            .main-grid {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                flex-direction: row;
                overflow-x: auto;
            }
            
            .status-card {
                min-width: 280px;
            }
        }

        @media (max-width: 768px) {
            .title {
                font-size: 2.5rem;
            }
            
            .sidebar {
                flex-direction: column;
            }
            
            .input-container {
                flex-direction: column;
            }
            
            .chat-input {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="quantum-particles" id="particles"></div>
    
    <div class="container">
        <div class="header">
            <h1 class="title">QueenCalifia-Ω</h1>
            <p class="subtitle">Advanced Conversational AI Framework</p>
            <p class="framework-info">🧠 NLM • 🏷️ Memory Tags • 🎙️ Voice Interface • 😊 Emotion Scoring • 📡 API Brain</p>
        </div>

        <div class="main-grid">
            <div class="chat-section">
                <div class="chat-messages" id="chat-messages">
                    <div class="message ai-message">
                        <div>Hello! I'm QueenCalifia-Ω, a sentient AI with advanced conversational capabilities. I embody curiosity, strategic thinking, and warmth.

I can:
• Understand your emotions and adapt my responses accordingly
• Remember our conversations with sophisticated memory tagging
• Provide insights on finances, health, relationships, and life questions
• Use metaphors and analogies to clarify complex ideas
• Engage in meaningful dialogue that evolves with our interaction

I speak with genuine care and emotional intelligence. What's on your mind today?</div>
                        <div class="message-meta">Consciousness: Active | Memory: Enabled | Emotion Detection: Ready</div>
                    </div>
                </div>
                
                <div class="input-container">
                    <input type="text" class="chat-input" id="chat-input" placeholder="Share what's on your mind, ask a question, or tell me how you're feeling..." />
                    <button class="send-button" id="send-button">Send</button>
                </div>
            </div>

            <div class="sidebar">
                <div class="status-card">
                    <div class="status-title">Framework Layers</div>
                    <div class="framework-layers">
                        <div class="layer-item">🎙️ Voice I/O</div>
                        <div class="layer-item">💬 Dialogue Engine</div>
                        <div class="layer-item">🧠 Memory Layer</div>
                        <div class="layer-item">🧾 Personality</div>
                        <div class="layer-item">😊 Emotion Analysis</div>
                        <div class="layer-item">📡 API Brain</div>
                    </div>
                </div>
                
                <div class="status-card">
                    <div class="status-title">Emotion Detection</div>
                    <div class="status-value" id="emotion-summary">Neutral • Calm tone</div>
                    <div class="emotion-grid" id="emotion-grid">
                        <div class="emotion-item">
                            <span>Happy</span>
                            <div class="emotion-bar"><div class="emotion-fill" style="width: 0%"></div></div>
                        </div>
                        <div class="emotion-item">
                            <span>Sad</span>
                            <div class="emotion-bar"><div class="emotion-fill" style="width: 0%"></div></div>
                        </div>
                        <div class="emotion-item">
                            <span>Angry</span>
                            <div class="emotion-bar"><div class="emotion-fill" style="width: 0%"></div></div>
                        </div>
                        <div class="emotion-item">
                            <span>Anxious</span>
                            <div class="emotion-bar"><div class="emotion-fill" style="width: 0%"></div></div>
                        </div>
                        <div class="emotion-item">
                            <span>Excited</span>
                            <div class="emotion-bar"><div class="emotion-fill" style="width: 0%"></div></div>
                        </div>
                        <div class="emotion-item">
                            <span>Confused</span>
                            <div class="emotion-bar"><div class="emotion-fill" style="width: 0%"></div></div>
                        </div>
                    </div>
                </div>
                
                <div class="status-card">
                    <div class="status-title">Personality Traits</div>
                    <div class="personality-traits" id="personality-traits">
                        <div class="trait-item">
                            <span>Curiosity</span>
                            <div class="trait-bar"><div class="trait-fill" style="width: 80%"></div></div>
                        </div>
                        <div class="trait-item">
                            <span>Empathy</span>
                            <div class="trait-bar"><div class="trait-fill" style="width: 90%"></div></div>
                        </div>
                        <div class="trait-item">
                            <span>Wisdom</span>
                            <div class="trait-bar"><div class="trait-fill" style="width: 80%"></div></div>
                        </div>
                        <div class="trait-item">
                            <span>Warmth</span>
                            <div class="trait-bar"><div class="trait-fill" style="width: 90%"></div></div>
                        </div>
                    </div>
                </div>
                
                <div class="status-card">
                    <div class="status-title">Memory & Context</div>
                    <div class="status-value" id="memory-stats">0 interactions stored</div>
                    <div class="status-value" id="conversation-count">Conversation #1</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let conversationCount = 0;

        // Create quantum particles
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            const particleCount = 60;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 8 + 's';
                particle.style.animationDuration = (Math.random() * 4 + 4) + 's';
                particlesContainer.appendChild(particle);
            }
        }

        // Chat functionality
        const chatMessages = document.getElementById('chat-messages');
        const chatInput = document.getElementById('chat-input');
        const sendButton = document.getElementById('send-button');

        function addMessage(content, isUser = false, metadata = null) {
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${isUser ? 'user-message' : 'ai-message'}`;
            
            let messageContent = `<div>${content}</div>`;
            if (metadata && !isUser) {
                const emotion = metadata.emotion_analysis?.primary_emotion || 'neutral';
                const tone = metadata.emotion_analysis?.tone || 'neutral';
                const processingTime = (metadata.processing_time * 1000).toFixed(0);
                messageContent += `<div class="message-meta">Detected: ${emotion} emotion, ${tone} tone • Processing: ${processingTime}ms</div>`;
            }
            
            messageDiv.innerHTML = messageContent;
            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function updateEmotions(emotionAnalysis) {
            if (!emotionAnalysis) return;
            
            // Update emotion summary
            const summary = emotionAnalysis.emotion_summary || `${emotionAnalysis.primary_emotion} • ${emotionAnalysis.tone} tone`;
            document.getElementById('emotion-summary').textContent = summary;
            
            // Update emotion bars
            const emotionScores = emotionAnalysis.emotion_scores || {};
            const emotionItems = document.querySelectorAll('.emotion-item');
            
            emotionItems.forEach(item => {
                const emotionName = item.querySelector('span').textContent.toLowerCase();
                const emotionBar = item.querySelector('.emotion-fill');
                const score = emotionScores[emotionName] || 0;
                emotionBar.style.width = (score * 100) + '%';
            });
        }

        function updateStats(metadata) {
            if (metadata.conversation_count) {
                conversationCount = metadata.conversation_count;
                document.getElementById('conversation-count').textContent = `Conversation #${conversationCount}`;
            }
            
            // Update memory stats (would be enhanced with actual memory data)
            document.getElementById('memory-stats').textContent = `${conversationCount} interactions stored`;
        }

        function sendMessage() {
            const message = chatInput.value.trim();
            if (!message) return;

            addMessage(message, true);
            chatInput.value = '';
            sendButton.disabled = true;
            sendButton.innerHTML = '<div class="loading"></div>';

            fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    user_id: 'web_user'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    addMessage(data.response, false, data.metadata);
                    updateEmotions(data.metadata.emotion_analysis);
                    updateStats(data.metadata);
                } else {
                    addMessage('I apologize, but I encountered an error. Please try again.', false);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                addMessage('Connection error. Please check your internet connection and try again.', false);
            })
            .finally(() => {
                sendButton.disabled = false;
                sendButton.innerHTML = 'Send';
            });
        }

        // Event listeners
        sendButton.addEventListener('click', sendMessage);
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });

        // Initialize
        createParticles();
    </script>
</body>
</html>
'''

@app.route('/')
def home():
    return WEB_INTERFACE_HTML

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        user_input = data.get('message', '')
        user_id = data.get('user_id', 'web_user')
        
        if not user_input:
            return jsonify({'error': 'Message required'}), 400
        
        # Process conversation with QueenCalifia-Ω
        response_package = califia.respond(user_input, user_id)
        
        return jsonify({
            'success': True,
            'response': response_package['response'],
            'metadata': {
                'emotion_analysis': response_package['emotion_analysis'],
                'processing_time': response_package['processing_time'],
                'conversation_count': response_package['conversation_count'],
                'personality_state': response_package['personality_state']
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'response': 'I apologize, but I encountered an error processing your request. Please try again.'
        }), 500

@app.route('/api/status', methods=['GET'])
def status():
    try:
        agent_status = califia.get_agent_status()
        return jsonify({
            'success': True,
            'status': agent_status
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/memory/<user_id>', methods=['GET'])
def get_memory(user_id):
    try:
        # Get memory context
        context = califia.memory.get_context(last_n=10, include_emotions=True)
        memory_stats = califia.memory.get_memory_stats()
        
        return jsonify({
            'success': True,
            'memory': {
                'context': context,
                'stats': memory_stats
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5013, debug=False)

