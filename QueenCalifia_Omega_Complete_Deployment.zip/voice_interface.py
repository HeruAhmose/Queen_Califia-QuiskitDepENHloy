"""
QueenCalifia-Ω Voice Interface
STT (Speech-to-Text) + TTS (Text-to-Speech) with Whisper/ElevenLabs/Coqui support
"""

import subprocess
import sys
import os
import json
from typing import Optional, Dict
import tempfile
import wave

class VoiceInterface:
    def __init__(self, tts_engine="system", stt_engine="system"):
        self.tts_engine = tts_engine
        self.stt_engine = stt_engine
        self.voice_settings = {
            'rate': 150,
            'volume': 0.8,
            'voice_id': 'female',
            'language': 'en-US',
            'pitch': 'medium'
        }
        self.is_enabled = True
        
    def speak(self, text: str, emotion: str = "neutral", tone: str = "neutral") -> bool:
        """
        Convert text to speech with emotional context
        """
        if not self.is_enabled:
            print(f"[🎤 Califia says]: {text}")
            return True
            
        try:
            # Adjust voice parameters based on emotion and tone
            adjusted_settings = self._adjust_voice_for_emotion(emotion, tone)
            
            if self.tts_engine == "system":
                return self._system_tts(text, adjusted_settings)
            elif self.tts_engine == "coqui":
                return self._coqui_tts(text, adjusted_settings)
            elif self.tts_engine == "elevenlabs":
                return self._elevenlabs_tts(text, adjusted_settings)
            else:
                # Fallback to console output
                print(f"[🎤 Califia says]: {text}")
                return True
                
        except Exception as e:
            print(f"[🎤 Califia says]: {text}")
            print(f"Voice error: {e}")
            return False
    
    def listen(self, timeout: int = 30) -> Optional[str]:
        """
        Convert speech to text
        """
        if not self.is_enabled:
            return input("🎙️ Speak (text input): ")
            
        try:
            if self.stt_engine == "whisper":
                return self._whisper_stt(timeout)
            elif self.stt_engine == "system":
                return self._system_stt(timeout)
            else:
                # Fallback to text input
                return input("🎙️ Speak (text input): ")
                
        except Exception as e:
            print(f"Speech recognition error: {e}")
            return input("🎙️ Speak (text input): ")
    
    def _adjust_voice_for_emotion(self, emotion: str, tone: str) -> Dict:
        """Adjust voice parameters based on emotion and tone"""
        settings = self.voice_settings.copy()
        
        # Emotion-based adjustments
        emotion_adjustments = {
            'happy': {'rate': 160, 'pitch': 'high', 'volume': 0.9},
            'excited': {'rate': 170, 'pitch': 'high', 'volume': 0.95},
            'sad': {'rate': 120, 'pitch': 'low', 'volume': 0.7},
            'angry': {'rate': 140, 'pitch': 'high', 'volume': 0.9},
            'anxious': {'rate': 155, 'pitch': 'medium-high', 'volume': 0.8},
            'calm': {'rate': 140, 'pitch': 'medium', 'volume': 0.8},
            'confused': {'rate': 130, 'pitch': 'medium', 'volume': 0.75},
            'grateful': {'rate': 145, 'pitch': 'medium', 'volume': 0.85}
        }
        
        # Tone-based adjustments
        tone_adjustments = {
            'urgent': {'rate': 165, 'volume': 0.9},
            'casual': {'rate': 150, 'volume': 0.8},
            'formal': {'rate': 140, 'volume': 0.85},
            'questioning': {'pitch': 'medium-high'},
            'emphatic': {'volume': 0.9, 'rate': 155}
        }
        
        # Apply emotion adjustments
        if emotion in emotion_adjustments:
            settings.update(emotion_adjustments[emotion])
            
        # Apply tone adjustments
        if tone in tone_adjustments:
            settings.update(tone_adjustments[tone])
            
        return settings
    
    def _system_tts(self, text: str, settings: Dict) -> bool:
        """System-based text-to-speech"""
        try:
            # macOS
            if sys.platform == "darwin":
                rate = settings.get('rate', 150)
                voice = "Samantha" if settings.get('voice_id') == 'female' else "Alex"
                cmd = ["say", "-r", str(rate), "-v", voice, text]
                subprocess.run(cmd, check=True)
                return True
                
            # Windows
            elif sys.platform == "win32":
                import pyttsx3
                engine = pyttsx3.init()
                engine.setProperty('rate', settings.get('rate', 150))
                engine.setProperty('volume', settings.get('volume', 0.8))
                
                voices = engine.getProperty('voices')
                if settings.get('voice_id') == 'female' and len(voices) > 1:
                    engine.setProperty('voice', voices[1].id)
                    
                engine.say(text)
                engine.runAndWait()
                return True
                
            # Linux
            elif sys.platform.startswith("linux"):
                # Try espeak
                rate = settings.get('rate', 150)
                cmd = ["espeak", "-s", str(rate), text]
                subprocess.run(cmd, check=True)
                return True
                
        except Exception as e:
            print(f"System TTS error: {e}")
            return False
    
    def _coqui_tts(self, text: str, settings: Dict) -> bool:
        """Coqui TTS implementation"""
        try:
            # This would require Coqui TTS installation
            # For now, simulate with system TTS
            print(f"[Coqui TTS] {text}")
            return self._system_tts(text, settings)
            
        except Exception as e:
            print(f"Coqui TTS error: {e}")
            return False
    
    def _elevenlabs_tts(self, text: str, settings: Dict) -> bool:
        """ElevenLabs TTS implementation"""
        try:
            # This would require ElevenLabs API key and library
            # For now, simulate with enhanced system TTS
            print(f"[ElevenLabs TTS] {text}")
            return self._system_tts(text, settings)
            
        except Exception as e:
            print(f"ElevenLabs TTS error: {e}")
            return False
    
    def _whisper_stt(self, timeout: int) -> Optional[str]:
        """Whisper-based speech recognition"""
        try:
            # This would require OpenAI Whisper
            # For now, simulate with system STT
            print("🎙️ Listening with Whisper...")
            return self._system_stt(timeout)
            
        except Exception as e:
            print(f"Whisper STT error: {e}")
            return None
    
    def _system_stt(self, timeout: int) -> Optional[str]:
        """System-based speech recognition"""
        try:
            # Try to use system speech recognition
            if sys.platform == "darwin":
                # macOS speech recognition would go here
                pass
            elif sys.platform == "win32":
                # Windows speech recognition would go here
                pass
                
            # Fallback to text input for now
            print(f"🎙️ Listening (timeout: {timeout}s)...")
            return input("🎙️ Speak (text input): ")
            
        except Exception as e:
            print(f"System STT error: {e}")
            return None
    
    def toggle_voice(self) -> bool:
        """Toggle voice interface on/off"""
        self.is_enabled = not self.is_enabled
        status = "enabled" if self.is_enabled else "disabled"
        print(f"Voice interface {status}")
        return self.is_enabled
    
    def set_voice_settings(self, **kwargs):
        """Update voice settings"""
        self.voice_settings.update(kwargs)
        print(f"Voice settings updated: {kwargs}")
    
    def get_voice_info(self) -> Dict:
        """Get current voice configuration"""
        return {
            'tts_engine': self.tts_engine,
            'stt_engine': self.stt_engine,
            'settings': self.voice_settings,
            'enabled': self.is_enabled
        }

# Simplified functions for backward compatibility
def speak(text: str, emotion: str = "neutral", tone: str = "neutral"):
    """Simple speak function"""
    voice = VoiceInterface()
    voice.speak(text, emotion, tone)

def listen(timeout: int = 30) -> str:
    """Simple listen function"""
    voice = VoiceInterface()
    result = voice.listen(timeout)
    return result or ""

# Test the voice interface
if __name__ == "__main__":
    print("Testing QueenCalifia-Ω Voice Interface...")
    
    voice = VoiceInterface()
    
    # Test voice info
    print("\nVoice Configuration:")
    info = voice.get_voice_info()
    for key, value in info.items():
        print(f"- {key}: {value}")
    
    # Test different emotions
    test_phrases = [
        ("Hello! I'm QueenCalifia-Ω, and I'm excited to meet you!", "excited", "enthusiastic"),
        ("I understand you're feeling stressed. Let's work through this together.", "calm", "empathetic"),
        ("That's a fascinating question! Let me think about that.", "curious", "thoughtful"),
        ("I'm sorry to hear you're going through a difficult time.", "sad", "compassionate")
    ]
    
    print("\nTesting emotional speech synthesis...")
    for text, emotion, tone in test_phrases:
        print(f"\nEmotion: {emotion}, Tone: {tone}")
        voice.speak(text, emotion, tone)
    
    # Test voice toggle
    print(f"\nVoice enabled: {voice.is_enabled}")
    voice.toggle_voice()
    print(f"Voice enabled: {voice.is_enabled}")
    voice.toggle_voice()
    print(f"Voice enabled: {voice.is_enabled}")
    
    # Test settings adjustment
    print("\nTesting voice settings...")
    voice.set_voice_settings(rate=120, pitch='low', voice_id='male')
    voice.speak("Testing new voice settings with slower, lower voice.", "calm", "formal")
    
    print("\nVoice Interface test complete!")

