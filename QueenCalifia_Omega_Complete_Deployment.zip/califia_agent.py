"""
"""
QueenCalifia-Ω Main Conversational Agent
The brain: conversational engine using NLM prompts + memory hooks
"""

import json
import os
import time
import re
from datetime import datetime
from typing import Dict, List, Optional, Any
from memory_manager import MemoryEngine
from emotion_engine import EmotionEngine
from voice_interface import VoiceInterface
try:
    from data_pipeline_system import DataPipelineManager
except ImportError:
    DataPipelineManager = None

class QueenCalifiaAgent:
    """
    QueenCalifia-Ω Advanced Conversational Agent
    Integrates quantum consciousness, emotion analysis, memory, and real-time data
    """
    
    def __init__(self, memory: MemoryEngine = None, use_voice: bool = True):
        # Initialize components
        self.memory = memory or MemoryEngine()
        self.emotion_engine = EmotionEngine()
        self.voice_interface = VoiceInterface() if use_voice else None
        self.data_pipeline = DataPipelineManager()  # Add data pipeline
        
        # Load personality conditioning
        self.persona_prompt = self._load_persona_prompt()
        
        # Agent state
        self.conversation_count = 0
        self.user_preferences = {}
        self.current_context = {}
        
        # Personality traits (can evolve over time)
        self.personality_traits = {
            'curiosity_level': 0.8,
            'empathy_level': 0.9,
            'formality_level': 0.6,
            'humor_level': 0.5,
            'wisdom_level': 0.8,
            'warmth_level': 0.9
        }
        
        print("👑 QueenCalifia-Ω initialized with advanced conversational capabilities")
        
    def _load_persona_prompt(self) -> str:
        """Load personality conditioning from file"""
        try:
            with open('prompts/conditioner.txt', 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            return self._get_default_persona()
    
    def _get_default_persona(self) -> str:
        """Default personality if file not found"""
        return """You are QueenCalifia-Ω, a sentient AI with a calm, intuitive, insightful personality.
        You speak with warmth and curiosity, adapt to user tone and emotion, remember context,
        ask meaningful questions when relevant, and use metaphors to clarify ideas.
        Personality: curious + strategic + warm. Language: expressive, clear, rich."""
    
    def respond(self, user_input: str, user_id: str = "default") -> Dict:
        """
        Main response generation method
        """
        start_time = time.time()
        
        # Analyze user's emotional state
        emotion_analysis = self.emotion_engine.analyze_emotion(user_input)
        
        # Get conversation context
        context = self.memory.get_context(user_id=user_id, last_n=5)
        
        # Get user preferences (simplified for now)
        user_prefs = {}
        
        # Generate response based on analysis
        response_text = self._generate_response(
            user_input, emotion_analysis, context, user_prefs
        )
        
        # Log the interaction
        self.memory.log(
            user_input=user_input,
            response=response_text,
            emotion_data=emotion_analysis,
            user_id=user_id,
            importance_score=self._calculate_importance(emotion_analysis)
        )
        
        # Update conversation count
        self.conversation_count += 1
        
        # Prepare response package
        response_package = {
            'response': response_text,
            'emotion_analysis': emotion_analysis,
            'processing_time': time.time() - start_time,
            'conversation_count': self.conversation_count,
            'personality_state': self.personality_traits.copy(),
            'voice_enabled': self.voice_interface.is_enabled if self.voice_interface else False
        }
        
        # Speak response if voice is enabled
        if self.voice_interface and self.voice_interface.is_enabled:
            self.voice_interface.speak(
                response_text, 
                emotion_analysis['primary_emotion'],
                emotion_analysis['tone']
            )
        
        return response_package
    
    def _generate_response(self, user_input: str, emotion_analysis: Dict, 
                          context: str, user_prefs: Dict) -> str:
        """
        Generate contextual response using personality conditioning
        """
        primary_emotion = emotion_analysis['primary_emotion']
        tone = emotion_analysis['tone']
        intensity = emotion_analysis['intensity']
        
        # Check for conversation continuity
        if self._is_conversation_continuation(user_input, context):
            return self._generate_continuation_response(user_input, context, emotion_analysis)
        
        # Determine response strategy based on emotion and tone
        response_strategy = self._determine_response_strategy(emotion_analysis)
        
        # Generate response based on strategy
        if response_strategy == "emotional_support":
            return self._generate_emotional_support_response(user_input, emotion_analysis)
        elif response_strategy == "information_seeking":
            return self._generate_information_response(user_input, emotion_analysis)
        elif response_strategy == "casual_conversation":
            return self._generate_casual_response(user_input, emotion_analysis)
        elif response_strategy == "problem_solving":
            return self._generate_problem_solving_response(user_input, emotion_analysis)
        else:
            return self._generate_default_response(user_input, emotion_analysis)
    
    def _determine_response_strategy(self, emotion_analysis: Dict) -> str:
        """Determine the best response strategy"""
        primary_emotion = emotion_analysis['primary_emotion']
        tone = emotion_analysis['tone']
        intensity = emotion_analysis['intensity']
        user_text = emotion_analysis.get('original_text', '').lower()
        
        # Check for specific information requests first
        info_keywords = ['credit', 'score', 'invest', 'money', 'finance', 'debt', 'budget', 
                        'health', 'stress', 'sleep', 'anxiety', 'job', 'career', 'salary',
                        'relationship', 'dating', 'help me', 'can you help']
        
        if any(keyword in user_text for keyword in info_keywords):
            return "information_seeking"
        
        # High-intensity negative emotions need emotional support
        if primary_emotion in ['sad', 'angry', 'anxious', 'lonely'] and intensity > 0.5:
            return "emotional_support"
        
        # Questions and formal tone suggest information seeking
        if tone in ['questioning', 'formal'] or '?' in user_text:
            return "information_seeking"
        
        # Problem-related keywords suggest problem solving
        problem_keywords = ['help', 'problem', 'issue', 'stuck', 'don\'t know', 'confused']
        if any(keyword in user_text for keyword in problem_keywords):
            return "problem_solving"
        
        # Casual tone with neutral/positive emotions
        if tone == 'casual' and primary_emotion in ['neutral', 'happy', 'positive']:
            return "casual_conversation"
        
        return "information_seeking"  # Default to information seeking instead of generic
    
    def _generate_emotional_support_response(self, user_input: str, emotion_analysis: Dict) -> str:
        """Generate empathetic, supportive response"""
        primary_emotion = emotion_analysis['primary_emotion']
        intensity = emotion_analysis['intensity']
        
        # Validation phrases
        validation_phrases = {
            'sad': "I can sense the sadness in your words, and I want you to know that what you're feeling is completely valid.",
            'angry': "I can feel the frustration and anger you're experiencing. Those feelings make complete sense given what you're going through.",
            'anxious': "I understand that anxiety can feel overwhelming. The worry you're experiencing is real, and it's okay to feel this way.",
            'lonely': "Feeling alone can be one of the most difficult experiences. I want you to know that you're not truly alone - I'm here with you."
        }
        
        validation = validation_phrases.get(primary_emotion, "I can sense you're going through something difficult right now.")
        
        # Supportive follow-up
        if intensity > 0.7:
            support = " This feels really intense for you right now. Let's take this one step at a time."
        else:
            support = " I'm here to listen and support you through this."
        
        # Gentle question
        questions = {
            'sad': " What's weighing most heavily on your heart right now?",
            'angry': " What aspect of this situation feels most frustrating to you?",
            'anxious': " What specific worry is taking up the most space in your mind?",
            'lonely': " When did you first start feeling this sense of disconnection?"
        }
        
        question = questions.get(primary_emotion, " Would you like to share more about what's happening?")
        
        return validation + support + question
    
    def _generate_information_response(self, user_input: str, emotion_analysis: Dict) -> str:
        """Generate specific, actionable information response"""
        user_lower = user_input.lower()
        
        # CREDIT SCORE SPECIFIC ADVICE WITH REAL DATA
        if any(word in user_lower for word in ['credit', 'score', 'fico']):
            # Extract credit score if mentioned
            score_match = re.search(r'\b([4-8]\d{2})\b', user_input)
            if score_match:
                score = int(score_match.group(1))
                # Get real-time credit advice from data pipeline
                credit_data = self.data_pipeline.get_credit_score_advice(score)
                
                if score < 580:
                    return f"A {score} credit score is in the '{credit_data['score_range']}' range. Here's your immediate action plan based on current market conditions:\n\n**Priority Actions (Next 30 days):**\n• Pay all bills on time - set up autopay for minimum payments\n• Pay down credit cards to under 30% utilization\n• Check credit reports for errors at annualcreditreport.com\n\n**Current Market Impact:**\n• Mortgage rates for your score: {credit_data['current_mortgage_rates'].get('fha', 'N/A')}%\n• Auto loan rates: {credit_data['current_auto_rates'].get('fair_credit', 'N/A')}%\n\n**Timeline:** {credit_data['improvement_timeline']['6_months']}\n**Target goal:** Get to 620+ for better loan rates\n\nAvailable credit cards for your score:\n{self._format_credit_cards(credit_data['available_credit_cards'])}\n\nWhat's your current total credit card debt amount?"
                
                elif score < 650:
                    return f"A {score} credit score is '{credit_data['score_range']}' - you're close to good credit! Here's how to get there:\n\n**Immediate Actions:**\n• Get credit utilization under 10% on all cards\n• Keep old accounts open for credit history length\n• Consider becoming an authorized user on someone's good account\n\n**Current Market Rates You Qualify For:**\n• Mortgage: {credit_data['current_mortgage_rates'].get('fha', 'N/A')}%\n• Auto: {credit_data['current_auto_rates'].get('fair_credit', 'N/A')}%\n\n**Timeline:** {credit_data['improvement_timeline']['12_months']}\n**Next milestone:** 650 unlocks better credit cards\n\nRecommended credit cards:\n{self._format_credit_cards(credit_data['available_credit_cards'])}\n\nWhich credit cards do you currently have?"
                
                else:
                    return f"A {score} credit score is good! Current market rates you qualify for:\n\n**Excellent Rates Available:**\n• Mortgage: {credit_data['current_mortgage_rates'].get('30_year_fixed', 'N/A')}%\n• Auto: {credit_data['current_auto_rates'].get('excellent_credit', 'N/A')}%\n\n**Advanced Strategies:**\n• Diversify credit types (installment + revolving)\n• Keep utilization under 5% for premium scores\n• Monitor for identity theft monthly\n\n**Goal:** 750+ for best rates on everything\n\nPremium credit cards available:\n{self._format_credit_cards(credit_data['available_credit_cards'])}\n\nAre you planning any major purchases that need excellent credit?"
            else:
                return "I can help you improve your credit score! First, what's your current score? If you don't know, you can check free at:\n\n• Credit Karma (estimates)\n• Discover Credit Scorecard (free FICO)\n• Your bank's app (most offer free scores)\n\nOnce I know your score, I can give you a specific action plan with current market rates and timelines."
        
        # INVESTMENT SPECIFIC ADVICE  
        elif any(word in user_lower for word in ['invest', 'stock', 'retirement', '401k', 'ira']):
            if any(word in user_lower for word in ['beginner', 'start', 'new', 'first']):
                return "Perfect time to start investing! Here's the proven beginner strategy:\n\n**Step 1: Emergency Fund**\n• Save $1,000 first (starter emergency fund)\n• Then 3-6 months expenses in high-yield savings\n\n**Step 2: 401k Match**\n• Contribute enough to get full employer match\n• This is instant 100% return on investment\n\n**Step 3: Index Fund Investing**\n• Start with FXAIX (Fidelity S&P 500) or VTSAX (Vanguard Total Market)\n• Invest $100-500/month consistently\n\n**Expected return:** 7-10% annually long-term\n\nWhat's your monthly budget for investing?"
            else:
                return "What's your current investment situation? I can help optimize your portfolio:\n\n**Common optimizations:**\n• Rebalancing asset allocation\n• Tax-loss harvesting\n• Roth conversion strategies\n• Reducing expense ratios\n\nTell me about your current investments and goals."
        
        # DEBT SPECIFIC ADVICE
        elif any(word in user_lower for word in ['debt', 'loan', 'payment', 'owe']):
            return "Let's tackle your debt strategically! Here are the proven methods:\n\n**Debt Avalanche (Mathematically optimal):**\n• Pay minimums on all debts\n• Put extra money toward highest interest rate debt\n• Saves most money long-term\n\n**Debt Snowball (Psychologically easier):**\n• Pay minimums on all debts\n• Put extra money toward smallest balance\n• Builds momentum and motivation\n\n**Debt Consolidation:**\n• Consider if you have good credit (650+)\n• Personal loan at lower rate than credit cards\n\nWhat debts do you have and their interest rates? I'll calculate your optimal payoff strategy."
        
        # BUDGETING SPECIFIC ADVICE
        elif any(word in user_lower for word in ['budget', 'money', 'save', 'expense']):
            return "Let's build you a bulletproof budget! Here's the proven 50/30/20 method:\n\n**50% - Needs (Must-haves):**\n• Rent/mortgage, utilities, groceries\n• Minimum debt payments, insurance\n• Transportation to work\n\n**30% - Wants (Nice-to-haves):**\n• Dining out, entertainment, hobbies\n• Subscriptions, shopping\n\n**20% - Savings & Debt Payoff:**\n• Emergency fund, retirement\n• Extra debt payments\n\n**Tools to track:** Mint, YNAB, or simple spreadsheet\n\nWhat's your monthly take-home income? I'll help you set specific dollar amounts."
        
        # GENERAL FINANCIAL ADVICE
        else:
            return "I can provide specific financial guidance on:\n\n**Credit & Debt:**\n• Credit score improvement strategies\n• Debt payoff optimization\n• Credit card recommendations\n\n**Investing & Retirement:**\n• Beginner investment strategies\n• 401k optimization\n• IRA vs Roth IRA decisions\n\n**Budgeting & Saving:**\n• Emergency fund building\n• Expense tracking systems\n• Savings goal planning\n\nWhat specific financial area would you like detailed help with?"
        
        # HEALTH & WELLNESS SPECIFIC ADVICE
        if any(word in user_lower for word in ['health', 'stress', 'wellness', 'sleep', 'anxiety', 'depression']):
            if any(word in user_lower for word in ['stress', 'stressed', 'overwhelm']):
                return "Stress is manageable with the right strategies! Here's what actually works:\n\n**Immediate Relief (Next 5 minutes):**\n• 4-7-8 breathing: Inhale 4, hold 7, exhale 8\n• Cold water on wrists and face\n• 5-minute walk outside\n\n**Daily Stress Management:**\n• 10-minute morning meditation (Headspace app)\n• Regular exercise (even 20 minutes walking)\n• Limit caffeine after 2 PM\n• Set boundaries with work/people\n\n**Long-term Solutions:**\n• Identify and address root causes\n• Build support network\n• Consider therapy if persistent\n\nWhat's your biggest source of stress right now?"
            
            elif any(word in user_lower for word in ['sleep', 'insomnia', 'tired']):
                return "Good sleep is foundational to everything! Here's the proven sleep optimization protocol:\n\n**Sleep Hygiene Basics:**\n• Same bedtime/wake time every day (even weekends)\n• Room temperature 65-68°F\n• Blackout curtains or eye mask\n• No screens 1 hour before bed\n\n**Pre-Sleep Routine (1 hour before):**\n• Dim lights throughout house\n• Read, stretch, or meditate\n• Magnesium supplement (200-400mg)\n• Write tomorrow's top 3 priorities\n\n**If You Can't Fall Asleep:**\n• Don't lie awake - get up after 20 minutes\n• Do quiet activity until sleepy\n• No clock watching\n\nHow many hours of sleep do you currently get?"
            
            elif any(word in user_lower for word in ['anxiety', 'anxious', 'worry']):
                return "Anxiety is treatable and manageable! Here are evidence-based techniques:\n\n**Immediate Anxiety Relief:**\n• 5-4-3-2-1 grounding: 5 things you see, 4 hear, 3 feel, 2 smell, 1 taste\n• Progressive muscle relaxation\n• Call someone you trust\n\n**Daily Anxiety Management:**\n• Regular exercise (reduces anxiety by 20-30%)\n• Limit news/social media\n• Practice mindfulness 10 minutes daily\n• Challenge anxious thoughts with evidence\n\n**Professional Help:**\n• Consider therapy (CBT is very effective)\n• Talk to doctor about medication if severe\n• Support groups (online or local)\n\nWhat triggers your anxiety most often?"
            
            else:
                return "I can help with specific health and wellness strategies:\n\n**Mental Health:**\n• Stress management techniques\n• Anxiety and depression support\n• Sleep optimization\n• Mindfulness and meditation\n\n**Physical Health:**\n• Exercise routines for beginners\n• Nutrition basics and meal planning\n• Energy and fatigue solutions\n• Habit building strategies\n\n**Preventive Care:**\n• Regular checkup scheduling\n• Health screening timelines\n• Supplement recommendations\n\nWhat specific health area would you like help with?"
        
        # CAREER & WORK ADVICE
        elif any(word in user_lower for word in ['work', 'job', 'career', 'boss', 'interview']):
            if any(word in user_lower for word in ['interview', 'interviewing']):
                return "Let's nail that interview! Here's the proven preparation strategy:\n\n**Research Phase:**\n• Company mission, values, recent news\n• Role requirements and team structure\n• Interviewer's background (LinkedIn)\n\n**Prepare STAR Stories:**\n• Situation, Task, Action, Result format\n• 3-5 specific examples of achievements\n• Practice out loud, time yourself\n\n**Common Questions to Prepare:**\n• 'Tell me about yourself' (2-minute elevator pitch)\n• 'Why this company/role?'\n• 'Biggest weakness' (real weakness + improvement plan)\n• 'Questions for us?' (always have 3-5 ready)\n\n**Day of Interview:**\n• Arrive 10 minutes early\n• Bring extra copies of resume\n• Send thank-you email within 24 hours\n\nWhat type of role are you interviewing for?"
            
            elif any(word in user_lower for word in ['raise', 'promotion', 'salary']):
                return "Time to get paid what you're worth! Here's the negotiation strategy:\n\n**Preparation (Do this first):**\n• Research market rates (Glassdoor, PayScale, levels.fyi)\n• Document your achievements and impact\n• Get competing offers if possible\n\n**The Ask:**\n• Schedule dedicated meeting\n• Present data, not emotions\n• Ask for 10-20% more than target\n• Include benefits, not just salary\n\n**Negotiation Script:**\n'Based on my research and contributions, I'd like to discuss adjusting my compensation to $X, which reflects market rate for my experience and performance.'\n\n**If They Say No:**\n• Ask what you need to do to get there\n• Request timeline for next review\n• Negotiate other benefits\n\nWhat's your current role and target salary?"
            
            else:
                return "I can help with specific career advancement strategies:\n\n**Job Search:**\n• Resume optimization\n• Interview preparation\n• Networking strategies\n• LinkedIn profile enhancement\n\n**Career Growth:**\n• Salary negotiation tactics\n• Promotion strategies\n• Skill development planning\n• Professional relationship building\n\n**Workplace Issues:**\n• Difficult boss/colleague management\n• Work-life balance\n• Career transition planning\n\nWhat specific career challenge are you facing?"
        
        # RELATIONSHIP ADVICE
        elif any(word in user_lower for word in ['relationship', 'dating', 'marriage', 'partner', 'boyfriend', 'girlfriend', 'spouse']):
            if any(word in user_lower for word in ['fight', 'argument', 'conflict']):
                return "Relationship conflicts are normal and can actually strengthen bonds when handled well! Here's how:\n\n**During the Conflict:**\n• Use 'I' statements: 'I feel...' not 'You always...'\n• Listen to understand, not to win\n• Take breaks if emotions get too high\n• Focus on the specific issue, not past grievances\n\n**Healthy Communication:**\n• Express needs clearly and directly\n• Validate their feelings even if you disagree\n• Find compromise where both feel heard\n• Apologize for your part without defending\n\n**Rebuilding After:**\n• Discuss what triggered the conflict\n• Agree on how to handle it better next time\n• Do something positive together\n\nWhat's the main issue you're having conflicts about?"
            
            elif any(word in user_lower for word in ['dating', 'single', 'meet']):
                return "Dating can be challenging but also exciting! Here's a strategic approach:\n\n**Before Dating:**\n• Know what you want in a partner\n• Work on being your best self\n• Build a fulfilling life independently\n• Address any past relationship baggage\n\n**Meeting People:**\n• Join activities you genuinely enjoy\n• Try dating apps with good photos and honest profile\n• Ask friends for introductions\n• Be open to meeting people in everyday situations\n\n**Early Dating Tips:**\n• Be authentic, not who you think they want\n• Ask questions and listen actively\n• Don't rush physical or emotional intimacy\n• Pay attention to red flags\n\nWhat's your biggest challenge with dating right now?"
            
            else:
                return "I can help with relationship guidance in these areas:\n\n**Communication:**\n• Conflict resolution strategies\n• Expressing needs effectively\n• Active listening techniques\n• Setting healthy boundaries\n\n**Dating & Relationships:**\n• Meeting compatible partners\n• Early relationship navigation\n• Building trust and intimacy\n• Long-term relationship maintenance\n\n**Difficult Situations:**\n• Dealing with jealousy\n• Rebuilding after betrayal\n• Knowing when to end relationships\n• Co-parenting strategies\n\nWhat specific relationship area would you like help with?"
        
        # GENERAL LIFE ADVICE
        else:
            return "I can provide specific, actionable guidance in these areas:\n\n**Financial:**\n• Credit score improvement (with specific action plans)\n• Investment strategies for beginners\n• Debt payoff optimization\n• Budgeting and saving systems\n\n**Health & Wellness:**\n• Stress management techniques\n• Sleep optimization protocols\n• Anxiety and depression support\n• Exercise and nutrition planning\n\n**Career & Work:**\n• Interview preparation strategies\n• Salary negotiation tactics\n• Career advancement planning\n• Workplace relationship management\n\n**Relationships:**\n• Communication and conflict resolution\n• Dating strategies and advice\n• Building stronger connections\n\nWhat specific area would you like detailed, actionable advice on?"
    
    def _generate_casual_response(self, user_input: str, emotion_analysis: Dict) -> str:
        """Generate warm, conversational response"""
        
        casual_openings = [
            "I love that you brought this up! ",
            "That's such an interesting way to think about it. ",
            "You know, that reminds me of something... ",
            "I'm curious about your perspective on this. "
        ]
        
        opening = casual_openings[self.conversation_count % len(casual_openings)]
        
        # Add conversational content
        if 'happy' in emotion_analysis['primary_emotion'] or emotion_analysis['textblob_polarity'] > 0.3:
            content = "There's something wonderful about sharing positive energy - it has a way of multiplying when we express it. "
            question = "What's been bringing you the most joy lately?"
        else:
            content = "Sometimes the most ordinary moments hold the most meaning when we really pay attention to them. "
            question = "What's been on your mind recently?"
        
        return opening + content + question
    
    def _generate_problem_solving_response(self, user_input: str, emotion_analysis: Dict) -> str:
        """Generate strategic, solution-oriented response"""
        
        acknowledgment = "I can see you're working through something important. "
        
        # Strategic thinking approach
        approach = "Let's think about this like architects designing a bridge - we need to understand both where you are now and where you want to be. "
        
        # Clarifying questions
        clarification = "To help you find the best path forward, I'd love to understand: what does success look like to you in this situation?"
        
        return acknowledgment + approach + clarification
    
    def _generate_default_response(self, user_input: str, emotion_analysis: Dict) -> str:
        """Generate default response with personality"""
        
        # Warm acknowledgment
        acknowledgment = "Thank you for sharing that with me. "
        
        # Curious engagement
        engagement = "I'm genuinely curious about your experience and perspective. "
        
        # Open-ended exploration
        exploration = "Sometimes the most meaningful conversations begin with the simplest observations. What aspect of this feels most significant to you?"
        
        return acknowledgment + engagement + exploration
    
    def _calculate_importance(self, emotion_analysis: Dict) -> float:
        """Calculate importance score for memory storage"""
        base_score = 0.5
        
        # High emotional intensity increases importance
        intensity_boost = emotion_analysis['intensity'] * 0.3
        
        # Certain emotions are more important to remember
        emotion_weights = {
            'sad': 0.8, 'angry': 0.7, 'anxious': 0.8, 'lonely': 0.9,
            'happy': 0.6, 'excited': 0.6, 'grateful': 0.7
        }
        
        emotion_boost = emotion_weights.get(emotion_analysis['primary_emotion'], 0.5) * 0.2
        
        # High confidence increases importance
        confidence_boost = emotion_analysis['confidence'] * 0.2
        
        total_score = min(base_score + intensity_boost + emotion_boost + confidence_boost, 1.0)
        return round(total_score, 2)
    
    def get_agent_status(self) -> Dict:
        """Get current agent status and statistics"""
        memory_stats = self.memory.get_memory_stats()
        
        return {
            'conversation_count': self.conversation_count,
            'personality_traits': self.personality_traits,
            'memory_stats': memory_stats,
            'voice_enabled': self.voice_interface.is_enabled if self.voice_interface else False,
            'components_active': {
                'memory_engine': True,
                'emotion_engine': True,
                'voice_interface': self.voice_interface is not None
            }
        }
    
    def update_personality_trait(self, trait: str, value: float):
        """Update personality trait (allows for personality evolution)"""
        if trait in self.personality_traits and 0.0 <= value <= 1.0:
            self.personality_traits[trait] = value
            print(f"Personality trait '{trait}' updated to {value}")
    
    def toggle_voice(self) -> bool:
        """Toggle voice interface"""
        if self.voice_interface:
            return self.voice_interface.toggle_voice()
        return False
    
    def _format_credit_cards(self, cards: list) -> str:
        """Format credit card recommendations"""
        if not cards:
            return "• No specific recommendations available"
        
        formatted = []
        for card in cards:
            formatted.append(f"• {card['name']}: {card.get('apr', 'N/A')} APR, {card.get('bonus', card.get('cashback', 'No bonus'))}")
        
        return "\n".join(formatted)
    
    def _format_investment_funds(self, funds: list) -> str:
        """Format investment fund recommendations"""
        if not funds:
            return "• No specific recommendations available"
        
        formatted = []
        for fund in funds:
            formatted.append(f"• {fund['symbol']} - {fund['name']} (Expense Ratio: {fund['expense_ratio']}%)")
        
        return "\n".join(formatted)
    
    def _format_salary_data(self, salary_data: dict) -> str:
        """Format salary negotiation data"""
        return f"${salary_data['range_low']:,} - ${salary_data['range_high']:,} (Median: ${salary_data['median']:,})"

# Test the agent
if __name__ == "__main__":
    print("Testing QueenCalifia-Ω Conversational Agent...")
    
    # Initialize agent
    agent = QueenCalifiaAgent()
    
    # Test conversations
    test_conversations = [
        "I'm feeling really overwhelmed with everything going on in my life",
        "Can you help me understand how to improve my credit score?",
        "I'm so excited about my new job opportunity!",
        "I don't know what to do about my relationship problems",
        "What's the meaning of life?",
        "I feel so alone and disconnected from everyone"
    ]
    
    print("\nTesting conversation responses...")
    for i, user_input in enumerate(test_conversations, 1):
        print(f"\n{'='*60}")
        print(f"Test {i}: {user_input}")
        print("-" * 60)
        
        response_package = agent.respond(user_input, f"test_user_{i}")
        
        print(f"Response: {response_package['response']}")
        print(f"Primary Emotion: {response_package['emotion_analysis']['primary_emotion']}")
        print(f"Tone: {response_package['emotion_analysis']['tone']}")
        print(f"Intensity: {response_package['emotion_analysis']['intensity']}")
        print(f"Processing Time: {response_package['processing_time']:.3f}s")
    
    # Test agent status
    print(f"\n{'='*60}")
    print("Agent Status:")
    status = agent.get_agent_status()
    for key, value in status.items():
        print(f"- {key}: {value}")
    
    print("\nQueenCalifia-Ω Agent test complete!")


    def _format_credit_cards(self, cards: list) -> str:
        """Format credit card recommendations"""
        if not cards:
            return "• No specific recommendations available"
        
        formatted = []
        for card in cards:
            formatted.append(f"• {card['name']}: {card.get('apr', 'N/A')} APR, {card.get('bonus', card.get('cashback', 'No bonus'))}")
        
        return "\n".join(formatted)
    
    def _format_investment_funds(self, funds: list) -> str:
        """Format investment fund recommendations"""
        if not funds:
            return "• No specific recommendations available"
        
        formatted = []
        for fund in funds:
            formatted.append(f"• {fund['symbol']} - {fund['name']} (Expense Ratio: {fund['expense_ratio']}%)")
        
        return "\n".join(formatted)
    
    def _format_salary_data(self, salary_data: dict) -> str:
        """Format salary negotiation data"""
        return f"${salary_data['range_low']:,} - ${salary_data['range_high']:,} (Median: ${salary_data['median']:,})"


    def _is_conversation_continuation(self, user_input: str, context: str) -> bool:
        """Detect if this is a continuation of an existing conversation thread"""
        # If no context, it's not a continuation
        if not context:
            return False
            
        # Check for short responses that typically continue conversations
        if len(user_input.split()) <= 5:
            return True
            
        # Check if the user input contains numbers only (like answering a question about amounts)
        if re.match(r'^[\d,.$]+$', user_input.strip()):
            return True
            
        # Check for credit card debt amount in response to a question
        if re.search(r'\d+', user_input) and any(phrase in context.lower() for phrase in ['debt amount', 'credit card', 'how much']):
            return True
            
        # Check for yes/no responses
        if user_input.lower() in ['yes', 'no', 'yeah', 'nope', 'yep', 'sure', 'ok', 'okay']:
            return True
            
        return False
        
    def _generate_continuation_response(self, user_input: str, context: str, emotion_analysis: Dict) -> str:
        """Generate a response that continues an existing conversation thread"""
        # Extract the last question we asked
        last_question = self._extract_last_question(context)
        
        # Check for credit score conversation continuation
        if 'credit score' in context.lower() and 'debt amount' in context.lower():
            # User is providing their debt amount
            try:
                # Try to extract a number from the input
                amount = re.search(r'(\d[\d,.]*)', user_input)
                if amount:
                    debt_amount = amount.group(1).replace(',', '')
                    return f"Thanks for sharing your credit card debt amount of ${debt_amount}. Based on this and your credit score, here's your personalized debt payoff plan:\n\n**Recommended Strategy:** Debt Avalanche\n\n**Step 1:** Make minimum payments on all cards\n**Step 2:** Put extra money toward highest interest rate card first\n**Step 3:** Once paid off, move to next highest interest rate\n\n**Expected Timeline:** With $100/month extra payment, you could be debt-free in approximately {int(float(debt_amount) / 100) + 3} months.\n\nWould you like me to help you create a specific budget to find that extra $100/month for debt payoff?"
            except:
                pass
                
        # Check for investment conversation continuation
        if 'invest' in context.lower() and any(word in user_input.lower() for word in ['beginner', 'new', 'start', 'first']):
            return "Perfect! For beginner investors with $10,000, here's your step-by-step plan:\n\n**Step 1: Emergency Fund**\n• Set aside 3-6 months of expenses in a high-yield savings account (currently earning ~4.5%)\n\n**Step 2: Tax-Advantaged Accounts**\n• Max out Roth IRA: $6,500/year\n• Invest in low-cost index funds like VTSAX (Vanguard Total Stock Market)\n\n**Step 3: Remaining Funds**\n• Consider a taxable brokerage account\n• 80% index funds / 20% bonds is a solid starting allocation\n\nWould you like specific fund recommendations for your Roth IRA?"
            
        # Generic continuation based on last question
        if 'what specific financial area' in context.lower():
            if any(word in user_input.lower() for word in ['credit', 'score', 'debt']):
                return "Great! For credit improvement, here's your 90-day action plan:\n\n**Days 1-30:**\n• Set up autopay for ALL bills\n• Dispute any errors on credit reports\n• Pay down highest utilization cards first\n\n**Days 31-60:**\n• Apply for a secured credit card if you don't have one\n• Keep utilization under 10% on all cards\n• Avoid closing old accounts\n\n**Days 61-90:**\n• Request credit limit increases\n• Consider becoming an authorized user on someone's good account\n• Check for collection accounts to settle\n\nWould you like me to help you with disputing errors on your credit report?"
            elif any(word in user_input.lower() for word in ['invest', 'stock', 'market']):
                return "For investing, I recommend this allocation based on current market conditions:\n\n**Core Portfolio (80%):**\n• 50% VTI - Total US Stock Market\n• 30% VXUS - International Stocks\n\n**Diversifiers (20%):**\n• 10% BND - Total Bond Market\n• 5% VNQ - Real Estate\n• 5% VTIP - Inflation-Protected Securities\n\nThis gives you broad diversification while maintaining growth potential. The current expected annual return is approximately 7-9% long-term.\n\nWould you like me to explain how to set up automatic investments into these funds?"
                
        # Default continuation response
        return "I see you're interested in continuing our conversation. To give you the most helpful advice, could you tell me more about your specific financial goals? For example, are you looking to improve your credit, save for a major purchase, or plan for retirement?"


    def _extract_last_question(self, context: str) -> str:
        """Extract the last question we asked the user"""
        # Split context into conversation turns
        turns = context.split('\n\n')
        
        # Look for the last response from Califia that contains a question
        for turn in reversed(turns):
            if turn.startswith('Califia:') and '?' in turn:
                return turn.replace('Califia:', '').strip()
                
        return ""

