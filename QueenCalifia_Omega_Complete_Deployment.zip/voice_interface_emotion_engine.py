"""
QueenCalifia-Ω Voice Interface and Advanced Emotion Analysis
STT/TTS Integration with ElevenLabs/Coqui and VADER/BERT Emotion Analysis
"""

import json
import os
import time
import threading
import wave
import pyaudio
import io
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
import numpy as np

# Voice processing imports
try:
    import speech_recognition as sr
    import pyttsx3
    BASIC_VOICE_AVAILABLE = True
except ImportError:
    BASIC_VOICE_AVAILABLE = False
    print("⚠️ Basic voice libraries not available")

# Advanced TTS imports
try:
    import requests
    ELEVENLABS_AVAILABLE = True
except ImportError:
    ELEVENLABS_AVAILABLE = False
    print("⚠️ ElevenLabs integration not available")

# Advanced emotion analysis imports
try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    VADER_AVAILABLE = True
except ImportError:
    VADER_AVAILABLE = False
    print("⚠️ VADER sentiment analysis not available")

try:
    from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
    BERT_AVAILABLE = True
except ImportError:
    BERT_AVAILABLE = False
    print("⚠️ BERT emotion analysis not available")

# Audio processing
try:
    import librosa
    import soundfile as sf
    AUDIO_PROCESSING_AVAILABLE = True
except ImportError:
    AUDIO_PROCESSING_AVAILABLE = False
    print("⚠️ Advanced audio processing not available")

class AdvancedEmotionEngine:
    """
    Advanced Emotion Analysis Engine
    Combines VADER, BERT, and custom rules for comprehensive emotion detection
    """
    
    def __init__(self):
        self.vader_analyzer = None
        self.bert_emotion_pipeline = None
        self.bert_sentiment_pipeline = None
        
        # Initialize VADER
        if VADER_AVAILABLE:
            self.vader_analyzer = SentimentIntensityAnalyzer()
            print("✅ VADER sentiment analyzer initialized")
        
        # Initialize BERT models
        if BERT_AVAILABLE:
            try:
                # Emotion classification model
                self.bert_emotion_pipeline = pipeline(
                    "text-classification",
                    model="j-hartmann/emotion-english-distilroberta-base",
                    device=-1  # Use CPU
                )
                
                # Sentiment analysis model
                self.bert_sentiment_pipeline = pipeline(
                    "sentiment-analysis",
                    model="cardiffnlp/twitter-roberta-base-sentiment-latest",
                    device=-1  # Use CPU
                )
                print("✅ BERT emotion models initialized")
            except Exception as e:
                print(f"⚠️ BERT model initialization failed: {e}")
                self.bert_emotion_pipeline = None
                self.bert_sentiment_pipeline = None
        
        # Emotion mapping and rules
        self.emotion_categories = {
            'positive': ['joy', 'happiness', 'excitement', 'love', 'gratitude', 'hope', 'pride'],
            'negative': ['sadness', 'anger', 'fear', 'anxiety', 'frustration', 'disappointment', 'guilt'],
            'neutral': ['neutral', 'calm', 'curiosity', 'surprise', 'confusion']
        }
        
        # Custom emotion rules
        self.emotion_keywords = {
            'anxiety': ['anxious', 'worried', 'nervous', 'stressed', 'overwhelmed', 'panic'],
            'depression': ['depressed', 'sad', 'hopeless', 'empty', 'worthless', 'lonely'],
            'anger': ['angry', 'furious', 'mad', 'irritated', 'frustrated', 'annoyed'],
            'fear': ['scared', 'afraid', 'terrified', 'frightened', 'worried', 'concerned'],
            'joy': ['happy', 'excited', 'thrilled', 'delighted', 'cheerful', 'elated'],
            'love': ['love', 'adore', 'cherish', 'appreciate', 'grateful', 'thankful'],
            'curiosity': ['curious', 'interested', 'wondering', 'questioning', 'exploring'],
            'confusion': ['confused', 'puzzled', 'uncertain', 'unclear', 'lost', 'bewildered']
        }
        
        print("🧠 Advanced Emotion Engine initialized")
    
    def analyze_emotion(self, text: str, include_confidence: bool = True) -> Dict[str, Any]:
        """
        Comprehensive emotion analysis using multiple methods
        """
        
        results = {
            'primary_emotion': 'neutral',
            'emotion_category': 'neutral',
            'intensity': 0.5,
            'confidence': 0.5,
            'detailed_emotions': {},
            'sentiment_scores': {},
            'analysis_methods': []
        }
        
        # VADER sentiment analysis
        if self.vader_analyzer:
            vader_results = self._analyze_with_vader(text)
            results['sentiment_scores']['vader'] = vader_results
            results['analysis_methods'].append('vader')
        
        # BERT emotion analysis
        if self.bert_emotion_pipeline:
            bert_emotion_results = self._analyze_with_bert_emotion(text)
            results['detailed_emotions']['bert'] = bert_emotion_results
            results['analysis_methods'].append('bert_emotion')
        
        # BERT sentiment analysis
        if self.bert_sentiment_pipeline:
            bert_sentiment_results = self._analyze_with_bert_sentiment(text)
            results['sentiment_scores']['bert'] = bert_sentiment_results
            results['analysis_methods'].append('bert_sentiment')
        
        # Custom keyword analysis
        keyword_results = self._analyze_with_keywords(text)
        results['detailed_emotions']['keywords'] = keyword_results
        results['analysis_methods'].append('keywords')
        
        # Combine results to determine primary emotion
        primary_emotion, intensity, confidence = self._combine_emotion_results(
            results['sentiment_scores'],
            results['detailed_emotions']
        )
        
        results['primary_emotion'] = primary_emotion
        results['intensity'] = intensity
        results['confidence'] = confidence
        results['emotion_category'] = self._categorize_emotion(primary_emotion)
        
        return results
    
    def _analyze_with_vader(self, text: str) -> Dict[str, float]:
        """Analyze sentiment using VADER"""
        
        scores = self.vader_analyzer.polarity_scores(text)
        
        return {
            'positive': scores['pos'],
            'negative': scores['neg'],
            'neutral': scores['neu'],
            'compound': scores['compound']
        }
    
    def _analyze_with_bert_emotion(self, text: str) -> List[Dict[str, Any]]:
        """Analyze emotions using BERT emotion model"""
        
        try:
            # Truncate text if too long
            if len(text) > 512:
                text = text[:512]
            
            results = self.bert_emotion_pipeline(text)
            
            # Convert to consistent format
            emotion_scores = []
            for result in results:
                emotion_scores.append({
                    'emotion': result['label'].lower(),
                    'score': result['score']
                })
            
            return emotion_scores
            
        except Exception as e:
            print(f"BERT emotion analysis error: {e}")
            return []
    
    def _analyze_with_bert_sentiment(self, text: str) -> Dict[str, float]:
        """Analyze sentiment using BERT sentiment model"""
        
        try:
            # Truncate text if too long
            if len(text) > 512:
                text = text[:512]
            
            results = self.bert_sentiment_pipeline(text)
            
            # Convert to consistent format
            sentiment_scores = {}
            for result in results:
                label = result['label'].lower()
                if 'positive' in label:
                    sentiment_scores['positive'] = result['score']
                elif 'negative' in label:
                    sentiment_scores['negative'] = result['score']
                else:
                    sentiment_scores['neutral'] = result['score']
            
            return sentiment_scores
            
        except Exception as e:
            print(f"BERT sentiment analysis error: {e}")
            return {}
    
    def _analyze_with_keywords(self, text: str) -> Dict[str, float]:
        """Analyze emotions using keyword matching"""
        
        text_lower = text.lower()
        emotion_scores = {}
        
        for emotion, keywords in self.emotion_keywords.items():
            matches = 0
            total_keywords = len(keywords)
            
            for keyword in keywords:
                if keyword in text_lower:
                    matches += 1
            
            if matches > 0:
                score = matches / total_keywords
                emotion_scores[emotion] = score
        
        return emotion_scores
    
    def _combine_emotion_results(self, sentiment_scores: Dict, detailed_emotions: Dict) -> Tuple[str, float, float]:
        """Combine results from different analysis methods"""
        
        emotion_weights = {}
        confidence_sum = 0
        total_methods = 0
        
        # Process VADER results
        if 'vader' in sentiment_scores:
            vader = sentiment_scores['vader']
            compound = vader['compound']
            
            if compound >= 0.5:
                emotion_weights['joy'] = abs(compound)
            elif compound <= -0.5:
                if vader['negative'] > 0.3:
                    emotion_weights['sadness'] = abs(compound)
                else:
                    emotion_weights['anger'] = abs(compound) * 0.8
            else:
                emotion_weights['neutral'] = 1 - abs(compound)
            
            confidence_sum += abs(compound)
            total_methods += 1
        
        # Process BERT emotion results
        if 'bert' in detailed_emotions:
            bert_emotions = detailed_emotions['bert']
            for emotion_data in bert_emotions:
                emotion = emotion_data['emotion']
                score = emotion_data['score']
                
                if emotion in emotion_weights:
                    emotion_weights[emotion] = max(emotion_weights[emotion], score)
                else:
                    emotion_weights[emotion] = score
                
                confidence_sum += score
            
            if bert_emotions:
                total_methods += 1
        
        # Process keyword results
        if 'keywords' in detailed_emotions:
            keyword_emotions = detailed_emotions['keywords']
            for emotion, score in keyword_emotions.items():
                if emotion in emotion_weights:
                    emotion_weights[emotion] = max(emotion_weights[emotion], score)
                else:
                    emotion_weights[emotion] = score
                
                confidence_sum += score
            
            if keyword_emotions:
                total_methods += 1
        
        # Determine primary emotion
        if emotion_weights:
            primary_emotion = max(emotion_weights, key=emotion_weights.get)
            intensity = emotion_weights[primary_emotion]
            confidence = confidence_sum / max(total_methods, 1)
        else:
            primary_emotion = 'neutral'
            intensity = 0.5
            confidence = 0.3
        
        return primary_emotion, min(1.0, intensity), min(1.0, confidence)
    
    def _categorize_emotion(self, emotion: str) -> str:
        """Categorize emotion into positive, negative, or neutral"""
        
        for category, emotions in self.emotion_categories.items():
            if emotion in emotions:
                return category
        
        return 'neutral'
    
    def get_emotion_insights(self, emotion_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate insights and recommendations based on emotion analysis"""
        
        primary_emotion = emotion_data['primary_emotion']
        intensity = emotion_data['intensity']
        category = emotion_data['emotion_category']
        
        insights = {
            'emotional_state': f"{primary_emotion} ({category})",
            'intensity_level': 'high' if intensity > 0.7 else 'medium' if intensity > 0.4 else 'low',
            'recommendations': [],
            'conversation_approach': 'balanced',
            'response_tone': 'neutral'
        }
        
        # Generate recommendations based on emotion
        if category == 'negative':
            if primary_emotion in ['anxiety', 'fear']:
                insights['recommendations'] = [
                    'Practice deep breathing exercises',
                    'Ground yourself with 5-4-3-2-1 technique',
                    'Consider talking to someone you trust'
                ]
                insights['conversation_approach'] = 'supportive'
                insights['response_tone'] = 'calm_reassuring'
            
            elif primary_emotion in ['sadness', 'depression']:
                insights['recommendations'] = [
                    'Acknowledge your feelings as valid',
                    'Engage in gentle self-care activities',
                    'Reach out for professional support if needed'
                ]
                insights['conversation_approach'] = 'empathetic'
                insights['response_tone'] = 'warm_understanding'
            
            elif primary_emotion in ['anger', 'frustration']:
                insights['recommendations'] = [
                    'Take a few minutes to cool down',
                    'Identify the root cause of frustration',
                    'Consider constructive ways to address the issue'
                ]
                insights['conversation_approach'] = 'validating'
                insights['response_tone'] = 'calm_direct'
        
        elif category == 'positive':
            insights['recommendations'] = [
                'Savor this positive moment',
                'Share your joy with others',
                'Use this energy for productive activities'
            ]
            insights['conversation_approach'] = 'enthusiastic'
            insights['response_tone'] = 'warm_encouraging'
        
        else:  # neutral
            insights['conversation_approach'] = 'exploratory'
            insights['response_tone'] = 'curious_friendly'
        
        return insights

class VoiceInterface:
    """
    Advanced Voice Interface with STT/TTS capabilities
    Supports multiple TTS engines including ElevenLabs and local engines
    """
    
    def __init__(self, emotion_engine: AdvancedEmotionEngine = None):
        self.emotion_engine = emotion_engine or AdvancedEmotionEngine()
        
        # Voice settings
        self.voice_enabled = False
        self.current_tts_engine = 'local'  # 'local', 'elevenlabs'
        self.voice_speed = 150
        self.voice_volume = 0.8
        
        # Audio settings
        self.sample_rate = 16000
        self.chunk_size = 1024
        self.audio_format = pyaudio.paInt16
        self.channels = 1
        
        # Initialize speech recognition
        if BASIC_VOICE_AVAILABLE:
            self.recognizer = sr.Recognizer()
            self.microphone = sr.Microphone()
            
            # Adjust for ambient noise
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=1)
            
            print("✅ Speech recognition initialized")
        
        # Initialize TTS engines
        self._initialize_tts_engines()
        
        # ElevenLabs settings
        self.elevenlabs_api_key = os.getenv('ELEVENLABS_API_KEY')
        self.elevenlabs_voice_id = "21m00Tcm4TlvDq8ikWAM"  # Default voice
        
        print("🎤 Voice Interface initialized")
    
    def _initialize_tts_engines(self):
        """Initialize text-to-speech engines"""
        
        # Local TTS engine
        if BASIC_VOICE_AVAILABLE:
            try:
                self.local_tts = pyttsx3.init()
                
                # Configure voice settings
                voices = self.local_tts.getProperty('voices')
                if voices:
                    # Prefer female voice if available
                    for voice in voices:
                        if 'female' in voice.name.lower() or 'zira' in voice.name.lower():
                            self.local_tts.setProperty('voice', voice.id)
                            break
                
                self.local_tts.setProperty('rate', self.voice_speed)
                self.local_tts.setProperty('volume', self.voice_volume)
                
                print("✅ Local TTS engine initialized")
                
            except Exception as e:
                print(f"⚠️ Local TTS initialization failed: {e}")
                self.local_tts = None
        else:
            self.local_tts = None
    
    def toggle_voice(self) -> bool:
        """Toggle voice interface on/off"""
        
        self.voice_enabled = not self.voice_enabled
        status = "enabled" if self.voice_enabled else "disabled"
        print(f"🎤 Voice interface {status}")
        
        return self.voice_enabled
    
    def set_tts_engine(self, engine: str) -> bool:
        """Set TTS engine ('local' or 'elevenlabs')"""
        
        if engine == 'elevenlabs' and not self.elevenlabs_api_key:
            print("⚠️ ElevenLabs API key not found")
            return False
        
        if engine in ['local', 'elevenlabs']:
            self.current_tts_engine = engine
            print(f"🔊 TTS engine set to {engine}")
            return True
        
        return False
    
    def listen_for_speech(self, timeout: int = 5, phrase_timeout: int = 1) -> Optional[str]:
        """Listen for speech input and convert to text"""
        
        if not BASIC_VOICE_AVAILABLE or not self.voice_enabled:
            return None
        
        try:
            print("🎤 Listening...")
            
            with self.microphone as source:
                # Listen for audio with timeout
                audio = self.recognizer.listen(
                    source, 
                    timeout=timeout, 
                    phrase_time_limit=phrase_timeout
                )
            
            print("🔄 Processing speech...")
            
            # Convert speech to text
            text = self.recognizer.recognize_google(audio)
            print(f"📝 Recognized: {text}")
            
            return text
            
        except sr.WaitTimeoutError:
            print("⏰ Listening timeout")
            return None
        except sr.UnknownValueError:
            print("❓ Could not understand audio")
            return None
        except sr.RequestError as e:
            print(f"❌ Speech recognition error: {e}")
            return None
    
    def speak_text(self, text: str, emotion_context: Dict[str, Any] = None) -> bool:
        """Convert text to speech with emotion-aware delivery"""
        
        if not self.voice_enabled:
            return False
        
        # Adjust speech parameters based on emotion
        if emotion_context:
            self._adjust_speech_for_emotion(emotion_context)
        
        # Choose TTS engine
        if self.current_tts_engine == 'elevenlabs' and self.elevenlabs_api_key:
            return self._speak_with_elevenlabs(text, emotion_context)
        else:
            return self._speak_with_local_tts(text)
    
    def _speak_with_local_tts(self, text: str) -> bool:
        """Speak using local TTS engine"""
        
        if not self.local_tts:
            print("⚠️ Local TTS not available")
            return False
        
        try:
            self.local_tts.say(text)
            self.local_tts.runAndWait()
            return True
            
        except Exception as e:
            print(f"❌ Local TTS error: {e}")
            return False
    
    def _speak_with_elevenlabs(self, text: str, emotion_context: Dict[str, Any] = None) -> bool:
        """Speak using ElevenLabs TTS API"""
        
        if not ELEVENLABS_AVAILABLE or not self.elevenlabs_api_key:
            print("⚠️ ElevenLabs not available")
            return self._speak_with_local_tts(text)
        
        try:
            # ElevenLabs API endpoint
            url = f"https://api.elevenlabs.io/v1/text-to-speech/{self.elevenlabs_voice_id}"
            
            headers = {
                "Accept": "audio/mpeg",
                "Content-Type": "application/json",
                "xi-api-key": self.elevenlabs_api_key
            }
            
            # Adjust voice settings based on emotion
            voice_settings = {
                "stability": 0.75,
                "similarity_boost": 0.75,
                "style": 0.5,
                "use_speaker_boost": True
            }
            
            if emotion_context:
                primary_emotion = emotion_context.get('primary_emotion', 'neutral')
                intensity = emotion_context.get('intensity', 0.5)
                
                if primary_emotion in ['joy', 'excitement']:
                    voice_settings["style"] = min(1.0, 0.5 + intensity * 0.3)
                elif primary_emotion in ['sadness', 'depression']:
                    voice_settings["stability"] = max(0.3, 0.75 - intensity * 0.2)
                elif primary_emotion in ['anger', 'frustration']:
                    voice_settings["similarity_boost"] = min(1.0, 0.75 + intensity * 0.2)
            
            data = {
                "text": text,
                "model_id": "eleven_monolingual_v1",
                "voice_settings": voice_settings
            }
            
            response = requests.post(url, json=data, headers=headers, timeout=30)
            
            if response.status_code == 200:
                # Play audio
                audio_data = response.content
                self._play_audio_data(audio_data)
                return True
            else:
                print(f"❌ ElevenLabs API error: {response.status_code}")
                return self._speak_with_local_tts(text)
                
        except Exception as e:
            print(f"❌ ElevenLabs TTS error: {e}")
            return self._speak_with_local_tts(text)
    
    def _play_audio_data(self, audio_data: bytes):
        """Play audio data"""
        
        try:
            if AUDIO_PROCESSING_AVAILABLE:
                # Use librosa/soundfile for better audio handling
                audio_io = io.BytesIO(audio_data)
                data, samplerate = sf.read(audio_io)
                
                # Play using pyaudio
                p = pyaudio.PyAudio()
                stream = p.open(
                    format=pyaudio.paFloat32,
                    channels=1 if len(data.shape) == 1 else data.shape[1],
                    rate=samplerate,
                    output=True
                )
                
                stream.write(data.astype(np.float32).tobytes())
                stream.stop_stream()
                stream.close()
                p.terminate()
            else:
                # Fallback: save and play file
                temp_file = "temp_audio.mp3"
                with open(temp_file, "wb") as f:
                    f.write(audio_data)
                
                # Try to play with system command
                import subprocess
                try:
                    subprocess.run(["mpg123", temp_file], check=True, capture_output=True)
                except:
                    try:
                        subprocess.run(["afplay", temp_file], check=True, capture_output=True)
                    except:
                        print("⚠️ Could not play audio - no suitable player found")
                
                # Clean up
                if os.path.exists(temp_file):
                    os.remove(temp_file)
                    
        except Exception as e:
            print(f"❌ Audio playback error: {e}")
    
    def _adjust_speech_for_emotion(self, emotion_context: Dict[str, Any]):
        """Adjust speech parameters based on emotion context"""
        
        if not self.local_tts:
            return
        
        primary_emotion = emotion_context.get('primary_emotion', 'neutral')
        intensity = emotion_context.get('intensity', 0.5)
        
        # Base settings
        base_rate = 150
        base_volume = 0.8
        
        # Adjust based on emotion
        if primary_emotion in ['joy', 'excitement']:
            # Faster, more energetic
            rate = int(base_rate * (1 + intensity * 0.3))
            volume = min(1.0, base_volume * (1 + intensity * 0.2))
        
        elif primary_emotion in ['sadness', 'depression']:
            # Slower, softer
            rate = int(base_rate * (1 - intensity * 0.2))
            volume = max(0.3, base_volume * (1 - intensity * 0.3))
        
        elif primary_emotion in ['anger', 'frustration']:
            # Slightly faster, more assertive
            rate = int(base_rate * (1 + intensity * 0.1))
            volume = min(1.0, base_volume * (1 + intensity * 0.1))
        
        elif primary_emotion in ['anxiety', 'fear']:
            # Calmer, reassuring
            rate = int(base_rate * (1 - intensity * 0.1))
            volume = base_volume
        
        else:
            # Neutral
            rate = base_rate
            volume = base_volume
        
        try:
            self.local_tts.setProperty('rate', rate)
            self.local_tts.setProperty('volume', volume)
        except Exception as e:
            print(f"⚠️ Could not adjust speech parameters: {e}")
    
    def process_voice_interaction(self, conversation_agent, user_id: str = "default") -> Optional[Dict[str, Any]]:
        """Complete voice interaction cycle: listen -> process -> respond"""
        
        if not self.voice_enabled:
            return None
        
        # Listen for user input
        user_speech = self.listen_for_speech(timeout=10, phrase_timeout=3)
        
        if not user_speech:
            return None
        
        # Analyze emotion in speech
        emotion_data = self.emotion_engine.analyze_emotion(user_speech)
        
        # Get response from conversation agent
        response_data = conversation_agent.respond(
            user_input=user_speech,
            user_id=user_id,
            context={'voice_interaction': True, 'emotion_data': emotion_data}
        )
        
        # Speak the response
        response_text = response_data['response']
        
        # Clean response for speech (remove markdown formatting)
        clean_response = self._clean_text_for_speech(response_text)
        
        # Speak with emotion context
        speech_success = self.speak_text(clean_response, emotion_data)
        
        return {
            'user_speech': user_speech,
            'emotion_data': emotion_data,
            'response_data': response_data,
            'speech_success': speech_success,
            'clean_response': clean_response
        }
    
    def _clean_text_for_speech(self, text: str) -> str:
        """Clean text for better speech synthesis"""
        
        import re
        
        # Remove markdown formatting
        text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # Bold
        text = re.sub(r'\*(.*?)\*', r'\1', text)      # Italic
        text = re.sub(r'`(.*?)`', r'\1', text)        # Code
        text = re.sub(r'#{1,6}\s*(.*)', r'\1', text)  # Headers
        text = re.sub(r'^\s*[•\-\*]\s*', '', text, flags=re.MULTILINE)  # Bullet points
        text = re.sub(r'^\s*\d+\.\s*', '', text, flags=re.MULTILINE)    # Numbered lists
        
        # Replace special characters
        text = text.replace('&', ' and ')
        text = text.replace('@', ' at ')
        text = text.replace('#', ' number ')
        text = text.replace('%', ' percent')
        text = text.replace('$', ' dollars ')
        
        # Clean up whitespace
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()
        
        # Limit length for TTS
        if len(text) > 500:
            sentences = text.split('.')
            truncated = []
            current_length = 0
            
            for sentence in sentences:
                if current_length + len(sentence) < 450:
                    truncated.append(sentence)
                    current_length += len(sentence)
                else:
                    break
            
            text = '. '.join(truncated)
            if not text.endswith('.'):
                text += '.'
        
        return text
    
    def get_voice_status(self) -> Dict[str, Any]:
        """Get current voice interface status"""
        
        return {
            'voice_enabled': self.voice_enabled,
            'tts_engine': self.current_tts_engine,
            'speech_recognition_available': BASIC_VOICE_AVAILABLE,
            'elevenlabs_available': ELEVENLABS_AVAILABLE and bool(self.elevenlabs_api_key),
            'local_tts_available': self.local_tts is not None,
            'audio_processing_available': AUDIO_PROCESSING_AVAILABLE,
            'voice_settings': {
                'speed': self.voice_speed,
                'volume': self.voice_volume,
                'sample_rate': self.sample_rate
            }
        }

# Example usage and testing
if __name__ == "__main__":
    print("🎤 Testing QueenCalifia-Ω Voice Interface and Emotion Analysis...")
    
    # Initialize emotion engine
    emotion_engine = AdvancedEmotionEngine()
    
    # Test emotion analysis
    print("\n🧠 Testing Emotion Analysis:")
    test_texts = [
        "I'm feeling really anxious about my job interview tomorrow",
        "I'm so excited about my vacation next week!",
        "I'm frustrated with my credit card debt situation",
        "Can you help me understand quantum computing?",
        "I feel hopeless and don't know what to do"
    ]
    
    for text in test_texts:
        emotion_data = emotion_engine.analyze_emotion(text)
        insights = emotion_engine.get_emotion_insights(emotion_data)
        
        print(f"\nText: {text}")
        print(f"Emotion: {emotion_data['primary_emotion']} ({emotion_data['emotion_category']})")
        print(f"Intensity: {emotion_data['intensity']:.2f}")
        print(f"Confidence: {emotion_data['confidence']:.2f}")
        print(f"Approach: {insights['conversation_approach']}")
        print(f"Tone: {insights['response_tone']}")
    
    # Initialize voice interface
    print("\n🎤 Testing Voice Interface:")
    voice_interface = VoiceInterface(emotion_engine)
    
    # Test voice status
    status = voice_interface.get_voice_status()
    print(f"Voice Status:")
    for key, value in status.items():
        print(f"  {key}: {value}")
    
    # Test TTS (if available)
    if status['local_tts_available']:
        print("\n🔊 Testing Text-to-Speech:")
        test_response = "Hello! I'm QueenCalifia Omega, your quantum-enhanced AI assistant. I'm here to provide specific, actionable advice to help you achieve your goals."
        
        voice_interface.toggle_voice()  # Enable voice
        success = voice_interface.speak_text(test_response)
        print(f"TTS Test: {'Success' if success else 'Failed'}")
    
    print("\n✅ Voice Interface and Emotion Analysis test completed!")

