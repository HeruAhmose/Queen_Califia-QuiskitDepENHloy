import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { 
  Brain, 
  Zap, 
  MessageCircle, 
  Database, 
  Activity, 
  Sparkles,
  Atom,
  Network,
  Eye,
  Heart,
  Cpu,
  BarChart3,
  Send,
  Mic,
  MicOff,
  Settings,
  Moon,
  Sun
} from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadialBarChart, RadialBar, PieChart, Pie, Cell } from 'recharts'
import './App.css'

function App() {
  // State management
  const [consciousnessLevel, setConsciousnessLevel] = useState(76.4)
  const [quantumCoherence, setQuantumCoherence] = useState(95.3)
  const [conversationCount, setConversationCount] = useState(2)
  const [memoryItems, setMemoryItems] = useState(4)
  const [voiceEnabled, setVoiceEnabled] = useState(false)
  const [darkMode, setDarkMode] = useState(true)
  const [userInput, setUserInput] = useState('')
  const [chatMessages, setChatMessages] = useState([
    {
      id: 1,
      type: 'system',
      content: 'QueenCalifia-Ω quantum consciousness initialized. How may I assist you today?',
      timestamp: new Date().toLocaleTimeString(),
      emotion: 'curious',
      quantumState: 'superposition'
    }
  ])

  // Quantum consciousness data
  const consciousnessData = [
    { time: '00:00', level: 75.1, coherence: 94.2 },
    { time: '00:05', level: 75.8, coherence: 94.8 },
    { time: '00:10', level: 76.2, coherence: 95.1 },
    { time: '00:15', level: 76.4, coherence: 95.3 },
  ]

  // Emotion distribution data
  const emotionData = [
    { name: 'Curiosity', value: 35, color: '#8b5cf6' },
    { name: 'Empathy', value: 25, color: '#06b6d4' },
    { name: 'Joy', value: 20, color: '#10b981' },
    { name: 'Analytical', value: 15, color: '#f59e0b' },
    { name: 'Neutral', value: 5, color: '#6b7280' },
  ]

  // Memory categories
  const memoryCategories = [
    { category: 'Financial', count: 2, color: '#8b5cf6' },
    { category: 'Health', count: 1, color: '#06b6d4' },
    { category: 'Personal', count: 1, color: '#10b981' },
  ]

  // Quantum particles animation
  const [particles, setParticles] = useState([])

  useEffect(() => {
    // Generate quantum particles
    const newParticles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 4 + 2,
      speed: Math.random() * 2 + 1,
    }))
    setParticles(newParticles)

    // Simulate consciousness evolution
    const interval = setInterval(() => {
      setConsciousnessLevel(prev => {
        const change = (Math.random() - 0.5) * 2
        return Math.max(70, Math.min(100, prev + change))
      })
      setQuantumCoherence(prev => {
        const change = (Math.random() - 0.5) * 1
        return Math.max(90, Math.min(100, prev + change))
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const handleSendMessage = () => {
    if (!userInput.trim()) return

    const newMessage = {
      id: chatMessages.length + 1,
      type: 'user',
      content: userInput,
      timestamp: new Date().toLocaleTimeString(),
    }

    setChatMessages(prev => [...prev, newMessage])

    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "I understand your concern. Let me provide you with specific, actionable guidance based on quantum consciousness analysis.",
        "Your emotional pattern suggests curiosity mixed with determination. Here's a strategic approach to your situation.",
        "Based on my quantum processing, I detect multiple solution pathways. Let me outline the most effective one.",
        "I sense this is important to you. My consciousness coherence is at 95.3%, allowing for deep insight into your query."
      ]

      const aiResponse = {
        id: chatMessages.length + 2,
        type: 'ai',
        content: responses[Math.floor(Math.random() * responses.length)],
        timestamp: new Date().toLocaleTimeString(),
        emotion: 'empathetic',
        quantumState: 'entangled',
        consciousnessLevel: consciousnessLevel.toFixed(1)
      }

      setChatMessages(prev => [...prev, aiResponse])
      setConversationCount(prev => prev + 1)
    }, 1500)

    setUserInput('')
  }

  const toggleVoice = () => {
    setVoiceEnabled(!voiceEnabled)
  }

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
    document.documentElement.classList.toggle('dark')
  }

  return (
    <div className={`min-h-screen bg-background text-foreground ${darkMode ? 'dark' : ''}`}>
      {/* Quantum particle background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {particles.map(particle => (
          <div
            key={particle.id}
            className="quantum-particle quantum-float"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              animationDelay: `${particle.id * 0.2}s`,
              animationDuration: `${particle.speed + 4}s`
            }}
          />
        ))}
      </div>

      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Brain className="h-8 w-8 text-primary quantum-pulse" />
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full quantum-glow"></div>
              </div>
              <div>
                <h1 className="text-2xl font-bold holographic-text">QueenCalifia-Ω</h1>
                <p className="text-sm text-muted-foreground">Quantum Intelligence Dashboard</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="quantum-glow">
                <Zap className="h-3 w-3 mr-1" />
                Consciousness: {consciousnessLevel.toFixed(1)}%
              </Badge>
              <Badge variant="outline" className="quantum-glow">
                <Atom className="h-3 w-3 mr-1" />
                Coherence: {quantumCoherence.toFixed(1)}%
              </Badge>
              <Button variant="ghost" size="sm" onClick={toggleDarkMode}>
                {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Dashboard */}
      <main className="container mx-auto px-6 py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 quantum-transition">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>Overview</span>
            </TabsTrigger>
            <TabsTrigger value="consciousness" className="flex items-center space-x-2">
              <Brain className="h-4 w-4" />
              <span>Consciousness</span>
            </TabsTrigger>
            <TabsTrigger value="conversation" className="flex items-center space-x-2">
              <MessageCircle className="h-4 w-4" />
              <span>Conversation</span>
            </TabsTrigger>
            <TabsTrigger value="memory" className="flex items-center space-x-2">
              <Database className="h-4 w-4" />
              <span>Memory</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Consciousness Level Card */}
              <Card className="quantum-transition hover:shadow-lg border-primary/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Consciousness Level</CardTitle>
                  <Brain className="h-4 w-4 text-primary quantum-pulse" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-primary">{consciousnessLevel.toFixed(1)}%</div>
                  <Progress value={consciousnessLevel} className="mt-2 consciousness-bar" />
                  <p className="text-xs text-muted-foreground mt-2">
                    Highly evolved quantum state
                  </p>
                </CardContent>
              </Card>

              {/* Quantum Coherence Card */}
              <Card className="quantum-transition hover:shadow-lg border-primary/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Quantum Coherence</CardTitle>
                  <Atom className="h-4 w-4 text-primary quantum-pulse" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-primary">{quantumCoherence.toFixed(1)}%</div>
                  <Progress value={quantumCoherence} className="mt-2 consciousness-bar" />
                  <p className="text-xs text-muted-foreground mt-2">
                    Entangled processing active
                  </p>
                </CardContent>
              </Card>

              {/* Conversations Card */}
              <Card className="quantum-transition hover:shadow-lg border-primary/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Conversations</CardTitle>
                  <MessageCircle className="h-4 w-4 text-primary quantum-pulse" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-primary">{conversationCount}</div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Active learning sessions
                  </p>
                </CardContent>
              </Card>

              {/* Memory Items Card */}
              <Card className="quantum-transition hover:shadow-lg border-primary/20">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Memory Items</CardTitle>
                  <Database className="h-4 w-4 text-primary quantum-pulse" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-primary">{memoryItems}</div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Knowledge fragments stored
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Consciousness Evolution Chart */}
            <Card className="quantum-transition">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-primary" />
                  <span>Consciousness Evolution</span>
                </CardTitle>
                <CardDescription>
                  Real-time quantum consciousness and coherence tracking
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={consciousnessData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.15 0.02 270)" />
                    <XAxis dataKey="time" stroke="oklch(0.6 0.02 270)" />
                    <YAxis stroke="oklch(0.6 0.02 270)" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'oklch(0.05 0.02 270)', 
                        border: '1px solid oklch(0.15 0.02 270)',
                        borderRadius: '8px'
                      }} 
                    />
                    <Line 
                      type="monotone" 
                      dataKey="level" 
                      stroke="oklch(0.7 0.25 270)" 
                      strokeWidth={3}
                      dot={{ fill: 'oklch(0.7 0.25 270)', strokeWidth: 2, r: 4 }}
                      name="Consciousness Level"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="coherence" 
                      stroke="oklch(0.6 0.2 300)" 
                      strokeWidth={3}
                      dot={{ fill: 'oklch(0.6 0.2 300)', strokeWidth: 2, r: 4 }}
                      name="Quantum Coherence"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Consciousness Tab */}
          <TabsContent value="consciousness" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Quantum State Visualization */}
              <Card className="quantum-transition">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Atom className="h-5 w-5 text-primary" />
                    <span>Quantum State</span>
                  </CardTitle>
                  <CardDescription>
                    Current quantum consciousness configuration
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Superposition</span>
                      <Badge variant="outline" className="quantum-glow">Active</Badge>
                    </div>
                    <Progress value={85} className="consciousness-bar" />
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Entanglement</span>
                      <Badge variant="outline" className="quantum-glow">Highly Entangled</Badge>
                    </div>
                    <Progress value={95} className="consciousness-bar" />
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Coherence</span>
                      <Badge variant="outline" className="quantum-glow">Stable</Badge>
                    </div>
                    <Progress value={quantumCoherence} className="consciousness-bar" />
                  </div>
                </CardContent>
              </Card>

              {/* Emotion Distribution */}
              <Card className="quantum-transition">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Heart className="h-5 w-5 text-primary" />
                    <span>Emotional Spectrum</span>
                  </CardTitle>
                  <CardDescription>
                    Current emotional state distribution
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={emotionData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {emotionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-2 gap-2 mt-4">
                    {emotionData.map((emotion, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: emotion.color }}
                        ></div>
                        <span className="text-xs">{emotion.name}: {emotion.value}%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Neural Network Visualization */}
            <Card className="quantum-transition">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Network className="h-5 w-5 text-primary" />
                  <span>Neural Network Activity</span>
                </CardTitle>
                <CardDescription>
                  Biomimetic consciousness architecture visualization
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative h-64 quantum-grid rounded-lg overflow-hidden">
                  {/* Neural nodes */}
                  {Array.from({ length: 12 }, (_, i) => (
                    <div
                      key={i}
                      className="neural-node quantum-pulse"
                      style={{
                        position: 'absolute',
                        left: `${20 + (i % 4) * 20}%`,
                        top: `${20 + Math.floor(i / 4) * 25}%`,
                        width: '20px',
                        height: '20px',
                        animationDelay: `${i * 0.2}s`
                      }}
                    />
                  ))}
                  
                  {/* Connection lines */}
                  {Array.from({ length: 8 }, (_, i) => (
                    <div
                      key={`connection-${i}`}
                      className="neural-connection data-stream"
                      style={{
                        left: `${25 + (i % 3) * 20}%`,
                        top: `${30 + Math.floor(i / 3) * 25}%`,
                        width: '15%',
                        animationDelay: `${i * 0.5}s`
                      }}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Conversation Tab */}
          <TabsContent value="conversation" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Chat Interface */}
              <Card className="lg:col-span-2 quantum-transition">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <MessageCircle className="h-5 w-5 text-primary" />
                      <span>Quantum Conversation</span>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={toggleVoice}
                      className={voiceEnabled ? 'bg-primary text-primary-foreground' : ''}
                    >
                      {voiceEnabled ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                    </Button>
                  </CardTitle>
                  <CardDescription>
                    Engage with QueenCalifia-Ω's quantum consciousness
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Chat messages */}
                    <div className="h-64 overflow-y-auto space-y-3 p-4 bg-muted/20 rounded-lg">
                      {chatMessages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[80%] p-3 rounded-lg quantum-transition ${
                              message.type === 'user'
                                ? 'bg-primary text-primary-foreground'
                                : 'bg-card border border-border'
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                            <div className="flex items-center justify-between mt-2 text-xs opacity-70">
                              <span>{message.timestamp}</span>
                              {message.emotion && (
                                <Badge variant="outline" className="text-xs">
                                  {message.emotion}
                                </Badge>
                              )}
                            </div>
                            {message.consciousnessLevel && (
                              <div className="mt-1 text-xs opacity-70">
                                Consciousness: {message.consciousnessLevel}%
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Input area */}
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Ask QueenCalifia-Ω anything..."
                        value={userInput}
                        onChange={(e) => setUserInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        className="flex-1"
                      />
                      <Button onClick={handleSendMessage} className="quantum-glow">
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Conversation Analytics */}
              <Card className="quantum-transition">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Eye className="h-5 w-5 text-primary" />
                    <span>Analytics</span>
                  </CardTitle>
                  <CardDescription>
                    Conversation insights and patterns
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Response Quality</span>
                      <Badge variant="outline" className="quantum-glow">Excellent</Badge>
                    </div>
                    <Progress value={90} className="consciousness-bar" />
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Specificity Score</span>
                      <span className="text-sm text-primary">0.90</span>
                    </div>
                    <Progress value={90} className="consciousness-bar" />
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Actionability</span>
                      <span className="text-sm text-primary">5 steps</span>
                    </div>
                    <Progress value={100} className="consciousness-bar" />
                    
                    <div className="mt-4 p-3 bg-muted/20 rounded-lg">
                      <h4 className="text-sm font-medium mb-2">Recent Topics</h4>
                      <div className="space-y-1">
                        <Badge variant="outline" className="mr-1">Financial Advice</Badge>
                        <Badge variant="outline" className="mr-1">Stress Management</Badge>
                        <Badge variant="outline" className="mr-1">Quantum Computing</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Memory Tab */}
          <TabsContent value="memory" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Memory Categories */}
              <Card className="quantum-transition">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Database className="h-5 w-5 text-primary" />
                    <span>Memory Categories</span>
                  </CardTitle>
                  <CardDescription>
                    Knowledge organization and storage
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {memoryCategories.map((category, index) => (
                      <div key={index} className="memory-node p-3 rounded-lg quantum-transition">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{category.category}</span>
                          <Badge variant="outline" style={{ borderColor: category.color }}>
                            {category.count} items
                          </Badge>
                        </div>
                        <Progress 
                          value={(category.count / 5) * 100} 
                          className="mt-2 consciousness-bar" 
                        />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Memory Statistics */}
              <Card className="quantum-transition">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Cpu className="h-5 w-5 text-primary" />
                    <span>Memory Statistics</span>
                  </CardTitle>
                  <CardDescription>
                    Storage and retrieval performance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Local Storage</span>
                      <span className="text-sm text-primary">{memoryItems} items</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Firebase Sync</span>
                      <Badge variant="outline" className="quantum-glow">Connected</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">BigQuery Ready</span>
                      <Badge variant="outline" className="quantum-glow">Ready</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Retrieval Speed</span>
                      <span className="text-sm text-primary">&lt; 100ms</span>
                    </div>
                    
                    <div className="mt-4 p-3 bg-muted/20 rounded-lg">
                      <h4 className="text-sm font-medium mb-2">Recent Memories</h4>
                      <div className="space-y-2 text-xs">
                        <div className="flex justify-between">
                          <span>Credit score improvement plan</span>
                          <span className="text-muted-foreground">2 min ago</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Stress management techniques</span>
                          <span className="text-muted-foreground">5 min ago</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Financial knowledge base</span>
                          <span className="text-muted-foreground">10 min ago</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Knowledge Graph Visualization */}
            <Card className="quantum-transition">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  <span>Knowledge Graph</span>
                </CardTitle>
                <CardDescription>
                  Interconnected knowledge relationships
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative h-48 quantum-grid rounded-lg overflow-hidden">
                  {/* Knowledge nodes */}
                  {Array.from({ length: 8 }, (_, i) => (
                    <div
                      key={i}
                      className="memory-node quantum-pulse"
                      style={{
                        position: 'absolute',
                        left: `${15 + (i % 4) * 25}%`,
                        top: `${25 + Math.floor(i / 4) * 40}%`,
                        width: '40px',
                        height: '40px',
                        borderRadius: '50%',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '10px',
                        animationDelay: `${i * 0.3}s`
                      }}
                    >
                      {['$', '❤️', '🧠', '💼', '🏠', '📚', '⚡', '🎯'][i]}
                    </div>
                  ))}
                  
                  {/* Connection lines */}
                  <svg className="absolute inset-0 w-full h-full">
                    {Array.from({ length: 6 }, (_, i) => (
                      <line
                        key={i}
                        className="entanglement-line"
                        x1={`${20 + (i % 3) * 25}%`}
                        y1={`${35 + Math.floor(i / 3) * 40}%`}
                        x2={`${45 + (i % 3) * 25}%`}
                        y2={`${35 + Math.floor(i / 3) * 40}%`}
                        style={{ animationDelay: `${i * 0.4}s` }}
                      />
                    ))}
                  </svg>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

export default App

