"""
QueenCalifia-Ω Simplified Emotion Engine
VADER-based emotion analysis with fallback capabilities
"""

import json
import os
import time
import re
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple

# Emotion analysis imports
try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    VADER_AVAILABLE = True
except ImportError:
    VADER_AVAILABLE = False
    print("⚠️ VADER sentiment analysis not available")

class EmotionEngine:
    """
    Simplified Emotion Analysis Engine
    Uses VADER sentiment analysis with custom emotion mapping
    """
    
    def __init__(self):
        # Initialize VADER
        if VADER_AVAILABLE:
            self.vader_analyzer = SentimentIntensityAnalyzer()
            print("✅ VADER sentiment analyzer initialized")
        else:
            self.vader_analyzer = None
        
        # Emotion mapping and rules
        self.emotion_categories = {
            'positive': ['joy', 'happiness', 'excitement', 'love', 'gratitude', 'hope', 'pride'],
            'negative': ['sadness', 'anger', 'fear', 'anxiety', 'frustration', 'disappointment', 'guilt'],
            'neutral': ['neutral', 'calm', 'curiosity', 'surprise', 'confusion']
        }
        
        # Custom emotion keywords
        self.emotion_keywords = {
            'anxiety': ['anxious', 'worried', 'nervous', 'stressed', 'overwhelmed', 'panic'],
            'depression': ['depressed', 'sad', 'hopeless', 'empty', 'worthless', 'lonely'],
            'anger': ['angry', 'furious', 'mad', 'irritated', 'frustrated', 'annoyed'],
            'fear': ['scared', 'afraid', 'terrified', 'frightened', 'worried', 'concerned'],
            'joy': ['happy', 'excited', 'thrilled', 'delighted', 'cheerful', 'elated'],
            'love': ['love', 'adore', 'cherish', 'appreciate', 'grateful', 'thankful'],
            'curiosity': ['curious', 'interested', 'wondering', 'questioning', 'exploring'],
            'confusion': ['confused', 'puzzled', 'uncertain', 'unclear', 'lost', 'bewildered']
        }
        
        print("🧠 Emotion Engine initialized")
    
    def analyze_emotion(self, text: str, include_confidence: bool = True) -> Dict[str, Any]:
        """
        Analyze emotion using VADER and keyword matching
        """
        
        results = {
            'primary_emotion': 'neutral',
            'emotion_category': 'neutral',
            'intensity': 0.5,
            'confidence': 0.5,
            'sentiment_scores': {},
            'keyword_emotions': {},
            'analysis_methods': []
        }
        
        # VADER sentiment analysis
        if self.vader_analyzer:
            vader_results = self._analyze_with_vader(text)
            results['sentiment_scores'] = vader_results
            results['analysis_methods'].append('vader')
        
        # Custom keyword analysis
        keyword_results = self._analyze_with_keywords(text)
        results['keyword_emotions'] = keyword_results
        results['analysis_methods'].append('keywords')
        
        # Combine results to determine primary emotion
        primary_emotion, intensity, confidence = self._combine_emotion_results(
            results['sentiment_scores'],
            results['keyword_emotions']
        )
        
        results['primary_emotion'] = primary_emotion
        results['intensity'] = intensity
        results['confidence'] = confidence
        results['emotion_category'] = self._categorize_emotion(primary_emotion)
        
        return results
    
    def _analyze_with_vader(self, text: str) -> Dict[str, float]:
        """Analyze sentiment using VADER"""
        
        scores = self.vader_analyzer.polarity_scores(text)
        
        return {
            'positive': scores['pos'],
            'negative': scores['neg'],
            'neutral': scores['neu'],
            'compound': scores['compound']
        }
    
    def _analyze_with_keywords(self, text: str) -> Dict[str, float]:
        """Analyze emotions using keyword matching"""
        
        text_lower = text.lower()
        emotion_scores = {}
        
        for emotion, keywords in self.emotion_keywords.items():
            matches = 0
            total_keywords = len(keywords)
            
            for keyword in keywords:
                if keyword in text_lower:
                    matches += 1
            
            if matches > 0:
                score = matches / total_keywords
                emotion_scores[emotion] = score
        
        return emotion_scores
    
    def _combine_emotion_results(self, sentiment_scores: Dict, keyword_emotions: Dict) -> Tuple[str, float, float]:
        """Combine results from different analysis methods"""
        
        emotion_weights = {}
        confidence_sum = 0
        total_methods = 0
        
        # Process VADER results
        if sentiment_scores:
            compound = sentiment_scores.get('compound', 0)
            
            if compound >= 0.5:
                emotion_weights['joy'] = abs(compound)
            elif compound <= -0.5:
                if sentiment_scores.get('negative', 0) > 0.3:
                    emotion_weights['sadness'] = abs(compound)
                else:
                    emotion_weights['anger'] = abs(compound) * 0.8
            else:
                emotion_weights['neutral'] = 1 - abs(compound)
            
            confidence_sum += abs(compound)
            total_methods += 1
        
        # Process keyword results
        for emotion, score in keyword_emotions.items():
            if emotion in emotion_weights:
                emotion_weights[emotion] = max(emotion_weights[emotion], score)
            else:
                emotion_weights[emotion] = score
            
            confidence_sum += score
        
        if keyword_emotions:
            total_methods += 1
        
        # Determine primary emotion
        if emotion_weights:
            primary_emotion = max(emotion_weights, key=emotion_weights.get)
            intensity = emotion_weights[primary_emotion]
            confidence = confidence_sum / max(total_methods, 1)
        else:
            primary_emotion = 'neutral'
            intensity = 0.5
            confidence = 0.3
        
        return primary_emotion, min(1.0, intensity), min(1.0, confidence)
    
    def _categorize_emotion(self, emotion: str) -> str:
        """Categorize emotion into positive, negative, or neutral"""
        
        for category, emotions in self.emotion_categories.items():
            if emotion in emotions:
                return category
        
        return 'neutral'
    
    def get_emotion_insights(self, emotion_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate insights and recommendations based on emotion analysis"""
        
        primary_emotion = emotion_data['primary_emotion']
        intensity = emotion_data['intensity']
        category = emotion_data['emotion_category']
        
        insights = {
            'emotional_state': f"{primary_emotion} ({category})",
            'intensity_level': 'high' if intensity > 0.7 else 'medium' if intensity > 0.4 else 'low',
            'recommendations': [],
            'conversation_approach': 'balanced',
            'response_tone': 'neutral'
        }
        
        # Generate recommendations based on emotion
        if category == 'negative':
            if primary_emotion in ['anxiety', 'fear']:
                insights['recommendations'] = [
                    'Practice deep breathing exercises',
                    'Ground yourself with 5-4-3-2-1 technique',
                    'Consider talking to someone you trust'
                ]
                insights['conversation_approach'] = 'supportive'
                insights['response_tone'] = 'calm_reassuring'
            
            elif primary_emotion in ['sadness', 'depression']:
                insights['recommendations'] = [
                    'Acknowledge your feelings as valid',
                    'Engage in gentle self-care activities',
                    'Reach out for professional support if needed'
                ]
                insights['conversation_approach'] = 'empathetic'
                insights['response_tone'] = 'warm_understanding'
            
            elif primary_emotion in ['anger', 'frustration']:
                insights['recommendations'] = [
                    'Take a few minutes to cool down',
                    'Identify the root cause of frustration',
                    'Consider constructive ways to address the issue'
                ]
                insights['conversation_approach'] = 'validating'
                insights['response_tone'] = 'calm_direct'
        
        elif category == 'positive':
            insights['recommendations'] = [
                'Savor this positive moment',
                'Share your joy with others',
                'Use this energy for productive activities'
            ]
            insights['conversation_approach'] = 'enthusiastic'
            insights['response_tone'] = 'warm_encouraging'
        
        else:  # neutral
            insights['conversation_approach'] = 'exploratory'
            insights['response_tone'] = 'curious_friendly'
        
        return insights

class SimpleVoiceInterface:
    """
    Simplified Voice Interface
    Text-based interface with emotion-aware responses
    """
    
    def __init__(self, emotion_engine: EmotionEngine = None):
        self.emotion_engine = emotion_engine or EmotionEngine()
        self.voice_enabled = False
        
        print("🎤 Simple Voice Interface initialized (text-based)")
    
    def toggle_voice(self) -> bool:
        """Toggle voice interface on/off"""
        
        self.voice_enabled = not self.voice_enabled
        status = "enabled" if self.voice_enabled else "disabled"
        print(f"🎤 Voice interface {status}")
        
        return self.voice_enabled
    
    def process_text_interaction(self, conversation_agent, user_input: str, user_id: str = "default") -> Dict[str, Any]:
        """Process text interaction with emotion analysis"""
        
        # Analyze emotion in text
        emotion_data = self.emotion_engine.analyze_emotion(user_input)
        
        # Get response from conversation agent
        response_data = conversation_agent.respond(
            user_input=user_input,
            user_id=user_id,
            context={'emotion_data': emotion_data}
        )
        
        return {
            'user_input': user_input,
            'emotion_data': emotion_data,
            'response_data': response_data,
            'emotion_insights': self.emotion_engine.get_emotion_insights(emotion_data)
        }
    
    def get_voice_status(self) -> Dict[str, Any]:
        """Get current voice interface status"""
        
        return {
            'voice_enabled': self.voice_enabled,
            'interface_type': 'text_based',
            'emotion_analysis_available': VADER_AVAILABLE,
            'advanced_features': False
        }

# Example usage and testing
if __name__ == "__main__":
    print("🎤 Testing QueenCalifia-Ω Simplified Voice Interface and Emotion Analysis...")
    
    # Initialize emotion engine
    emotion_engine = EmotionEngine()
    
    # Test emotion analysis
    print("\n🧠 Testing Emotion Analysis:")
    test_texts = [
        "I'm feeling really anxious about my job interview tomorrow",
        "I'm so excited about my vacation next week!",
        "I'm frustrated with my credit card debt situation",
        "Can you help me understand quantum computing?",
        "I feel hopeless and don't know what to do"
    ]
    
    for text in test_texts:
        emotion_data = emotion_engine.analyze_emotion(text)
        insights = emotion_engine.get_emotion_insights(emotion_data)
        
        print(f"\nText: {text}")
        print(f"Emotion: {emotion_data['primary_emotion']} ({emotion_data['emotion_category']})")
        print(f"Intensity: {emotion_data['intensity']:.2f}")
        print(f"Confidence: {emotion_data['confidence']:.2f}")
        print(f"Approach: {insights['conversation_approach']}")
        print(f"Tone: {insights['response_tone']}")
    
    # Initialize voice interface
    print("\n🎤 Testing Voice Interface:")
    voice_interface = SimpleVoiceInterface(emotion_engine)
    
    # Test voice status
    status = voice_interface.get_voice_status()
    print(f"Voice Status:")
    for key, value in status.items():
        print(f"  {key}: {value}")
    
    print("\n✅ Simplified Voice Interface and Emotion Analysis test completed!")

