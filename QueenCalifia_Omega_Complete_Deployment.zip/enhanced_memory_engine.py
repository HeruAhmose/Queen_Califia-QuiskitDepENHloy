"""
Enhanced Firebase + BigQuery Memory and Knowledge Systems
Real-time synchronization with cloud databases for QueenCalifia-Ω
"""

import json
import sqlite3
import os
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import hashlib
import uuid

# Firebase imports with fallback
try:
    import firebase_admin
    from firebase_admin import credentials, firestore, storage
    FIREBASE_AVAILABLE = True
except ImportError:
    FIREBASE_AVAILABLE = False
    print("⚠️ Firebase not available - using local storage")

# BigQuery imports with fallback
try:
    from google.cloud import bigquery
    from google.cloud.exceptions import NotFound
    BIGQUERY_AVAILABLE = True
except ImportError:
    BIGQUERY_AVAILABLE = False
    print("⚠️ BigQuery not available - using local knowledge base")

class EnhancedMemoryEngine:
    """
    Enhanced Memory Engine with Firebase + BigQuery Integration
    Provides real-time memory synchronization and knowledge management
    """
    
    def __init__(self, memory_file="memory/history_log.json", firebase_db=None, bigquery_client=None):
        self.memory_file = memory_file
        self.firebase_db = firebase_db
        self.bigquery_client = bigquery_client
        self.local_db = "memory/conversations.db"
        self.knowledge_db = "memory/knowledge_base.db"
        
        # Memory configuration
        self.sync_interval = 300  # 5 minutes
        self.max_local_memories = 10000
        self.importance_threshold = 0.6
        
        # Initialize storage systems
        self.initialize_local_storage()
        self.initialize_firebase()
        self.initialize_bigquery()
        
        # Start background sync
        self.sync_thread = threading.Thread(target=self._background_sync, daemon=True)
        self.sync_thread.start()
        
        print("✅ Enhanced Memory Engine initialized")
    
    def initialize_local_storage(self):
        """Initialize local SQLite databases"""
        os.makedirs("memory", exist_ok=True)
        
        # Conversations database
        conn = sqlite3.connect(self.local_db)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT UNIQUE,
                user_id TEXT,
                user_input TEXT,
                response TEXT,
                emotion_data TEXT,
                quantum_insights TEXT,
                importance_score REAL,
                timestamp TEXT,
                tags TEXT,
                synced_firebase BOOLEAN DEFAULT 0,
                synced_bigquery BOOLEAN DEFAULT 0
            )
        ''')
        
        # Memory tags for fast retrieval
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memory_tags (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id TEXT,
                tag_type TEXT,
                tag_value TEXT,
                relevance_score REAL,
                FOREIGN KEY (conversation_id) REFERENCES conversations (conversation_id)
            )
        ''')
        
        conn.commit()
        conn.close()
        
        # Knowledge base database
        conn = sqlite3.connect(self.knowledge_db)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge_base (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                knowledge_id TEXT UNIQUE,
                category TEXT,
                content TEXT,
                source TEXT,
                confidence_score REAL,
                last_updated TEXT,
                access_count INTEGER DEFAULT 0,
                relevance_score REAL DEFAULT 0.5
            )
        ''')
        
        # Knowledge relationships
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge_relationships (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_knowledge_id TEXT,
                target_knowledge_id TEXT,
                relationship_type TEXT,
                strength REAL,
                FOREIGN KEY (source_knowledge_id) REFERENCES knowledge_base (knowledge_id),
                FOREIGN KEY (target_knowledge_id) REFERENCES knowledge_base (knowledge_id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def initialize_firebase(self):
        """Initialize Firebase Firestore connection"""
        if not FIREBASE_AVAILABLE:
            return
        
        try:
            # Check if Firebase is already initialized
            if not firebase_admin._apps:
                if os.path.exists('secrets/serviceAccountKey.json'):
                    cred = credentials.Certificate('secrets/serviceAccountKey.json')
                    firebase_admin.initialize_app(cred, {
                        'storageBucket': 'queencalifia-omega.appspot.com'
                    })
                    self.firebase_db = firestore.client()
                    print("✅ Firebase Firestore connected")
                else:
                    print("⚠️ Firebase service account key not found")
            else:
                self.firebase_db = firestore.client()
                print("✅ Firebase Firestore already connected")
                
        except Exception as e:
            print(f"⚠️ Firebase initialization failed: {e}")
    
    def initialize_bigquery(self):
        """Initialize BigQuery connection and create datasets/tables"""
        if not BIGQUERY_AVAILABLE:
            return
        
        try:
            if os.path.exists('secrets/serviceAccountKey.json'):
                self.bigquery_client = bigquery.Client.from_service_account_json('secrets/serviceAccountKey.json')
                
                # Create dataset if it doesn't exist
                dataset_id = "queen_califia_knowledge"
                dataset_ref = self.bigquery_client.dataset(dataset_id)
                
                try:
                    self.bigquery_client.get_dataset(dataset_ref)
                except NotFound:
                    dataset = bigquery.Dataset(dataset_ref)
                    dataset.location = "US"
                    self.bigquery_client.create_dataset(dataset)
                    print(f"✅ Created BigQuery dataset: {dataset_id}")
                
                # Create tables
                self._create_bigquery_tables()
                print("✅ BigQuery connected and tables ready")
                
            else:
                print("⚠️ BigQuery service account key not found")
                
        except Exception as e:
            print(f"⚠️ BigQuery initialization failed: {e}")
    
    def _create_bigquery_tables(self):
        """Create BigQuery tables for knowledge storage"""
        
        # Conversations table schema
        conversations_schema = [
            bigquery.SchemaField("conversation_id", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("user_id", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("user_input", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("response", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("emotion_data", "JSON", mode="NULLABLE"),
            bigquery.SchemaField("quantum_insights", "JSON", mode="NULLABLE"),
            bigquery.SchemaField("importance_score", "FLOAT", mode="REQUIRED"),
            bigquery.SchemaField("timestamp", "TIMESTAMP", mode="REQUIRED"),
            bigquery.SchemaField("tags", "JSON", mode="NULLABLE"),
        ]
        
        # Knowledge base table schema
        knowledge_schema = [
            bigquery.SchemaField("knowledge_id", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("category", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("content", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("source", "STRING", mode="REQUIRED"),
            bigquery.SchemaField("confidence_score", "FLOAT", mode="REQUIRED"),
            bigquery.SchemaField("last_updated", "TIMESTAMP", mode="REQUIRED"),
            bigquery.SchemaField("access_count", "INTEGER", mode="REQUIRED"),
            bigquery.SchemaField("relevance_score", "FLOAT", mode="REQUIRED"),
        ]
        
        # Create tables
        tables = [
            ("conversations", conversations_schema),
            ("knowledge_base", knowledge_schema)
        ]
        
        for table_name, schema in tables:
            table_id = f"queen_califia_knowledge.{table_name}"
            try:
                self.bigquery_client.get_table(table_id)
            except NotFound:
                table = bigquery.Table(table_id, schema=schema)
                self.bigquery_client.create_table(table)
                print(f"✅ Created BigQuery table: {table_name}")
    
    def log_conversation(self, user_input: str, response: str, emotion_data: Dict, 
                        quantum_insights: Dict = None, user_id: str = "default", 
                        importance_score: float = None) -> str:
        """Enhanced conversation logging with automatic importance scoring"""
        
        # Generate unique conversation ID
        conversation_id = str(uuid.uuid4())
        
        # Calculate importance score if not provided
        if importance_score is None:
            importance_score = self._calculate_importance_score(user_input, response, emotion_data)
        
        # Generate memory tags
        tags = self._generate_memory_tags(user_input, response, emotion_data, quantum_insights)
        
        record = {
            "conversation_id": conversation_id,
            "timestamp": datetime.utcnow().isoformat(),
            "user_id": user_id,
            "user_input": user_input,
            "response": response,
            "emotion_data": emotion_data,
            "quantum_insights": quantum_insights or {},
            "importance_score": importance_score,
            "tags": tags
        }
        
        # Log to local storage
        self._log_to_local(record)
        
        # Log to Firebase if available (real-time sync)
        if self.firebase_db:
            self._log_to_firebase(record)
        
        # Log to BigQuery if important enough
        if self.bigquery_client and importance_score >= self.importance_threshold:
            self._log_to_bigquery(record)
        
        return conversation_id
    
    def _calculate_importance_score(self, user_input: str, response: str, emotion_data: Dict) -> float:
        """Calculate conversation importance score"""
        score = 0.5  # Base score
        
        # Length factor (longer conversations tend to be more important)
        length_factor = min(1.0, (len(user_input) + len(response)) / 500.0)
        score += length_factor * 0.2
        
        # Emotion intensity factor
        emotion_intensity = emotion_data.get('intensity', 0.5)
        score += emotion_intensity * 0.2
        
        # Topic importance (financial, health, personal issues are more important)
        important_keywords = [
            'credit', 'debt', 'money', 'investment', 'health', 'anxiety', 'depression',
            'relationship', 'career', 'problem', 'help', 'advice', 'emergency'
        ]
        
        text_lower = (user_input + " " + response).lower()
        keyword_matches = sum(1 for keyword in important_keywords if keyword in text_lower)
        score += min(0.3, keyword_matches * 0.1)
        
        return min(1.0, score)
    
    def _generate_memory_tags(self, user_input: str, response: str, emotion_data: Dict, 
                             quantum_insights: Dict) -> List[Dict]:
        """Generate comprehensive memory tags"""
        tags = []
        
        # Emotion tags
        primary_emotion = emotion_data.get('primary_emotion', 'neutral')
        emotion_intensity = emotion_data.get('intensity', 0.5)
        tags.append({
            'type': 'emotion',
            'value': primary_emotion,
            'relevance': emotion_intensity
        })
        
        # Topic tags
        topic_keywords = {
            'financial': ['credit', 'money', 'invest', 'debt', 'budget', 'loan', 'savings', 'income'],
            'health': ['stress', 'sleep', 'anxiety', 'wellness', 'health', 'exercise', 'diet'],
            'career': ['job', 'work', 'career', 'salary', 'interview', 'promotion', 'skills'],
            'relationship': ['relationship', 'dating', 'family', 'friend', 'love', 'marriage'],
            'personal': ['help', 'advice', 'problem', 'question', 'goal', 'plan'],
            'technology': ['computer', 'software', 'app', 'internet', 'AI', 'quantum'],
            'education': ['learn', 'study', 'school', 'course', 'knowledge', 'skill']
        }
        
        text_combined = (user_input + " " + response).lower()
        for topic, keywords in topic_keywords.items():
            matches = sum(1 for keyword in keywords if keyword in text_combined)
            if matches > 0:
                relevance = min(1.0, matches / len(keywords))
                tags.append({
                    'type': 'topic',
                    'value': topic,
                    'relevance': relevance
                })
        
        # Quantum insights tags
        if quantum_insights:
            if quantum_insights.get('quantum_entanglement_detected', False):
                tags.append({
                    'type': 'quantum',
                    'value': 'entangled_thinking',
                    'relevance': 0.8
                })
            
            consciousness_coherence = quantum_insights.get('consciousness_coherence', 0)
            if consciousness_coherence > 0.8:
                tags.append({
                    'type': 'quantum',
                    'value': 'high_coherence',
                    'relevance': consciousness_coherence
                })
        
        return tags
    
    def _log_to_local(self, record: Dict):
        """Log to local SQLite database"""
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            
            # Insert conversation
            cursor.execute('''
                INSERT OR REPLACE INTO conversations 
                (conversation_id, user_id, user_input, response, emotion_data, quantum_insights,
                 importance_score, timestamp, tags, synced_firebase, synced_bigquery)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                record['conversation_id'],
                record['user_id'],
                record['user_input'],
                record['response'],
                json.dumps(record['emotion_data']),
                json.dumps(record['quantum_insights']),
                record['importance_score'],
                record['timestamp'],
                json.dumps(record['tags']),
                1 if self.firebase_db else 0,
                1 if self.bigquery_client and record['importance_score'] >= self.importance_threshold else 0
            ))
            
            # Insert tags
            for tag in record['tags']:
                cursor.execute('''
                    INSERT INTO memory_tags (conversation_id, tag_type, tag_value, relevance_score)
                    VALUES (?, ?, ?, ?)
                ''', (
                    record['conversation_id'],
                    tag['type'],
                    tag['value'],
                    tag['relevance']
                ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            print(f"Local logging error: {e}")
    
    def _log_to_firebase(self, record: Dict):
        """Log to Firebase Firestore"""
        try:
            # Convert timestamp to Firebase timestamp
            record_copy = record.copy()
            record_copy['timestamp'] = firestore.SERVER_TIMESTAMP
            
            self.firebase_db.collection('conversations').document(record['conversation_id']).set(record_copy)
            
        except Exception as e:
            print(f"Firebase logging error: {e}")
    
    def _log_to_bigquery(self, record: Dict):
        """Log important conversations to BigQuery"""
        try:
            table_id = "queen_califia_knowledge.conversations"
            
            # Prepare record for BigQuery
            bq_record = {
                'conversation_id': record['conversation_id'],
                'user_id': record['user_id'],
                'user_input': record['user_input'],
                'response': record['response'],
                'emotion_data': record['emotion_data'],
                'quantum_insights': record['quantum_insights'],
                'importance_score': record['importance_score'],
                'timestamp': record['timestamp'],
                'tags': record['tags']
            }
            
            errors = self.bigquery_client.insert_rows_json(table_id, [bq_record])
            if errors:
                print(f"BigQuery logging errors: {errors}")
                
        except Exception as e:
            print(f"BigQuery logging error: {e}")
    
    def get_contextual_memory(self, user_input: str, user_id: str = "default", 
                             max_memories: int = 5) -> List[Dict]:
        """Get contextually relevant memories"""
        
        # Extract keywords from user input for relevance matching
        keywords = self._extract_keywords(user_input)
        
        memories = []
        
        # Search local database first
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            
            # Get memories with matching tags
            query = '''
                SELECT DISTINCT c.conversation_id, c.user_input, c.response, c.emotion_data,
                       c.quantum_insights, c.importance_score, c.timestamp,
                       AVG(mt.relevance_score) as avg_relevance
                FROM conversations c
                JOIN memory_tags mt ON c.conversation_id = mt.conversation_id
                WHERE c.user_id = ? AND mt.tag_value IN ({})
                GROUP BY c.conversation_id
                ORDER BY avg_relevance DESC, c.importance_score DESC, c.timestamp DESC
                LIMIT ?
            '''.format(','.join(['?' for _ in keywords]))
            
            cursor.execute(query, [user_id] + keywords + [max_memories])
            rows = cursor.fetchall()
            
            for row in rows:
                memories.append({
                    'conversation_id': row[0],
                    'user_input': row[1],
                    'response': row[2],
                    'emotion_data': json.loads(row[3]) if row[3] else {},
                    'quantum_insights': json.loads(row[4]) if row[4] else {},
                    'importance_score': row[5],
                    'timestamp': row[6],
                    'relevance_score': row[7]
                })
            
            conn.close()
            
        except Exception as e:
            print(f"Local memory retrieval error: {e}")
        
        # If we don't have enough memories, get recent ones
        if len(memories) < max_memories:
            recent_memories = self.get_recent_conversations(user_id, max_memories - len(memories))
            memories.extend(recent_memories)
        
        return memories[:max_memories]
    
    def get_recent_conversations(self, user_id: str = "default", limit: int = 5) -> List[Dict]:
        """Get recent conversations"""
        conversations = []
        
        # Try Firebase first
        if self.firebase_db:
            try:
                docs = self.firebase_db.collection('conversations')\
                    .where('user_id', '==', user_id)\
                    .order_by('timestamp', direction=firestore.Query.DESCENDING)\
                    .limit(limit).stream()
                
                for doc in docs:
                    data = doc.to_dict()
                    conversations.append(data)
                
                if conversations:
                    return conversations
                    
            except Exception as e:
                print(f"Firebase recent conversations error: {e}")
        
        # Fallback to local database
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT conversation_id, user_input, response, emotion_data, quantum_insights,
                       importance_score, timestamp
                FROM conversations 
                WHERE user_id = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (user_id, limit))
            
            rows = cursor.fetchall()
            conn.close()
            
            for row in rows:
                conversations.append({
                    'conversation_id': row[0],
                    'user_input': row[1],
                    'response': row[2],
                    'emotion_data': json.loads(row[3]) if row[3] else {},
                    'quantum_insights': json.loads(row[4]) if row[4] else {},
                    'importance_score': row[5],
                    'timestamp': row[6]
                })
                
        except Exception as e:
            print(f"Local recent conversations error: {e}")
        
        return conversations
    
    def add_knowledge(self, category: str, content: str, source: str, 
                     confidence_score: float = 0.8) -> str:
        """Add knowledge to the knowledge base"""
        
        knowledge_id = str(uuid.uuid4())
        
        # Store locally
        try:
            conn = sqlite3.connect(self.knowledge_db)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO knowledge_base 
                (knowledge_id, category, content, source, confidence_score, last_updated, access_count, relevance_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                knowledge_id, category, content, source, confidence_score,
                datetime.utcnow().isoformat(), 0, 0.5
            ))
            conn.commit()
            conn.close()
            
        except Exception as e:
            print(f"Local knowledge storage error: {e}")
        
        # Store in BigQuery if available
        if self.bigquery_client:
            try:
                table_id = "queen_califia_knowledge.knowledge_base"
                record = {
                    'knowledge_id': knowledge_id,
                    'category': category,
                    'content': content,
                    'source': source,
                    'confidence_score': confidence_score,
                    'last_updated': datetime.utcnow().isoformat(),
                    'access_count': 0,
                    'relevance_score': 0.5
                }
                
                errors = self.bigquery_client.insert_rows_json(table_id, [record])
                if errors:
                    print(f"BigQuery knowledge storage errors: {errors}")
                    
            except Exception as e:
                print(f"BigQuery knowledge storage error: {e}")
        
        return knowledge_id
    
    def search_knowledge(self, query: str, category: str = None, limit: int = 10) -> List[Dict]:
        """Search knowledge base"""
        results = []
        
        # Search BigQuery first if available
        if self.bigquery_client:
            try:
                sql_query = """
                SELECT knowledge_id, category, content, source, confidence_score, last_updated
                FROM `queen_califia_knowledge.knowledge_base`
                WHERE LOWER(content) CONTAINS @query
                """
                
                if category:
                    sql_query += " AND category = @category"
                
                sql_query += " ORDER BY confidence_score DESC, access_count DESC LIMIT @limit"
                
                job_config = bigquery.QueryJobConfig(
                    query_parameters=[
                        bigquery.ScalarQueryParameter("query", "STRING", query.lower()),
                        bigquery.ScalarQueryParameter("limit", "INT64", limit),
                    ]
                )
                
                if category:
                    job_config.query_parameters.append(
                        bigquery.ScalarQueryParameter("category", "STRING", category)
                    )
                
                query_job = self.bigquery_client.query(sql_query, job_config=job_config)
                
                for row in query_job:
                    results.append({
                        'knowledge_id': row.knowledge_id,
                        'category': row.category,
                        'content': row.content,
                        'source': row.source,
                        'confidence_score': row.confidence_score,
                        'last_updated': row.last_updated
                    })
                
                if results:
                    return results
                    
            except Exception as e:
                print(f"BigQuery knowledge search error: {e}")
        
        # Fallback to local search
        try:
            conn = sqlite3.connect(self.knowledge_db)
            cursor = conn.cursor()
            
            sql_query = '''
                SELECT knowledge_id, category, content, source, confidence_score, last_updated
                FROM knowledge_base
                WHERE LOWER(content) LIKE ?
            '''
            params = [f'%{query.lower()}%']
            
            if category:
                sql_query += ' AND category = ?'
                params.append(category)
            
            sql_query += ' ORDER BY confidence_score DESC, access_count DESC LIMIT ?'
            params.append(limit)
            
            cursor.execute(sql_query, params)
            rows = cursor.fetchall()
            conn.close()
            
            for row in rows:
                results.append({
                    'knowledge_id': row[0],
                    'category': row[1],
                    'content': row[2],
                    'source': row[3],
                    'confidence_score': row[4],
                    'last_updated': row[5]
                })
                
        except Exception as e:
            print(f"Local knowledge search error: {e}")
        
        return results
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extract keywords from text for relevance matching"""
        # Simple keyword extraction (can be enhanced with NLP)
        import re
        
        # Remove common stop words
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have',
            'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should',
            'may', 'might', 'can', 'i', 'you', 'he', 'she', 'it', 'we', 'they'
        }
        
        # Extract words
        words = re.findall(r'\b\w+\b', text.lower())
        keywords = [word for word in words if word not in stop_words and len(word) > 2]
        
        return keywords[:10]  # Limit to top 10 keywords
    
    def _background_sync(self):
        """Background synchronization with cloud services"""
        while True:
            try:
                # Sync unsynced conversations to Firebase
                if self.firebase_db:
                    self._sync_to_firebase()
                
                # Sync important conversations to BigQuery
                if self.bigquery_client:
                    self._sync_to_bigquery()
                
                # Clean up old local data
                self._cleanup_old_data()
                
                time.sleep(self.sync_interval)
                
            except Exception as e:
                print(f"Background sync error: {e}")
                time.sleep(60)  # Wait longer on error
    
    def _sync_to_firebase(self):
        """Sync unsynced conversations to Firebase"""
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT conversation_id, user_id, user_input, response, emotion_data,
                       quantum_insights, importance_score, timestamp, tags
                FROM conversations
                WHERE synced_firebase = 0
                LIMIT 100
            ''')
            
            rows = cursor.fetchall()
            
            for row in rows:
                record = {
                    'conversation_id': row[0],
                    'user_id': row[1],
                    'user_input': row[2],
                    'response': row[3],
                    'emotion_data': json.loads(row[4]) if row[4] else {},
                    'quantum_insights': json.loads(row[5]) if row[5] else {},
                    'importance_score': row[6],
                    'timestamp': firestore.SERVER_TIMESTAMP,
                    'tags': json.loads(row[7]) if row[7] else []
                }
                
                self.firebase_db.collection('conversations').document(row[0]).set(record)
                
                # Mark as synced
                cursor.execute('''
                    UPDATE conversations SET synced_firebase = 1 WHERE conversation_id = ?
                ''', (row[0],))
            
            conn.commit()
            conn.close()
            
            if rows:
                print(f"✅ Synced {len(rows)} conversations to Firebase")
                
        except Exception as e:
            print(f"Firebase sync error: {e}")
    
    def _sync_to_bigquery(self):
        """Sync important conversations to BigQuery"""
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT conversation_id, user_id, user_input, response, emotion_data,
                       quantum_insights, importance_score, timestamp, tags
                FROM conversations
                WHERE synced_bigquery = 0 AND importance_score >= ?
                LIMIT 50
            ''', (self.importance_threshold,))
            
            rows = cursor.fetchall()
            records = []
            
            for row in rows:
                records.append({
                    'conversation_id': row[0],
                    'user_id': row[1],
                    'user_input': row[2],
                    'response': row[3],
                    'emotion_data': json.loads(row[4]) if row[4] else {},
                    'quantum_insights': json.loads(row[5]) if row[5] else {},
                    'importance_score': row[6],
                    'timestamp': row[7],
                    'tags': json.loads(row[8]) if row[8] else []
                })
            
            if records:
                table_id = "queen_califia_knowledge.conversations"
                errors = self.bigquery_client.insert_rows_json(table_id, records)
                
                if not errors:
                    # Mark as synced
                    for row in rows:
                        cursor.execute('''
                            UPDATE conversations SET synced_bigquery = 1 WHERE conversation_id = ?
                        ''', (row[0],))
                    
                    conn.commit()
                    print(f"✅ Synced {len(records)} important conversations to BigQuery")
                else:
                    print(f"BigQuery sync errors: {errors}")
            
            conn.close()
            
        except Exception as e:
            print(f"BigQuery sync error: {e}")
    
    def _cleanup_old_data(self):
        """Clean up old local data to prevent database bloat"""
        try:
            # Keep only the most recent conversations locally
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            
            # Count total conversations
            cursor.execute('SELECT COUNT(*) FROM conversations')
            total_count = cursor.fetchone()[0]
            
            if total_count > self.max_local_memories:
                # Delete oldest conversations that are already synced
                delete_count = total_count - self.max_local_memories
                cursor.execute('''
                    DELETE FROM conversations
                    WHERE conversation_id IN (
                        SELECT conversation_id FROM conversations
                        WHERE synced_firebase = 1 AND synced_bigquery = 1
                        ORDER BY timestamp ASC
                        LIMIT ?
                    )
                ''', (delete_count,))
                
                # Clean up orphaned tags
                cursor.execute('''
                    DELETE FROM memory_tags
                    WHERE conversation_id NOT IN (SELECT conversation_id FROM conversations)
                ''')
                
                conn.commit()
                print(f"✅ Cleaned up {delete_count} old conversations")
            
            conn.close()
            
        except Exception as e:
            print(f"Cleanup error: {e}")
    
    def get_memory_statistics(self) -> Dict[str, Any]:
        """Get comprehensive memory system statistics"""
        stats = {
            'local_conversations': 0,
            'local_knowledge_items': 0,
            'firebase_connected': self.firebase_db is not None,
            'bigquery_connected': self.bigquery_client is not None,
            'sync_status': 'active',
            'last_sync': datetime.now().isoformat()
        }
        
        # Local statistics
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            
            cursor.execute('SELECT COUNT(*) FROM conversations')
            stats['local_conversations'] = cursor.fetchone()[0]
            
            cursor.execute('SELECT COUNT(*) FROM conversations WHERE synced_firebase = 0')
            stats['unsynced_firebase'] = cursor.fetchone()[0]
            
            cursor.execute('SELECT COUNT(*) FROM conversations WHERE synced_bigquery = 0')
            stats['unsynced_bigquery'] = cursor.fetchone()[0]
            
            conn.close()
            
            # Knowledge base statistics
            conn = sqlite3.connect(self.knowledge_db)
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM knowledge_base')
            stats['local_knowledge_items'] = cursor.fetchone()[0]
            conn.close()
            
        except Exception as e:
            print(f"Statistics error: {e}")
        
        return stats

# Example usage and testing
if __name__ == "__main__":
    print("🧠 Testing Enhanced Memory Engine with Firebase + BigQuery...")
    
    # Initialize memory engine
    memory_engine = EnhancedMemoryEngine()
    
    # Test conversation logging
    test_emotion = {
        'primary_emotion': 'curious',
        'intensity': 0.7,
        'confidence': 0.85
    }
    
    test_quantum = {
        'consciousness_coherence': 0.9,
        'quantum_entanglement_detected': True,
        'quantum_intuition_score': 0.8
    }
    
    conversation_id = memory_engine.log_conversation(
        user_input="How can I improve my credit score from 580?",
        response="I can help you improve your credit score! Here's a specific action plan...",
        emotion_data=test_emotion,
        quantum_insights=test_quantum,
        user_id="test_user"
    )
    
    print(f"✅ Logged conversation: {conversation_id}")
    
    # Test knowledge addition
    knowledge_id = memory_engine.add_knowledge(
        category="financial",
        content="Credit scores range from 300-850. A score of 580 is considered 'fair' and can be improved through consistent on-time payments, reducing credit utilization, and maintaining old accounts.",
        source="financial_expert_system",
        confidence_score=0.95
    )
    
    print(f"✅ Added knowledge: {knowledge_id}")
    
    # Test memory retrieval
    memories = memory_engine.get_contextual_memory("credit score help", "test_user")
    print(f"✅ Retrieved {len(memories)} relevant memories")
    
    # Test knowledge search
    knowledge = memory_engine.search_knowledge("credit score")
    print(f"✅ Found {len(knowledge)} knowledge items")
    
    # Get statistics
    stats = memory_engine.get_memory_statistics()
    print(f"📊 Memory Statistics:")
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    print("✅ Enhanced Memory Engine test completed!")

