"""
Enhanced Memory Manager with Firebase + BigQuery Integration
"""

import json
import sqlite3
from datetime import datetime
from typing import Dict, List, Optional

class MemoryEngine:
    def __init__(self, memory_file="memory/history_log.json", firebase_db=None, bigquery_client=None):
        self.memory_file = memory_file
        self.firebase_db = firebase_db
        self.bigquery_client = bigquery_client
        self.local_db = "memory/conversations.db"
        self.initialize_local_storage()
    
    def initialize_local_storage(self):
        """Initialize local SQLite database"""
        import os
        os.makedirs("memory", exist_ok=True)
        
        conn = sqlite3.connect(self.local_db)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                user_input TEXT,
                response TEXT,
                emotion_data TEXT,
                importance_score REAL,
                timestamp TEXT,
                tags TEXT
            )
        ''')
        conn.commit()
        conn.close()
    
    def log(self, user_input: str, response: str, emotion_data: Dict, user_id: str = "default", importance_score: float = 0.5):
        """Enhanced logging with multiple storage backends"""
        
        record = {
            "timestamp": str(datetime.utcnow()),
            "user_id": user_id,
            "user_input": user_input,
            "response": response,
            "emotion_data": emotion_data,
            "importance_score": importance_score,
            "tags": self._generate_tags(user_input, emotion_data)
        }
        
        # Log to local JSON file
        self._log_to_json(record)
        
        # Log to local SQLite
        self._log_to_sqlite(record)
        
        # Log to Firebase if available
        if self.firebase_db:
            self._log_to_firebase(record)
        
        # Log to BigQuery if available and important enough
        if self.bigquery_client and importance_score > 0.7:
            self._log_to_bigquery(record)
    
    def _log_to_json(self, record: Dict):
        """Log to local JSON file"""
        try:
            with open(self.memory_file, "a") as f:
                f.write(json.dumps(record) + "\n")
        except Exception as e:
            print(f"JSON logging error: {e}")
    
    def _log_to_sqlite(self, record: Dict):
        """Log to local SQLite database"""
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO conversations 
                (user_id, user_input, response, emotion_data, importance_score, timestamp, tags)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                record['user_id'],
                record['user_input'],
                record['response'],
                json.dumps(record['emotion_data']),
                record['importance_score'],
                record['timestamp'],
                json.dumps(record['tags'])
            ))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"SQLite logging error: {e}")
    
    def _log_to_firebase(self, record: Dict):
        """Log to Firebase Firestore"""
        try:
            self.firebase_db.collection('conversations').add(record)
        except Exception as e:
            print(f"Firebase logging error: {e}")
    
    def _log_to_bigquery(self, record: Dict):
        """Log important conversations to BigQuery"""
        try:
            table_id = "queen_califia_knowledge.important_conversations"
            rows_to_insert = [record]
            errors = self.bigquery_client.insert_rows_json(table_id, rows_to_insert)
            if errors:
                print(f"BigQuery logging errors: {errors}")
        except Exception as e:
            print(f"BigQuery logging error: {e}")
    
    def get_context(self, user_id: str = "default", last_n: int = 5) -> str:
        """Get conversation context with multiple fallbacks"""
        
        # Try Firebase first
        if self.firebase_db:
            try:
                docs = self.firebase_db.collection('conversations')\
                    .where('user_id', '==', user_id)\
                    .order_by('timestamp', direction='DESCENDING')\
                    .limit(last_n).stream()
                
                conversations = []
                for doc in docs:
                    data = doc.to_dict()
                    conversations.append(f"User: {data['user_input']}\nCalifia: {data['response']}")
                
                if conversations:
                    return "\n\n".join(reversed(conversations))
            except Exception as e:
                print(f"Firebase context retrieval error: {e}")
        
        # Fallback to SQLite
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT user_input, response FROM conversations 
                WHERE user_id = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (user_id, last_n))
            
            rows = cursor.fetchall()
            conn.close()
            
            conversations = [f"User: {row[0]}\nCalifia: {row[1]}" for row in rows]
            return "\n\n".join(reversed(conversations))
            
        except Exception as e:
            print(f"SQLite context retrieval error: {e}")
        
        # Final fallback to JSON file
        try:
            with open(self.memory_file, "r") as f:
                lines = f.readlines()[-last_n:]
                conversations = []
                for line in lines:
                    record = json.loads(line)
                    if record.get('user_id') == user_id:
                        conversations.append(f"User: {record['user_input']}\nCalifia: {record['response']}")
                return "\n\n".join(conversations)
        except:
            return "No prior context available."
    
    def search_memory(self, query: str, user_id: str = "default") -> List[Dict]:
        """Search memory across all storage systems"""
        results = []
        
        # Search Firebase
        if self.firebase_db:
            try:
                docs = self.firebase_db.collection('conversations')\
                    .where('user_id', '==', user_id).stream()
                
                for doc in docs:
                    data = doc.to_dict()
                    if query.lower() in data['user_input'].lower() or query.lower() in data['response'].lower():
                        results.append(data)
            except Exception as e:
                print(f"Firebase search error: {e}")
        
        # Search BigQuery for knowledge
        if self.bigquery_client:
            try:
                query_sql = f"""
                SELECT * FROM `queen_califia_knowledge.important_conversations`
                WHERE LOWER(user_input) CONTAINS '{query.lower()}'
                   OR LOWER(response) CONTAINS '{query.lower()}'
                ORDER BY importance_score DESC
                LIMIT 10
                """
                results_bq = self.bigquery_client.query(query_sql)
                for row in results_bq:
                    results.append(dict(row))
            except Exception as e:
                print(f"BigQuery search error: {e}")
        
        return results
    
    def _generate_tags(self, user_input: str, emotion_data: Dict) -> List[str]:
        """Generate tags for memory categorization"""
        tags = []
        
        # Emotion-based tags
        primary_emotion = emotion_data.get('primary_emotion', 'neutral')
        tags.append(f"emotion:{primary_emotion}")
        
        # Content-based tags
        content_keywords = {
            'financial': ['credit', 'money', 'invest', 'debt', 'budget', 'loan'],
            'health': ['stress', 'sleep', 'anxiety', 'wellness', 'health'],
            'career': ['job', 'work', 'career', 'salary', 'interview'],
            'relationship': ['relationship', 'dating', 'family', 'friend'],
            'personal': ['help', 'advice', 'problem', 'question']
        }
        
        user_lower = user_input.lower()
        for category, keywords in content_keywords.items():
            if any(keyword in user_lower for keyword in keywords):
                tags.append(f"topic:{category}")
        
        return tags
    
    def get_memory_stats(self) -> Dict:
        """Get memory system statistics"""
        stats = {
            'local_conversations': 0,
            'firebase_connected': self.firebase_db is not None,
            'bigquery_connected': self.bigquery_client is not None
        }
        
        # Count local conversations
        try:
            conn = sqlite3.connect(self.local_db)
            cursor = conn.cursor()
            cursor.execute('SELECT COUNT(*) FROM conversations')
            stats['local_conversations'] = cursor.fetchone()[0]
            conn.close()
        except:
            pass
        
        return stats

